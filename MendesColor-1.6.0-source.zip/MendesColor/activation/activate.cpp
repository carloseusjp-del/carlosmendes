#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <stdexcept>
#include "license_windows.hpp"
#include "version.hpp"
#include "win_ui.hpp"

namespace {
constexpr int ID_ICON = 100, ID_MACHINE = 101, ID_COPY_MACHINE = 102, ID_LICENSE = 103,
              ID_ACTIVATE = 104, ID_STATUS = 105;
constexpr wchar_t kClass[] = L"MendesColorActivateWindow";

struct Application {
    HINSTANCE instance{};
    HWND window{}, machine{}, license{}, status{};
    HFONT normal{}, title{}, small{};
    HICON largeIcon{}, smallIcon{};
    std::string machineId;

    ~Application() {
        if (normal) DeleteObject(normal);
        if (title) DeleteObject(title);
        if (small) DeleteObject(small);
        if (largeIcon) DestroyIcon(largeIcon);
        if (smallIcon) DestroyIcon(smallIcon);
    }

    void create(HWND owner) {
        window = owner;
        normal = mendes::winui::font(10);
        title = mendes::winui::font(18, true);
        small = mendes::winui::font(9);
        largeIcon = mendes::winui::icon(instance, 1, 96);
        smallIcon = mendes::winui::icon(instance, 1, 32);
        SendMessageW(owner, WM_SETICON, ICON_BIG, reinterpret_cast<LPARAM>(largeIcon));
        SendMessageW(owner, WM_SETICON, ICON_SMALL, reinterpret_cast<LPARAM>(smallIcon));
        HWND logo = mendes::winui::control(owner, WC_STATICW, L"", SS_ICON, 28, 24, 96, 96,
                                           ID_ICON, normal);
        SendMessageW(logo, STM_SETIMAGE, IMAGE_ICON, reinterpret_cast<LPARAM>(largeIcon));
        mendes::winui::control(owner, WC_STATICW, L"Ativar Mendes Color", SS_LEFT, 145, 30, 500,
                              36, 0, title);
        mendes::winui::control(owner, WC_STATICW,
                              L"Ativação offline • nenhuma conta ou conexão é necessária", SS_LEFT,
                              145, 73, 500, 22, 0, small);
        mendes::winui::control(owner, WC_STATICW, L"ID desta máquina", SS_LEFT, 28, 140, 260, 22,
                              0, normal);
        machine = mendes::winui::control(owner, WC_EDITW, L"", ES_AUTOHSCROLL | ES_READONLY, 28,
                                         166, 500, 29, ID_MACHINE, normal);
        mendes::winui::control(owner, WC_BUTTONW, L"Copiar ID", BS_PUSHBUTTON, 542, 165, 130, 31,
                              ID_COPY_MACHINE, normal);
        mendes::winui::control(owner, WC_STATICW,
                              L"Envie esse ID ao fornecedor e cole abaixo a key recebida:", SS_LEFT,
                              28, 220, 620, 22, 0, normal);
        license = mendes::winui::control(owner, WC_EDITW, L"",
                                         ES_MULTILINE | ES_AUTOVSCROLL | ES_WANTRETURN | WS_VSCROLL,
                                         28, 248, 644, 126, ID_LICENSE, normal);
        mendes::winui::control(owner, WC_BUTTONW, L"ATIVAR LICENÇA", BS_DEFPUSHBUTTON, 28, 394,
                              210, 40, ID_ACTIVATE, normal);
        status = mendes::winui::control(owner, WC_STATICW, L"", SS_LEFT, 258, 398, 414, 58,
                                        ID_STATUS, normal);
        machineId = mendes::license::machineId();
        SetWindowTextW(machine, mendes::license::wide(machineId).c_str());
        updateStatus();
    }

    void updateStatus() {
        const auto current = mendes::license::readAndValidate();
        std::wstring message;
        if (current.valid())
            message = L"✓ " + mendes::license::wide(current.detail) + L"\nLicenciado para: " +
                      mendes::license::wide(current.fields.customer);
        else
            message = L"Status: " + mendes::license::wide(current.detail);
        SetWindowTextW(status, message.c_str());
    }

    void command(int id) {
        if (id == ID_COPY_MACHINE) {
            mendes::winui::clipboard(window, mendes::license::wide(machineId));
            SetWindowTextW(status, L"ID copiado. Envie ao responsável pelas licenças.");
        } else if (id == ID_ACTIVATE) {
            const auto value = mendes::license::utf8(mendes::winui::text(license));
            std::string error;
            if (!mendes::license::save(value, error)) {
                MessageBoxW(window, mendes::license::wide(error).c_str(), L"Licença recusada",
                            MB_OK | MB_ICONERROR);
                return;
            }
            mendes::license::gate().refresh();
            updateStatus();
            MessageBoxW(window,
                        L"Mendes Color foi ativado. Se o DaVinci Resolve já estiver aberto, "
                        L"feche e abra novamente.",
                        L"Ativação concluída", MB_OK | MB_ICONINFORMATION);
        }
    }
};

Application *application = nullptr;
LRESULT CALLBACK procedure(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
    try {
        if (message == WM_CREATE) {
            application = static_cast<Application *>(reinterpret_cast<CREATESTRUCTW *>(lParam)->lpCreateParams);
            application->create(window);
            return 0;
        }
        if (message == WM_COMMAND && application) {
            application->command(LOWORD(wParam));
            return 0;
        }
        if (message == WM_DESTROY) {
            PostQuitMessage(0);
            return 0;
        }
    } catch (const std::exception &error) {
        MessageBoxW(window, mendes::license::wide(error.what()).c_str(), L"Mendes Color",
                    MB_OK | MB_ICONERROR);
    }
    return DefWindowProcW(window, message, wParam, lParam);
}
} // namespace

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
    Application app;
    app.instance = instance;
    INITCOMMONCONTROLSEX controls{sizeof(controls), ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&controls);
    WNDCLASSEXW type{};
    type.cbSize = sizeof(type);
    type.lpfnWndProc = procedure;
    type.hInstance = instance;
    type.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    type.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
    type.lpszClassName = kClass;
    type.hIcon = mendes::winui::icon(instance, 1, 32);
    if (!RegisterClassExW(&type))
        return 1;
    HWND window = CreateWindowExW(0, kClass, L"Mendes Color — Ativação " MENDES_WIDE_LITERAL(MENDES_COLOR_VERSION),
                                  WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                                  CW_USEDEFAULT, CW_USEDEFAULT, 720, 520, nullptr, nullptr, instance,
                                  &app);
    if (!window)
        return 1;
    mendes::winui::center(window);
    ShowWindow(window, show);
    UpdateWindow(window);
    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
    return static_cast<int>(message.wParam);
}
