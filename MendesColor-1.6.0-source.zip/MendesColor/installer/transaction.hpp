#pragma once
#include <exception>
#include <filesystem>
#include <stdexcept>
#include <string>

namespace mendes_setup {
namespace fs = std::filesystem;
struct Result { fs::path destination, backup; };

// Prepare and verify an owned staging directory before moving the installed
// bundle. Backups live outside the OFX scan directory on the same volume.
template<class Writer>
Result install(const fs::path& plugins, const fs::path& backups, const std::string& tag, Writer writer) {
    if (tag.empty() || tag.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_") != std::string::npos)
        throw std::invalid_argument("Invalid staging identifier.");
    Result result{plugins / "MendesColor.ofx.bundle", {}};
    const auto stage = plugins / (".mendes-stage-" + tag);
    if (fs::exists(stage)) throw std::runtime_error("Staging directory already exists; nothing was overwritten.");
    if (fs::exists(result.destination) && !fs::is_directory(result.destination))
        throw std::runtime_error("The plugin destination exists and is not a directory.");
    fs::create_directories(plugins);
    if (!fs::create_directory(stage)) throw std::runtime_error("Cannot create staging directory.");
    bool moved = false;
    try {
        writer(stage);
        if (fs::exists(result.destination)) {
            fs::create_directories(backups);
            result.backup = backups / (tag + "-MendesColor.ofx.bundle");
            if (fs::exists(result.backup)) throw std::runtime_error("Backup already exists; previous install was not changed.");
            fs::rename(result.destination, result.backup);
            moved = true;
        }
        fs::rename(stage, result.destination);
        return result;
    } catch (...) {
        const auto original = std::current_exception();
        std::error_code cleanup;
        fs::remove_all(stage, cleanup);
        if (moved) {
            std::error_code restore;
            fs::rename(result.backup, result.destination, restore);
            if (restore) throw std::runtime_error("Installation failed and rollback could not complete. The previous bundle is preserved in the backup directory.");
        }
        std::rethrow_exception(original);
    }
}
} // namespace mendes_setup
