# Run from the extracted release folder in an elevated Windows PowerShell.
[CmdletBinding(SupportsShouldProcess = $true)]
param()
$ErrorActionPreference = 'Stop'
$bundle = 'MendesColor.ofx.bundle'
$source = Join-Path $PSScriptRoot $bundle
$binary = Join-Path $source 'Contents\Win64\MendesColor.ofx'
$manifest = Get-Content (Join-Path $PSScriptRoot 'manifest.json') -Raw | ConvertFrom-Json
if (-not (Test-Path -LiteralPath $binary -PathType Leaf)) {
    throw 'Plugin not found. Extract the complete ZIP before installing.'
}
if ((Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.sha256) {
    throw 'Plugin checksum mismatch. Do not install this copy; extract the release again.'
}
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Open PowerShell as Administrator, close DaVinci Resolve, and run this script again.'
}
if (Get-Process -Name Resolve -ErrorAction SilentlyContinue) {
    throw 'Close DaVinci Resolve before installing.'
}
$root = Join-Path $env:ProgramFiles 'Common Files\OFX\Plugins'
$destination = Join-Path $root $bundle
if (-not $PSCmdlet.ShouldProcess($destination, 'Install Mendes Color; back up any existing version')) { return }
New-Item -ItemType Directory -Path $root -Force | Out-Null
$suffix = [Guid]::NewGuid().ToString('N')
$staging = Join-Path $root ('.mendes-staging-' + $suffix)
$backup = $null
try {
    Copy-Item -LiteralPath $source -Destination $staging -Recurse
    $stagedBinary = Join-Path $staging 'Contents\Win64\MendesColor.ofx'
    if ((Get-FileHash -LiteralPath $stagedBinary -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.sha256) {
        throw 'Copied plugin checksum mismatch.'
    }
    if (Test-Path -LiteralPath $destination) {
        $backupRoot = Join-Path $env:ProgramData 'MendesColor\backups'
        New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
        $backup = Join-Path $backupRoot ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $suffix + '-' + $bundle)
        Move-Item -LiteralPath $destination -Destination $backup
    }
    Move-Item -LiteralPath $staging -Destination $destination
} catch {
    if ($backup -and -not (Test-Path -LiteralPath $destination)) {
        Move-Item -LiteralPath $backup -Destination $destination
    }
    throw
} finally {
    if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force }
}
Write-Host ('Installed: ' + $destination)
if ($backup) { Write-Host ('Previous version preserved: ' + $backup) }
$activator = Join-Path $destination 'Contents\Resources\MendesColorActivate.exe'
Write-Host ('Activation app: ' + $activator)
Write-Host 'Run the activation app, insert your key, then start Resolve and search Effects for Mendes Color.'
