"""Create the Mendes Color signing identity once and embed only encrypted private material."""

from __future__ import annotations

import base64
import os
import secrets
import struct
from pathlib import Path

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "src/license_public.hpp"
SECRET = ROOT / "admin/license_secret.hpp"
PASSWORD = ROOT / "build/private/license-studio-password.txt"
ITERATIONS = 310_000


def array(name: str, data: bytes) -> str:
    values = ", ".join(f"0x{value:02x}" for value in data)
    return f"inline constexpr unsigned char {name}[] = {{{values}}};\n"


if PUBLIC.exists() or SECRET.exists():
    if not (PUBLIC.exists() and SECRET.exists()):
        raise SystemExit("Refusing to replace only one half of the existing signing identity.")
    print("Existing Mendes Color signing identity preserved.")
    raise SystemExit(0)

private = ec.generate_private_key(ec.SECP256R1())
numbers = private.private_numbers()
public = numbers.public_numbers
x = public.x.to_bytes(32, "big")
y = public.y.to_bytes(32, "big")
d = numbers.private_value.to_bytes(32, "big")

# Windows BCRYPT_ECCKEY_BLOB, ECDSA P-256 public/private magic values.
public_blob = struct.pack("<II", 0x31534345, 32) + x + y
private_blob = struct.pack("<II", 0x32534345, 32) + x + y + d

password = base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")
salt = secrets.token_bytes(16)
nonce = secrets.token_bytes(12)
key = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=ITERATIONS).derive(
    password.encode("ascii")
)
encrypted = AESGCM(key).encrypt(nonce, private_blob, b"MendesColor-License-Studio-1")
ciphertext, tag = encrypted[:-16], encrypted[-16:]

PUBLIC.write_text(
    "#pragma once\n#include <cstddef>\nnamespace mendes::license {\n"
    + array("kPublicKeyBlob", public_blob)
    + "inline constexpr std::size_t kPublicKeyBlobSize=sizeof(kPublicKeyBlob);\n"
    + "} // namespace mendes::license\n",
    encoding="utf-8",
)
SECRET.parent.mkdir(parents=True, exist_ok=True)
SECRET.write_text(
    "#pragma once\n#include <cstddef>\nnamespace mendes::license_admin {\n"
    + f"inline constexpr unsigned long long kPbkdf2Iterations={ITERATIONS}ULL;\n"
    + array("kSalt", salt)
    + array("kNonce", nonce)
    + array("kTag", tag)
    + array("kEncryptedPrivateKey", ciphertext)
    + 'inline constexpr unsigned char kAad[]="MendesColor-License-Studio-1";\n'
    + "} // namespace mendes::license_admin\n",
    encoding="utf-8",
)
PASSWORD.parent.mkdir(parents=True, exist_ok=True)
PASSWORD.write_text(password + "\n", encoding="ascii")
os.chmod(PASSWORD, 0o600)
print("Created a new signing identity. The private key is embedded only in encrypted form.")
print(f"Administrative password saved outside release sources: {PASSWORD}")
