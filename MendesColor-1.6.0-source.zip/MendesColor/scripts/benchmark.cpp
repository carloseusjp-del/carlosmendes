// Synthetic CPU benchmark. No Resolve/GPU timings are implied.
#include "avata2_lut.hpp"
#include "frame.hpp"
#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <vector>
#ifdef MENDES_PARALLEL_BENCH
#include <thread>
OfxStatus spawn(OfxThreadFunctionV1 fn, unsigned n, void* data) {
    std::vector<std::thread> threads;
    for(unsigned i=1;i<n;++i)threads.emplace_back([=]{fn(i,n,data);});
    fn(0,n,data);for(auto& t:threads)t.join();return kOfxStatOK;
}
OfxStatus cpus(unsigned* n){*n=std::thread::hardware_concurrency();return kOfxStatOK;}
#endif
int main(int argc,char** argv) {
    using namespace mendes;
    const int w=argc>1?std::stoi(argv[1]):1920,h=argc>2?std::stoi(argv[2]):1080;
    const int repeats=argc>3?std::stoi(argv[3]):3;
    const std::string fixture=argc>4?argv[4]:"";
    std::vector<float> src(static_cast<std::size_t>(w)*h*4),dst(src.size());
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){auto p=&src[(y*w+x)*4];
        p[3]=fixture.empty()?1.0f:((x+y)%13==0?0.0f:((x+y)%7==0?.35f:1.0f));
        p[0]=static_cast<float>((x*13+y*3)%1024/1023.0);p[1]=static_cast<float>((x*3+y*17)%1024/1023.0);
        p[2]=static_cast<float>((x*7+y*11)%1024/1023.0);
        if(!fixture.empty()){p[0]=(p[0]*1.4f-.1f)*p[3];p[1]*=p[3];p[2]=(p[2]*2.0f)*p[3];}}
    std::ofstream gold;if(!fixture.empty())gold.open(fixture,std::ios::binary);
#ifdef MENDES_PARALLEL_BENCH
    OfxMultiThreadSuiteV1 suite{};suite.multiThread=spawn;suite.multiThreadNumCPUs=cpus;
    RowExecutor exec(argc>5&&std::string(argv[5])=="serial"?nullptr:&suite);
#endif
    for(int scenario=0;scenario<(fixture.empty()?3:8);++scenario){
        if(argc>6 && scenario!=std::stoi(argv[6]))continue;
        Controls c;c.look=Look::CommercialTeal;c.lookStrength=.8;
        AdvSettings s;
        auto preset=[&](AdvId id,int index){for(auto [field,v]:designedPreset(id,index))s.set(field,v);};
        if(scenario==1 || scenario==2 || scenario>=4){preset(AdvId::HalationProfile,2);preset(AdvId::BloomProfile,3);}
        if(scenario==2 || scenario>=5){preset(AdvId::GrainPreset,3);preset(AdvId::VignettePreset,2);
            preset(AdvId::SkinPreset,4);preset(AdvId::SplitToningPreset,2);s.set(AdvId::BasicEnable,1);s.set(AdvId::Exposure,.2);}
        if(scenario==6)s.set(AdvId::HalationMaskMode,1);
        if(scenario==7)s.set(AdvId::BloomMaskMode,1);
        Pipeline p(c,avata2Cube(),LutEncoding::Preserve,std::make_shared<const Advanced>(s));
        FrameGeometry g;g.width=w;g.height=h;g.time=13.5;
        configureFrame(g,p,scenario==3?HalationPreset::Medium:HalationPreset::Off);
        auto reader=[&](int x,int y)->const float*{return x<0||x>=w||y<0||y>=h?nullptr:&src[(static_cast<std::size_t>(y)*w+x)*4];};
        std::vector<double> times;
        for(int repeat=0;repeat<repeats+1;++repeat){auto start=std::chrono::steady_clock::now();
            FrameEngine engine(p,g,reader,!fixture.empty());
#ifdef MENDES_PARALLEL_BENCH
            engine.build({0,0,w,h},{0,0,w,h},[]{return false;},exec);
            exec.rows(0,h,[&](int y){for(int x=0;x<w;++x)engine.pixel(reader(x,y),&dst[(static_cast<std::size_t>(y)*w+x)*4],x,y);return true;});
#else
            engine.build({0,0,w,h},{0,0,w,h},[]{return false;});
            for(int y=0;y<h;++y)for(int x=0;x<w;++x)engine.pixel(reader(x,y),&dst[(static_cast<std::size_t>(y)*w+x)*4],x,y);
#endif
            const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
            if(repeat)times.push_back(ms);
        }
        std::sort(times.begin(),times.end());double sum=0;for(float v:dst)sum+=v;
        std::cout<<w<<'x'<<h<<" scenario="<<scenario<<" median_ms="<<std::fixed<<std::setprecision(3)<<times[times.size()/2]<<" checksum="<<std::setprecision(9)<<sum<<std::endl;
        if(gold)gold.write(reinterpret_cast<const char*>(dst.data()),static_cast<std::streamsize>(dst.size()*sizeof(float)));
    }
}
