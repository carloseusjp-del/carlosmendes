"""Embed the original OpenCL engine and authoritative parameter indices."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
spec=(root/'src/advanced_specs.hpp').read_text()
ids=re.search(r'enum class AdvId \{(.*?)\};',spec,re.S).group(1).split(',')
prefix=''.join(f'#define {name.strip()} {index}\n' for index,name in enumerate(ids) if name.strip()!='Count')
source=prefix+(root/'assets/kernels/mendes.cl').read_text()
# Double coordinates are intentional: grain must be stable at 4K and at ROI origins.
target=root/'build/generated/gpu_kernel.hpp';target.parent.mkdir(parents=True,exist_ok=True)
target.write_text('#pragma once\nnamespace mendes { inline constexpr const char* kGpuKernel=R"MENDESCL(\n'+source+'\n)MENDESCL"; }\n')
print('Embedded original OpenCL engine:',len(source),'bytes')
