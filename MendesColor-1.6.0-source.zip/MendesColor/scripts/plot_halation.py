"""Plot the synthetic C++ engine output; optional preview needs matplotlib."""
from pathlib import Path
import os
root = Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR', str(root / 'build/matplotlib-config'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

fig, axes = plt.subplots(2, 2, figsize=(12, 7), facecolor='#101622')
fig.suptitle('Mendes Color — Halation', color='#f2f5fb', fontsize=21, y=0.98)
for index, (axis, label) in enumerate(zip(axes.flat, ['Desligado', 'Mínimo', 'Médio', 'Alto'])):
    axis.imshow(plt.imread(root / f'build/halation-preview/{index}.ppm'), interpolation='nearest')
    axis.set_title(label, color='#f2f5fb', fontsize=15, loc='left', pad=10)
    axis.set_axis_off()
fig.text(0.05, 0.03, 'Recortes sintéticos de uma imagem Rec.709 • Tamanho de referência: 1080 linhas\n'
         'Calculado pelo motor C++; não é filmagem, emulação calibrada ou garantia de aparência no monitor.',
         color='#aebbd0', fontsize=10, linespacing=1.6)
fig.subplots_adjust(left=0.05, right=0.95, bottom=0.13, top=0.88, hspace=0.28, wspace=0.08)
fig.savefig(root / 'docs/HALATION-preview.png', dpi=140, facecolor=fig.get_facecolor())
plt.close(fig)
print('Generated docs/HALATION-preview.png')
