#include "halation.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 2) return 1;
    std::filesystem::create_directories(argv[1]);
    constexpr int width = 420, height = 220;
    auto image = [](int x, int y) -> mendes::RGB {
        if (x >= 75 && x < 145 && y >= 52 && y < 167) return {0.98, 0.98, 0.98};
        const int dx = x - 287, dy = y - 109;
        if (dx * dx + dy * dy < 31 * 31) return {1, 0.96, 0.86};
        if (x >= 173 && x < 205 && y >= 69 && y < 151) return {0.28, 0.30, 0.32};
        return {0.035, 0.035, 0.035};
    };
    for (int preset = 0; preset < 4; ++preset) {
        const auto plan = mendes::halationPlan(static_cast<mendes::HalationPreset>(preset), 1080);
        mendes::HaloBuffer halo;
        halo.build({0, 0, width, height}, {0, 0, width, height}, plan,
            [&](int x, int y) { return mendes::halationEmission(image(x, y), 1); }, [] { return false; });
        std::ofstream out(std::filesystem::path(argv[1]) / (std::to_string(preset) + ".ppm"), std::ios::binary);
        out << "P6\n" << width << ' ' << height << "\n255\n";
        for (int y = 0; y < height; ++y) for (int x = 0; x < width; ++x) {
            const auto rgb = image(x, y);
            const auto add = mendes::halationColor(halo.at(x, y), mendes::halationEmission(rgb, 1), plan);
            for (int c = 0; c < 3; ++c) out.put(static_cast<char>(std::lround(std::clamp(rgb[c] + add[c], 0.0, 1.0) * 255)));
        }
        if (!out) return 1;
    }
    std::cout << "Generated four synthetic halation crops at 1080-line reference size\n";
}
