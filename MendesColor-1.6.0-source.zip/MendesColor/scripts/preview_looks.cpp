#include "pipeline.hpp"
#include "avata2_lut.hpp"
#include "version.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

namespace {
std::string escape(std::string value) {
    std::string result;
    for (char c : value) result += c == '&' ? "&amp;" : std::string(1, c);
    return result;
}
std::string color(mendes::RGB rgb) {
    std::ostringstream s; s << '#' << std::hex << std::setfill('0');
    for (double v : rgb) s << std::setw(2) << static_cast<int>(std::lround(std::clamp(v, 0.0, 1.0) * 255));
    return s.str();
}
}
int main(int argc, char** argv) {
    if (argc != 2) return 1;
    std::ofstream out(argv[1]);
    if (!out) return 1;
    const int columns = 3, width = 1060, tileWidth = 326, tileHeight = 150;
    const int rows = (static_cast<int>(mendes::kLookCount) + columns - 1) / columns;
    const int height = 150 + rows * (tileHeight + 16);
    out << "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"" << width << "\" height=\"" << height
        << "\" viewBox=\"0 0 " << width << ' ' << height << "\">\n"
        << "<rect width=\"100%\" height=\"100%\" fill=\"#101622\"/>\n"
        << "<g font-family=\"Arial, sans-serif\" fill=\"#f2f5fb\">\n"
        << "<text x=\"26\" y=\"38\" font-size=\"26\">Mendes Color " MENDES_COLOR_VERSION " — looks</text>\n"
        << "<text x=\"26\" y=\"65\" font-size=\"14\">LUT Avata 2 primeiro · Look Strength 1 · comparação de cores sintéticas</text>\n"
        << "<text x=\"26\" y=\"88\" font-size=\"13\" fill=\"#aebbd0\">Prévia aproximada para comparar estilos; não é filmagem nem prova de colorimetria.</text>\n";
    const mendes::RGB samples[] = {{0.48,0.36,0.28},{0.65,0.49,0.37},{0.33,0.50,0.35},
                                  {0.25,0.43,0.65},{0.70,0.50,0.22},{0.55,0.25,0.30}};
    for (std::size_t index = 0; index < mendes::kLookCount; ++index) {
        const int x = 26 + static_cast<int>(index % columns) * (tileWidth + 16);
        const int y = 115 + static_cast<int>(index / columns) * (tileHeight + 16);
        mendes::Controls c; c.look = static_cast<mendes::Look>(index);
        mendes::Pipeline pipeline(c, mendes::avata2Cube());
        out << "<rect x=\"" << x << "\" y=\"" << y << "\" width=\"" << tileWidth
            << "\" height=\"" << tileHeight << "\" rx=\"8\" fill=\"#1c2738\"/>\n"
            << "<text x=\"" << x+14 << "\" y=\"" << y+27 << "\" font-size=\"18\">"
            << escape(mendes::kLooks[index].name) << "</text>\n";
        for (int step = 0; step < 100; ++step) {
            const double v = step / 99.0;
            out << "<rect x=\"" << x+14+step*3 << "\" y=\"" << y+42
                << "\" width=\"3.1\" height=\"28\" fill=\"" << color(pipeline.apply({v,v,v})) << "\"/>\n";
        }
        for (int sample = 0; sample < 6; ++sample)
            out << "<rect x=\"" << x+14+sample*50 << "\" y=\"" << y+80
                << "\" width=\"46\" height=\"34\" rx=\"3\" fill=\"" << color(pipeline.apply(samples[sample])) << "\"/>\n";
        out << "<text x=\"" << x+14 << "\" y=\"" << y+136
            << "\" font-size=\"12\" fill=\"#aebbd0\">Rampa neutra + amostras de cor</text>\n";
    }
    out << "</g></svg>\n";
    if (!out) return 1;
    std::cout << "Generated synthetic look comparison: " << argv[1] << '\n';
}
