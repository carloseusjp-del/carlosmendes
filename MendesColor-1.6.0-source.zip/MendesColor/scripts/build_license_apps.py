"""Build the branded Windows activation and administrative licensing applications."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--compiler", default="x86_64-w64-mingw32-g++")
parser.add_argument("--windres", default="x86_64-w64-mingw32-windres")
args = parser.parse_args()

root = Path(__file__).resolve().parents[1]
build = root / "build/license-apps"
dist = root / "dist"
build.mkdir(parents=True, exist_ok=True)
dist.mkdir(exist_ok=True)
version = re.search(
    r'^#define MENDES_COLOR_VERSION "([0-9]+\.[0-9]+\.[0-9]+)"$',
    (root / "src/version.hpp").read_text(),
    re.MULTILINE,
).group(1)


def compile_app(name: str, source: Path, description: str, administrative: bool) -> Path:
    manifest = build / f"{name}.manifest"
    manifest.write_text(
        f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity version="{version}.0" processorArchitecture="amd64" name="MendesColor.{name}" type="win32"/>
  <description>{description}</description>
  <dependency><dependentAssembly><assemblyIdentity type="win32" name="Microsoft.Windows.Common-Controls" version="6.0.0.0" processorArchitecture="*" publicKeyToken="6595b64144ccf1df" language="*"/></dependentAssembly></dependency>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3"><security><requestedPrivileges>
    <requestedExecutionLevel level="asInvoker" uiAccess="false"/>
  </requestedPrivileges></security></trustInfo>
</assembly>
''',
        encoding="utf-8",
    )
    rc = build / f"{name}.rc"
    rc.write_text(
        '#include <windows.h>\n'
        + f'1 RT_MANIFEST "{manifest.as_posix()}"\n'
        + f'1 ICON "{(root / "assets/branding/MendesColor.ico").as_posix()}"\n',
        encoding="utf-8",
    )
    resource = build / f"{name}-res.o"
    subprocess.run(
        [
            args.windres,
            "--preprocessor",
            args.compiler,
            "--preprocessor-arg=-E",
            "--preprocessor-arg=-xc",
            "--preprocessor-arg=-DRC_INVOKED",
            "-i",
            str(rc),
            "-O",
            "coff",
            "-o",
            str(resource),
        ],
        check=True,
    )
    output = dist / ("MendesColor-License-Studio-" + version + ".exe" if administrative else "MendesColorActivate.exe")
    includes = ["-I" + str(root / "src"), "-I" + str(root / "admin")]
    subprocess.run(
        [
            args.compiler,
            "-std=c++17",
            "-O2",
            "-Wall",
            "-Wextra",
            "-Wpedantic",
            "-Werror",
            "-static",
            "-static-libgcc",
            "-static-libstdc++",
            "-municode",
            "-mwindows",
            *includes,
            str(source),
            str(resource),
            "-o",
            str(output),
            "-Wl,--no-insert-timestamp",
            "-lbcrypt",
            "-ladvapi32",
            "-lcomctl32",
        ],
        check=True,
    )
    return output


activation = compile_app(
    "Activate", root / "activation/activate.cpp", "Mendes Color Offline Activation", False
)
studio = compile_app(
    "LicenseStudio",
    root / "admin/license_studio.cpp",
    "Mendes Color Administrative License Studio",
    True,
)
owner_kit = dist / f"MendesColor-Owner-Kit-{version}.zip"
with zipfile.ZipFile(owner_kit, "w", zipfile.ZIP_DEFLATED) as archive:
    for source, name in [
        (studio, studio.name),
        (root / "admin/README.md", "LEIA-ME-ADMIN.md"),
    ]:
        entry = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        archive.writestr(entry, source.read_bytes())
record = {
    "version": version,
    "activation": {
        "file": activation.name,
        "bytes": activation.stat().st_size,
        "sha256": hashlib.sha256(activation.read_bytes()).hexdigest(),
    },
    "studio": {
        "file": studio.name,
        "bytes": studio.stat().st_size,
        "sha256": hashlib.sha256(studio.read_bytes()).hexdigest(),
        "private_key_storage": "AES-256-GCM encrypted BCRYPT ECC private blob; PBKDF2-HMAC-SHA256",
    },
    "owner_kit": {
        "file": owner_kit.name,
        "bytes": owner_kit.stat().st_size,
        "sha256": hashlib.sha256(owner_kit.read_bytes()).hexdigest(),
        "contains_password": False,
    },
}
(build / "manifest.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record, indent=2))
