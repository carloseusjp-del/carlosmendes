"""Generate the embedded RGB table from the exact supplied .cube asset."""
import hashlib
import json
import math
from pathlib import Path

root = Path(__file__).resolve().parents[1]
folder = root / 'assets/luts'
provenance = json.loads((folder / 'PROVENANCE.json').read_text(encoding='utf-8'))
data = (folder / provenance['file']).read_bytes()
if hashlib.sha256(data).hexdigest() != provenance['sha256']:
    raise ValueError('Supplied LUT checksum changed; inspect and update its provenance first.')
rows = []
size = None
for line in data.decode('utf-8-sig').splitlines():
    text = line.strip()
    if not text or text.startswith('#'):
        continue
    if text.startswith('LUT_3D_SIZE'):
        if size is not None:
            raise ValueError('Duplicate LUT size')
        size = int(text.split()[1])
        continue
    values = tuple(float(v) for v in text.split())
    if len(values) != 3 or not all(math.isfinite(v) for v in values):
        raise ValueError('Invalid supplied LUT row')
    rows.append(values)
if size != 33 or len(rows) != size**3:
    raise ValueError('Expected the supplied 33x33x33 cube with implicit [0,1] domain.')
output = root / 'build/generated/avata2_lut.hpp'
output.parent.mkdir(parents=True, exist_ok=True)
lines = [
    '// Generated from assets/luts; do not edit. Source comments remain in the .cube.',
    '#pragma once', '#include "cube.hpp"', 'namespace mendes {',
    'inline constexpr const char* kAvata2LutSha256 = "' + provenance['sha256'] + '";',
    'inline const std::shared_ptr<const Cube3D>& avata2Cube() {',
    '    static constexpr RGB values[] = {',
]
lines += ['        {' + ', '.join(repr(v) for v in row) + '},' for row in rows]
lines += [
    '    };',
    '    static const auto cube = std::make_shared<const Cube3D>(',
    '        Cube3D::fromTable(33, values, sizeof(values) / sizeof(values[0])));',
    '    return cube;', '}', '} // namespace mendes', '',
]
text = '\n'.join(lines)
if not output.exists() or output.read_text(encoding='utf-8') != text:
    output.write_text(text, encoding='utf-8')
print('Embedded LUT generated:', len(rows), 'RGB entries; SHA-256', provenance['sha256'])
