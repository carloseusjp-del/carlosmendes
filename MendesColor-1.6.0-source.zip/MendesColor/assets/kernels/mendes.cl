// Original Mendes Color OpenCL 1.2 engine. No vendor plugin code or LUTs.
#pragma OPENCL FP_CONTRACT OFF
#ifdef cl_khr_fp64
#pragma OPENCL EXTENSION cl_khr_fp64 : enable
typedef double real; typedef double2 real2;
#else
typedef float real; typedef float2 real2;
#endif
#define V(id) p[id]
float lum(float3 a){return .2126f*a.x+.7152f*a.y+.0722f*a.z;}
float sm(float a,float b,float x){float t=clamp((x-a)/fmax(b-a,1e-9f),0.f,1.f);return t*t*(3.f-2.f*t);}
float3 sat(float3 a,float s){float y=lum(a);return y+s*(a-y);}
float3 blend3(float3 a,float3 b,float t){return a+t*(b-a);}
float power(float x,float e){return copysign(pow(fabs(x),e),x);}
float3 hsv3(float3 a){float hi=fmax(a.x,fmax(a.y,a.z)),lo=fmin(a.x,fmin(a.y,a.z)),d=hi-lo,h=0;
 if(d>1e-12f){if(hi==a.x)h=60.f*fmod((a.y-a.z)/d,6.f);else if(hi==a.y)h=60.f*((a.z-a.x)/d+2.f);else h=60.f*((a.x-a.y)/d+4.f);}if(h<0)h+=360;return (float3)(h,hi>1e-12f?d/hi:0,hi);}
float hueDist(float a,float b){float d=fmod(fabs(a-b),360.f);return fmin(d,360.f-d);}
float3 hue(float angle){float h=fmod(fmod(angle,360.f)+360.f,360.f)/60.f,x=1-fabs(fmod(h,2.f)-1);
 if(h<1)return(float3)(1,x,0);if(h<2)return(float3)(x,1,0);if(h<3)return(float3)(0,1,x);if(h<4)return(float3)(0,x,1);if(h<5)return(float3)(x,0,1);return(float3)(1,0,x);}
float3 rotate3(float3 v,float degrees){float3 u=(float3)(.7071067811865475f,-.7071067811865475f,0),w=(float3)(.408248290463863f,.408248290463863f,-.816496580927726f);
 float a=dot(v,u),b=dot(v,w),angle=degrees*.017453292519943295f,co=cos(angle),si=sin(angle);return v+(a*co-b*si-a)*u+(a*si+b*co-b)*w;}
float3 lut(__global const float4* data,float3 rgb){int n=(int)data[0].x,m=(int)data[0].y;if(n==0||!all(isfinite(rgb)))return rgb;
 int3 lo;float3 f;
 for(int c=0;c<3;c++){float x=clamp((rgb[c]-data[1][c])/(data[2][c]-data[1][c]),0.f,1.f),t=x*(n-1);
  if(m){int a=0,b=m;while(a<b){int mid=(a+b)/2;if(x<data[3+mid].x)b=mid;else a=mid+1;}
   t=a==0?0:a==m?n-1:a-1+(x-data[3+a-1].x)/(data[3+a].x-data[3+a-1].x);}
  lo[c]=min((int)t,n-2);f[c]=t-lo[c];}
 float3 out=(float3)(0);int start=3+m;
 for(int b=0;b<2;b++)for(int g=0;g<2;g++)for(int r=0;r<2;r++){
  float wt=(r?f.x:1-f.x)*(g?f.y:1-f.y)*(b?f.z:1-f.z);out+=wt*data[start+((lo.z+b)*n+lo.y+g)*n+lo.x+r].xyz;}return out;}
float3 gradeRecipe(float3 v,__constant const float* p,int offset){float3 gain=vload3(0,p+offset),sh=vload3(0,p+offset+5),hi=vload3(0,p+offset+8);
 for(int c=0;c<3;c++){float x=(v[c]-p[135])/(p[136]-p[135]);x*=gain[c];x=(x-p[130])*p[offset+3]+p[130];v[c]=p[131]==1?x:power(x,1.f/p[131]);}
 if(p[offset+13]){float y=lum(v),s=(1-sm(.05f,.70f,y))*fmax(0.f,y),h=sm(.25f,1.10f,y)*fmax(0.f,y);
  v+=sh*s+hi*h;for(int c=0;c<3;c++){if(p[offset+12]>0&&v[c]>p[130]){float d=v[c]-p[130];v[c]=p[130]+d/(1+p[offset+12]*d);}if(p[offset+11]>0)v[c]=v[c]*(1-p[offset+11])+p[offset+11];}}
 return sat(v,p[offset+4]);}
float3 grade(float3 v,__constant const float* p){if(p[140])return v;float3 out=gradeRecipe(v,p,p[138]==0?144:164);if(p[139]!=0&&p[138]>0&&p[138]<1)out=blend3(gradeRecipe(v,p,144),out,p[138]);return out;}
// Standards-based optional primaries/transfer conversions, relative to 203 nits.
float pqD(float v){double x=fabs((double)v);if(x>1)return (float)copysign((10000+(x-1)*95541.8)/203,(double)v);double q=pow(x,32.0/2523),n=fmax(q-3424.0/4096,0.0)/(2413.0/128-2392.0/128*q);return (float)copysign(10000.0/203*pow(n,16384.0/2610),(double)v);}
float pqE(float v){double n=fabs((double)v)*203;if(n>10000)return (float)copysign(1+(n-10000)/95541.8,(double)v);double q=pow(n/10000,2610.0/16384);return (float)copysign(pow((3424.0/4096+2413.0/128*q)/(1+2392.0/128*q),2523.0/32),(double)v);}
float transferD(float v,int gamma){float x=fabs(v);switch(gamma){case 0:return power(v,2.4f);case 1:return power(v,2.2f);case 2:return power(v,1.96f);case 3:return copysign(x<=.04045f?x/12.92f:pow((x+.055f)/1.055f,2.4f),v);case 4:return v;case 5:return pqD(v);default:return copysign(x<=.5f?x*x/3:(exp((x-.55991073f)/.17883277f)+.28466892f)/12,v);}}
float transferE(float v,int gamma){float x=fabs(v);switch(gamma){case 0:return power(v,1.f/2.4f);case 1:return power(v,1.f/2.2f);case 2:return power(v,1.f/1.96f);case 3:return copysign(x<=.0031308f?x*12.92f:1.055f*pow(x,1.f/2.4f)-.055f,v);case 4:return v;case 5:return pqE(v);default:return copysign(x<=1.f/12?sqrt(3*x):.17883277f*log(12*x-.28466892f)+.55991073f,v);}}
float3 matrix3(float3 v,__constant const float* p,int offset){return(float3)(dot(v,vload3(0,p+offset)),dot(v,vload3(0,p+offset+3)),dot(v,vload3(0,p+offset+6)));}
float3 conversion(float3 v,__constant const float* p,int output){int space=(int)(output?V(OutputColorSpace):V(InputColorSpace)),gamma=(int)(output?V(ConversionOutput):V(InputGamma));if(!V(ColorSpaceEnable)||(space==0&&gamma==0))return v;
 if(output){for(int c=0;c<3;c++)v[c]=power(v[c],2.4f);v=matrix3(v,p,359);
  if(space!=1&&gamma==6){float dy=fmax(fabs(dot(v,vload3(0,p+371))),1e-15f),sy=pow(dy/(1000.f/203.f),1.f/1.2f),gain=1000.f/203.f*pow(sy,.2f);v/=gain;}
  for(int c=0;c<3;c++)v[c]=space==1?(v[c]<=.00262409f?v[c]*10.44426855f:(log2(v[c]+.0075f)+7)*.07329248f):transferE(v[c],gamma);
 }else{for(int c=0;c<3;c++)v[c]=space==1?(v[c]<=.02740668f?v[c]/10.44426855f:exp2(v[c]/.07329248f-7)-.0075f):transferD(v[c],gamma);
  if(space!=1&&gamma==6)v*=1000.f/203.f*pow(fmax(fabs(dot(v,vload3(0,p+368))),1e-15f),.2f);
  v=matrix3(v,p,350);for(int c=0;c<3;c++)v[c]=power(v[c],1.f/2.4f);}
 return v;}
__constant float finishR[18][9]={
 {1,1,0,0,0,0,0,0,0},{0,1.08,0,-.01,0,.025,0,0,.01},{1.12,1.12,-.08,-.04,.01,.09,0,0,0},
 {.72,1.08,-.1,-.015,.01,.045,0,0,0},{1.02,1.08,-.03,-.035,.04,.055,.03,.01,-.015},{.90,1.08,-.02,0,.02,.01,-.02,.05,-.01},
 {1.2,1.08,0,0,.025,0,-.02,.06,-.025},{.68,.93,-.02,.01,.035,.01,0,0,0},{.88,1.04,.12,.02,.035,-.015,.04,.025,-.04},
 {.80,1.18,-.04,-.02,.04,-.01,0,0,0},{1.08,1.06,.24,.01,0,-.02,.08,.035,-.06},{.9,1.08,.08,.07,-.01,-.02,0,0,0},
 {.75,.96,.10,.025,.005,.015,.035,.01,-.035},{.42,1.20,-.16,-.04,.01,.08,0,0,0},{.94,1.12,-.04,-.02,.055,.005,.02,.02,-.015},
 {.76,1.04,.04,.015,.04,-.02,0,0,0},{.65,1.24,-.10,-.03,.04,.05,0,0,0},{.70,.92,.13,.035,.01,.025,.04,.015,-.03}};
float3 colors(float3 v,__constant const float* p,__global const float4* custom){float3 in=v;
 if(V(BasicEnable)){float gain=exp2(V(Exposure)+V(Gain)/100),lift=V(Lift)/400,gamma=exp2(-V(Gamma)/100),temp=V(Temperature)/100,tint=V(Tint)/100;
  float3 gains=(float3)(exp2(temp*.35f+tint*.12f),exp2(-tint*.24f),exp2(-temp*.35f+tint*.12f));
  for(int c=0;c<3;c++){v[c]+=lift*(1-v[c]);v[c]=power(v[c],gamma)*gain*gains[c];}
  float high=exp2(V(Highlights)/200*sm(.35f,1.2f,lum(v)));v=(v*high-.18f)*V(Contrast)+.18f;v=sat(v,V(Saturation));
  float richness=V(ColourRichness)/100,s=clamp(hsv3(v).y,0.f,1.f);v=sat(v,1+richness*.35f*(1-s));float density=exp2(-richness*s*.20f),fade=V(Fade)/100*.12f;v=v*density*(1-fade)+fade;
  v=blend3(v,(sat(v,.12f)-.18f)*1.30f+.18f,V(BleachBypass)/100);v=blend3(in,v,V(BasicIntensity)/100);}
 if(V(BwEnable)){in=v;float black=V(BlackPoint)/100,white=1+V(WhitePoint)/100,den=fmax(.02f,white-black);int mode=(int)V(ColorMode);
  if(mode==1)v=(v-black)/den;else if(mode==2){float y=lum(v),mapped=(y-black)/den;v=fabs(y)>1e-9f?v*(mapped/y):v+mapped-y;}else{float shadow=1-sm(0,1,lum(v));v=v-black*shadow+(1-white)*(1-shadow);}v=blend3(in,v,V(BwIntensity)/100);}
 if(custom[0].x)v=blend3(v,lut(custom,v),V(CustomIntensity)/100);
 if(V(FinishingTones)){int i=(int)V(FinishingTones);__constant float* r=finishR[i];in=v;v=sat(v,r[0]);float y=lum(v),sh=1-sm(.08f,.70f,y),hi=sm(.3f,1,y);for(int c=0;c<3;c++)v[c]=((v[c]-.18f)*r[1]+.18f)*exp2((c==0?1:c==2?-1:0)*r[2]*.35f)+fmax(0.f,y)*(r[3+c]*sh+r[6+c]*hi);v=blend3(in,v,V(FinishingIntensity)/100);}
 if(V(SplitToningEnable)){in=v;float3 hi=hue(V(SplitHueAngle)),lo=hue(V(SplitHueAngle)+180);float y=lum(v),pivot=V(SplitPivot),high=sm(pivot-.22f,pivot+.22f,y),prot=(V(SplitProtectNeutrals)!=0)?sm(.01f,.25f,hsv3(v).y):1,amt=V(SplitAmount)*prot*fmax(0.f,y);
  v+=amt*((hi-lum(hi))*high+(lo-lum(lo))*(1-high));v=blend3(in,v,V(SplitIntensity)/100);}
 if(V(SkinEnable)){float3 h=hsv3(v);float y=lum(v),range=V(SkinRange),width=V(SkinBrightnessRange)*.5f,mask=(1-sm(range*.45f,range,hueDist(h.x,25+V(SkinCenter))))*(1-sm(width*.55f,width,fabs(y-V(SkinBrightness))))*sm(.02f,.20f,h.y);
  if(V(ShowSkinSelection))v=(float3)(mask);else v=blend3(v,sat(rotate3(v,V(SkinPop)),1+V(SkinSaturate))*exp2(V(SkinColour)),mask*V(SkinIntensity)/100);}
 if(V(ColorIntensityEnable)){int channels[6]={ColorIntensityRed,ColorIntensityYellow,ColorIntensityGreen,ColorIntensityCyan,ColorIntensityBlue,ColorIntensityMagenta};float h=hsv3(v).x,adjust=0;for(int i=0;i<6;i++)adjust+=fmax(0.f,1-hueDist(h,i*60)/60)*p[channels[i]];
  float amount=fmax(0.f,V(ColorIntensityGlobal)*(1+adjust)),high=(V(ColorIntensityHighlight)!=0)?sm(.25f,.9f,lum(v)):1;v=blend3(v,sat(v,amount),high*V(ColorIntensityIntensity)/100);}
 return v;}
real2 coords(int x,int y,__global const double* g){return(real2)(((real)x+.5)*(real)g[6]/(real)g[4]-(real)g[0],((real)y+.5)/(real)g[5]-(real)g[1]);}
float3 position3(float3 v,int x,int y,__constant const float* p,__global const double* g){if(!V(VignetteEnable))return v;real2 xy=coords(x,y,g);float xx=((float)(xy.x/(real)g[2])*2-1-V(VignetteCenterX))*exp2(-V(VignetteAspectRatio)),yy=((float)(xy.y/(real)g[3])*2-1-V(VignetteCenterY))*exp2(V(VignetteAspectRatio));
 float r=hypot(xx,yy),start=V(VignetteSize)/100,feather=V(VignetteFeather)/100*1.4f,mask=feather==0?(r>=start?1:0):sm(start,start+feather,r);return (V(VignetteMaskMode)!=0)?(float3)(mask):v*exp2(V(VignetteExposure)*mask*V(VignetteIntensity)/100);}
uint hash32(uint x){x^=x>>16;x*=0x7feb352dU;x^=x>>15;x*=0x846ca68bU;x^=x>>16;return x;}
real random2(long x,long y,uint seed){return (real)hash32((uint)x*0x9e3779b9U ^ (uint)y*0x85ebca6bU ^ seed)/(real)4294967295.0*2-1;}
real noise2(real x,real y,uint seed){x=fmod(x,(real)1048576);y=fmod(y,(real)1048576);long ix=(long)floor(x),iy=(long)floor(y);real fx=x-floor(x),fy=y-floor(y),tx=fx*fx*(3-2*fx),ty=fy*fy*(3-2*fy);return(random2(ix,iy,seed)*(1-tx)+random2(ix+1,iy,seed)*tx)*(1-ty)+(random2(ix,iy+1,seed)*(1-tx)+random2(ix+1,iy+1,seed)*tx)*ty;}
float3 grain3(float3 v,int x,int y,__constant const float* p,__global const double* g){if(!V(GrainEnable)||!V(GrainIntensity))return v;float yv=clamp(lum(v),0.f,1.f),low=(1-yv)*(1-yv),high=yv*yv,mid=4*yv*(1-yv),zone=(low*V(GrainShadows)+mid*V(GrainMidtones)+high*V(GrainHighlights))/100,amount=.08f*V(GrainAmount)/100*V(GrainIntensity)/100*zone;
 real scale=(real)g[10],co=(real)g[8],si=(real)g[9];real2 xy=coords(x,y,g)*(real)1080/(real)g[3];real xx=(xy.x*co-xy.y*si)/scale,yy=(xy.x*si+xy.y*co)/scale;uint frame=(uint)((long)floor(fmod(g[7],1e9)));real mono=noise2(xx,yy,hash32(frame+12345));float color=(V(GrainIsColored)!=0)?V(GrainColor)/100:0;
 for(int c=0;c<3;c++)v[c]+=amount*((1-color)*(float)mono+color*(float)noise2(xx,yy,hash32(frame+(uint)c*3299+8171)));return v;}
float emission(float4 a,__constant const float* p){if(!isfinite(a.w)||a.w<=0||!all(isfinite(a.xyz)))return 0;float y=lum(a.xyz);float mask=(p[205]!=0)?sm(.35f+.55f*V(HalationSourceLimiter)/100,.35f+.55f*V(HalationSourceLimiter)/100+.04f+.30f*V(HalationSmoothness)/100,y):sm(.65f,.95f,y);return mask*clamp(y,0.f,4.f)*fmin(a.w,1.f);}
float3 addHalo(float4 a,float nearHalo,float farHalo,__constant const float* p){float e=emission(a,p);if(!p[205])return a.xyz+(float3)(1,.23f,.04f)*fmax(0.f,nearHalo-e)*p[204];float bg=1-sm(V(HalationBackgroundGain)/150,V(HalationBackgroundGain)/150+.45f,lum(a.xyz));float energy=(fmax(0.f,nearHalo-e)+.35f*fmax(0.f,farHalo-e))*bg*.20f*exp2(V(HalationAmplify)/25-2)*V(HalationImpact)/100;
 float3 add=(float3)(energy,energy*(.03f+.5f*V(HalationHue)/100),energy*(.02f-.05f*V(HalationBlueComp)/100*clamp(a.z,0.f,1.f)));return (V(HalationMaskMode)!=0)?add:a.xyz+add;}
float3 bloomEmit(float4 a,__constant const float* p){if(!isfinite(a.w)||a.w<=0||!all(isfinite(a.xyz)))return(float3)(0);float th=V(BloomHighlights)*.006f+V(BloomSourceLimiter)*.003f,mask=sm(th,th+.05f+.25f*(1-V(BloomDetails)/100),lum(a.xyz))*fmin(a.w,1.f);return clamp(a.xyz,0.f,4.f)*mask;}
float3 finish(float3 result,float4 src,__constant const float* p){float3 in=src.xyz;if(p[203]&&src.w!=0)in/=src.w;result=conversion(result,p,1);if(p[137]!=1)result=blend3(in,result,p[137]);return result*((p[203]!=0)?src.w:1);}
__kernel void base(__global const float4* src,__global float4* dst,__constant const float* p,__global const double* g,__global const float4* technical,__global const float4* custom,int final){int i=get_global_id(0),n=(int)p[201]*(int)p[202];if(i>=n)return;float4 s=src[i];float3 v=s.xyz;
 if(s.w==0)v=(float3)(0);else{if(p[203])v/=s.w;v=(technical[0].x!=0)?lut(technical,v):conversion(v,p,0);if(technical[0].x&&p[206])for(int c=0;c<3;c++){float a=fabs(v[c]),linear=a<.081f?a/4.5f:pow((a+.099f)/1.099f,1.f/.45f);v[c]=copysign(pow(linear,1.f/2.4f),v[c]);}v=colors(grade(v,p),p,custom);}
 int x=i%(int)p[201]+(int)p[207],y=i/(int)p[201]+(int)p[208];if(s.w!=0)v=position3(v,x,y,p,g);if(final){v=grain3(v,x,y,p,g);v=finish(v,s,p);if(p[203]&&s.w==0)v=(float3)(0);}dst[i]=(float4)(v,s.w);}
__kernel void prepare(__global const float4* src,__global float4* dst,__constant const float* p,int mode){int i=get_global_id(0);if(i>=(int)p[201]*(int)p[202])return;float4 a=src[i];float alpha=isfinite(a.w)?clamp(a.w,0.f,1.f):0;if(mode==0)dst[i]=(float4)(select((float3)(0),a.xyz,isfinite(a.xyz))*alpha,alpha);else if(mode==1)dst[i]=(float4)(emission(a,p),0,0,0);else dst[i]=(float4)(bloomEmit(a,p),0);}
// Sliding sums: bounded work per pixel, independent of diffusion radius.
__kernel void box(__global const float4* src,__global float4* dst,int width,int height,int radius,int horizontal,int nonnegative){int line=get_global_id(0),length=horizontal?width:height,lines=horizontal?height:width;if(line>=lines)return;int stride=horizontal?1:width,start=horizontal?line*width:line;double4 sum=(double4)(0);for(int j=0;j<=radius&&j<length;j++)sum+=convert_double4(src[start+j*stride]);double norm=1.0/(2*radius+1);for(int j=0;j<length;j++){float4 val=convert_float4(sum*norm);dst[start+j*stride]=nonnegative?fmax(val,0.f):val;if(j>=radius)sum-=convert_double4(src[start+(j-radius)*stride]);if(j+radius+1<length)sum+=convert_double4(src[start+(j+radius+1)*stride]);}}
__kernel void grained(__global const float4* src,__global const float4* soft,__global float4* dst,__constant const float* p,__global const double* g,int enabled){int i=get_global_id(0);if(i>=(int)p[201]*(int)p[202])return;float4 a=src[i],b=soft[i];if(enabled&&b.w>1e-9f)a.xyz=blend3(a.xyz,b.xyz/b.w,V(GrainBlur)/100*V(GrainIntensity)/100);int x=i%(int)p[201]+(int)p[207],y=i/(int)p[201]+(int)p[208];a.xyz=grain3(a.xyz,x,y,p,g);dst[i]=a;}
__kernel void halated(__global const float4* src,__global const float4* nearHalo,__global const float4* farHalo,__global float4* dst,__constant const float* p){int i=get_global_id(0);if(i>=(int)p[201]*(int)p[202])return;float4 a=src[i];a.xyz=addHalo(a,nearHalo[i].x,farHalo[i].x,p);dst[i]=a;}
__kernel void final(__global const float4* src,__global const float4* processed,__global const float4* blurred,__global float4* dst,__constant const float* p,int bloom){int i=get_global_id(0);if(i>=(int)p[201]*(int)p[202])return;float4 original=src[i],a=processed[i];if(bloom){float3 b=fmax(0.f,blurred[i].xyz-V(BloomDetails)/100*bloomEmit(a,p));b=sat(b,V(BloomSaturation)/100);float protect=1-V(BloomSaveLights)/100*sm(.4f,1,lum(a.xyz));b*=.8f*V(BloomAmplify)/100*V(BloomImpact)/100*protect;a.xyz=(V(BloomMaskMode)!=0)?b:a.xyz+b;}a.xyz=finish(a.xyz,original,p);if(p[203]&&original.w==0)a.xyz=(float3)(0);dst[i]=(float4)(a.xyz,original.w);}
// Tiled transpose makes both sliding-sum directions coalesced on a GPU.
// A spare stage buffer is reused; no additional full-frame VRAM allocation.
__kernel void transpose(__global const float4* src,__global float4* dst,int width,int height){
 __local float4 tile[16][17];int lx=get_local_id(0),ly=get_local_id(1);
 int x=get_group_id(0)*16+lx,y=get_group_id(1)*16+ly;
 tile[ly][lx]=(x<width&&y<height)?src[y*width+x]:(float4)(0);barrier(CLK_LOCAL_MEM_FENCE);
 x=get_group_id(1)*16+lx;y=get_group_id(0)*16+ly;
 if(x<height&&y<width)dst[y*height+x]=tile[lx][ly];
}
