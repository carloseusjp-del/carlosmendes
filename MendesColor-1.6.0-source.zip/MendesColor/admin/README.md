# Mendes License Studio

Este aplicativo é o painel do proprietário do Mendes Color. Guarde o
executável e a senha administrativa em backup privado. Não envie o Studio nem
a senha aos clientes.

Para emitir uma key:

1. Peça ao cliente o ID mostrado em **Ativar Mendes Color**.
2. Abra o Studio e informe a senha administrativa.
3. Preencha o nome do cliente e cole o ID completo `MC-...`.
4. Deixe a validade vazia para uma licença perpétua ou use `AAAA-MM-DD`.
5. Clique em **GERAR KEY**, copie a key e envie apenas ao cliente desse ID.

O histórico fica em
`%LOCALAPPDATA%\MendesColor\LicenseStudio\issued.csv`. Ele registra a impressão
digital da key, sem guardar a senha nem a chave privada em texto aberto.

O Studio trabalha offline. A chave privada embutida está cifrada e só é aberta
em memória quando a senha correta assina uma licença.
