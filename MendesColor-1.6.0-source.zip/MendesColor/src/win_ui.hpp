#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <cstring>
#include <cwchar>
#include <stdexcept>
#include <string>
#include <vector>

namespace mendes::winui {

inline HFONT font(int points, bool bold = false) {
    HDC screen = GetDC(nullptr);
    const int height = -MulDiv(points, GetDeviceCaps(screen, LOGPIXELSY), 72);
    ReleaseDC(nullptr, screen);
    return CreateFontW(height, 0, 0, 0, bold ? FW_SEMIBOLD : FW_NORMAL, FALSE, FALSE, FALSE,
                       DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                       DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
}

inline HWND control(HWND parent, const wchar_t *type, const wchar_t *text, DWORD style, int x, int y,
                    int width, int height, int id, HFONT fontHandle) {
    HWND result = CreateWindowExW(std::wcscmp(type, WC_EDITW) == 0 ? WS_EX_CLIENTEDGE : 0, type, text,
                                  WS_CHILD | WS_VISIBLE | style, x, y, width, height, parent,
                                  reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),
                                  GetModuleHandleW(nullptr), nullptr);
    if (!result)
        throw std::runtime_error("Não foi possível criar a interface.");
    SendMessageW(result, WM_SETFONT, reinterpret_cast<WPARAM>(fontHandle), TRUE);
    return result;
}

inline std::wstring text(HWND window) {
    const int size = GetWindowTextLengthW(window);
    std::wstring result(static_cast<std::size_t>(size) + 1, L'\0');
    if (size)
        GetWindowTextW(window, result.data(), size + 1);
    result.resize(static_cast<std::size_t>(size));
    return result;
}

inline void clipboard(HWND owner, const std::wstring &value) {
    if (!OpenClipboard(owner))
        throw std::runtime_error("Não foi possível abrir a área de transferência.");
    EmptyClipboard();
    const auto bytes = (value.size() + 1) * sizeof(wchar_t);
    HGLOBAL memory = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (!memory) {
        CloseClipboard();
        throw std::bad_alloc();
    }
    void *destination = GlobalLock(memory);
    std::memcpy(destination, value.c_str(), bytes);
    GlobalUnlock(memory);
    if (!SetClipboardData(CF_UNICODETEXT, memory)) {
        GlobalFree(memory);
        CloseClipboard();
        throw std::runtime_error("Não foi possível copiar o texto.");
    }
    CloseClipboard();
}

inline void center(HWND window) {
    RECT rectangle{};
    GetWindowRect(window, &rectangle);
    const int width = rectangle.right - rectangle.left;
    const int height = rectangle.bottom - rectangle.top;
    SetWindowPos(window, nullptr, (GetSystemMetrics(SM_CXSCREEN) - width) / 2,
                 (GetSystemMetrics(SM_CYSCREEN) - height) / 2, 0, 0,
                 SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}

inline HICON icon(HINSTANCE instance, int id, int size) {
    return static_cast<HICON>(LoadImageW(instance, MAKEINTRESOURCEW(id), IMAGE_ICON, size, size,
                                         LR_DEFAULTCOLOR));
}

} // namespace mendes::winui
