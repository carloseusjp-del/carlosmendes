#pragma once
#include "diagnostics.hpp"
#include "frame.hpp"
#include "gpu_kernel.hpp"
#define CL_TARGET_OPENCL_VERSION 120
#include <CL/cl.h>
#include <cstring>
#include <mutex>
#include <string>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#else
#include <dlfcn.h>
#endif

namespace mendes {
class GpuError : public std::runtime_error {
public:
  using std::runtime_error::runtime_error;
};
inline void gpuCheck(cl_int status, const char *operation) {
  if (status != CL_SUCCESS)
    throw GpuError(std::string(operation) + " (OpenCL " +
                   std::to_string(status) + ")");
}
struct OpenCLApi {
#ifdef _WIN32
  HMODULE library = nullptr;
#else
  void *library = nullptr;
#endif
#define GPU_API_LIST(F)                                                        \
  F(clGetPlatformIDs)                                                          \
  F(clGetDeviceIDs)                                                            \
  F(clGetDeviceInfo)                                                           \
  F(clCreateContext) F(clCreateCommandQueue) F(clCreateProgramWithSource)      \
      F(clBuildProgram) F(clGetProgramBuildInfo) F(clCreateKernel)             \
          F(clCreateBuffer) F(clSetKernelArg) F(clEnqueueWriteBuffer)          \
              F(clEnqueueReadBuffer) F(clEnqueueNDRangeKernel)                 \
                  F(clEnqueueCopyBuffer) F(clFinish) F(clReleaseMemObject)     \
                      F(clReleaseKernel) F(clReleaseProgram)                   \
                          F(clReleaseCommandQueue) F(clReleaseContext)
#define GPU_DECLARE(name) decltype(&::name) name = nullptr;
  GPU_API_LIST(GPU_DECLARE)
#undef GPU_DECLARE
  void load() {
    if (library)
      return;
#ifdef _WIN32
    library =
        LoadLibraryExW(L"OpenCL.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
#else
    library = dlopen("libOpenCL.so.1", RTLD_NOW | RTLD_LOCAL);
#endif
    if (!library)
      throw GpuError("OpenCL runtime unavailable");
#define GPU_LOAD(name)                                                         \
  {                                                                            \
    auto address = symbol(#name);                                              \
    static_assert(sizeof(address) == sizeof(name), "function pointer size");   \
    std::memcpy(&name, &address, sizeof(name));                                \
    if (!name)                                                                 \
      throw GpuError("OpenCL entry missing: " #name);                          \
  }
    GPU_API_LIST(GPU_LOAD)
#undef GPU_LOAD
  }
#ifdef _WIN32
  FARPROC symbol(const char *name) { return GetProcAddress(library, name); }
#else
  void *symbol(const char *name) { return dlsym(library, name); }
#endif
  ~OpenCLApi() {
    if (library) {
#ifdef _WIN32
      FreeLibrary(library);
#else
      dlclose(library);
#endif
    }
  }
};
#undef GPU_API_LIST

// One bounded device workspace/queue for all instances. Serialized submissions
// avoid competing per-frame contexts and unbounded VRAM growth in host
// prefetch.
class GpuRenderer {
  OpenCLApi api_;
  std::mutex mutex_;
  bool attempted_ = false, ready_ = false, allowCpu_ = false, reported_ = false;
  std::string status_;
  cl_device_id device_ = nullptr;
  cl_context context_ = nullptr;
  cl_command_queue queue_ = nullptr;
  cl_program program_ = nullptr;
  std::array<cl_kernel, 7> kernels_{};
  std::array<cl_mem, 7> frames_{};
  std::array<std::size_t, 7> capacities_{};
  cl_mem params_ = nullptr, geometry_ = nullptr;
  std::array<cl_mem, 2> luts_{};
  std::array<std::shared_ptr<const Cube3D>, 2> cubeRefs_{};
  std::vector<float> packed_, result_;
  cl_ulong maxAllocation_ = 0, globalMemory_ = 0;
  static constexpr const char *kernelNames_[7] = {
      "base", "prepare", "box", "grained", "halated", "final", "transpose"};
  std::string deviceString(cl_device_info field) {
    std::size_t bytes = 0;
    gpuCheck(api_.clGetDeviceInfo(device_, field, 0, nullptr, &bytes),
             "device metadata");
    std::string result(bytes, '\0');
    gpuCheck(
        api_.clGetDeviceInfo(device_, field, bytes, result.data(), nullptr),
        "device metadata");
    while (!result.empty() && result.back() == 0)
      result.pop_back();
    return result;
  }
  cl_mem allocate(std::size_t bytes) {
    cl_int status = 0;
    auto mem = api_.clCreateBuffer(context_, CL_MEM_READ_WRITE, bytes, nullptr,
                                   &status);
    gpuCheck(status, "device buffer allocation");
    return mem;
  }
  cl_mem buffer(int index, std::size_t bytes) {
    if (bytes > maxAllocation_ || bytes > globalMemory_ / 8)
      throw GpuError(
          "Insufficient GPU memory budget for this image; CPU fallback");
    std::size_t total = bytes;
    for (std::size_t k = 0; k < capacities_.size(); ++k)
      if (k != static_cast<std::size_t>(index))
        total += capacities_[k];
    const auto budget =
        std::min<cl_ulong>(globalMemory_ / 4, 1280ULL * 1024 * 1024);
    if (total > budget)
      throw GpuError(
          "GPU working buffers exceed bounded memory budget; CPU fallback");
    if (capacities_[index] < bytes) {
      if (frames_[index])
        api_.clReleaseMemObject(frames_[index]);
      frames_[index] = nullptr;
      capacities_[index] = 0;
      frames_[index] = allocate(bytes);
      capacities_[index] = bytes;
    }
    return frames_[index];
  }
  void write(cl_mem dst, std::size_t bytes, const void *data) {
    gpuCheck(api_.clEnqueueWriteBuffer(queue_, dst, CL_TRUE, 0, bytes, data, 0,
                                       nullptr, nullptr),
             "upload");
  }
  template <class T> void arg(cl_kernel kernel, int index, const T &value) {
    gpuCheck(api_.clSetKernelArg(kernel, index, sizeof(T), &value),
             "kernel argument");
  }
  template <class... Args>
  void launch(int kernel, std::size_t count, const Args &...values) {
    int index = 0;
    (arg(kernels_[kernel], index++, values), ...);
    gpuCheck(api_.clEnqueueNDRangeKernel(queue_, kernels_[kernel], 1, nullptr,
                                         &count, nullptr, 0, nullptr, nullptr),
             "kernel dispatch");
  }
  void transpose(cl_mem src, cl_mem dst, int width, int height) {
    arg(kernels_[6], 0, src);
    arg(kernels_[6], 1, dst);
    arg(kernels_[6], 2, width);
    arg(kernels_[6], 3, height);
    const std::size_t global[] = {
        ((static_cast<std::size_t>(width) + 15) / 16) * 16,
        ((static_cast<std::size_t>(height) + 15) / 16) * 16};
    const std::size_t local[] = {16, 16};
    gpuCheck(api_.clEnqueueNDRangeKernel(queue_, kernels_[6], 2, nullptr,
                                         global, local, 0, nullptr, nullptr),
             "tiled transpose");
  }
  void blur(cl_mem data, cl_mem scratch, int w, int h, HalationPlan plan,
            bool nonnegative, cl_mem spare) {
    for (int pass = 0; pass < 3; ++pass) {
      transpose(data, scratch, w, h);
      launch(2, static_cast<std::size_t>(h), scratch, spare, h, w, plan.radiusX,
             0, 0);
      transpose(spare, scratch, h, w);
      launch(2, static_cast<std::size_t>(w), scratch, data, w, h, plan.radiusY,
             0, nonnegative ? 1 : 0);
    }
  }
  void copy(cl_mem src, cl_mem dst, std::size_t bytes) {
    gpuCheck(api_.clEnqueueCopyBuffer(queue_, src, dst, 0, 0, bytes, 0, nullptr,
                                      nullptr),
             "device stage copy");
  }
  void cube(int index, std::shared_ptr<const Cube3D> value) {
    if (luts_[index] && cubeRefs_[index] == value)
      return;
    std::vector<float> data(12, 0);
    if (value) {
      data[0] = static_cast<float>(value->size());
      data[1] = static_cast<float>(value->mesh().size());
      for (int c = 0; c < 3; ++c) {
        data[4 + c] = static_cast<float>(value->domainMin()[c]);
        data[8 + c] = static_cast<float>(value->domainMax()[c]);
      }
      for (double x : value->mesh()) {
        data.push_back(static_cast<float>(x));
        data.insert(data.end(), 3, 0);
      }
      for (const auto &entry : value->table()) {
        for (double x : entry)
          data.push_back(static_cast<float>(x));
        data.push_back(0);
      }
    }
    if (luts_[index])
      api_.clReleaseMemObject(luts_[index]);
    luts_[index] = nullptr;
    cubeRefs_[index].reset();
    luts_[index] = allocate(data.size() * sizeof(float));
    write(luts_[index], data.size() * sizeof(float), data.data());
    cubeRefs_[index] = std::move(value);
  }
  void initialize() {
    attempted_ = true;
    api_.load();
    cl_uint count = 0;
    gpuCheck(api_.clGetPlatformIDs(0, nullptr, &count), "OpenCL platforms");
    std::vector<cl_platform_id> platforms(count);
    gpuCheck(api_.clGetPlatformIDs(count, platforms.data(), nullptr),
             "OpenCL platforms");
    int best = -1;
    for (auto platform : platforms) {
      cl_uint n = 0;
      const auto kind = allowCpu_ ? CL_DEVICE_TYPE_ALL : CL_DEVICE_TYPE_GPU;
      if (api_.clGetDeviceIDs(platform, kind, 0, nullptr, &n) != CL_SUCCESS)
        continue;
      std::vector<cl_device_id> devices(n);
      if (api_.clGetDeviceIDs(platform, kind, n, devices.data(), nullptr) !=
          CL_SUCCESS)
        continue;
      for (auto d : devices) {
        device_ = d;
        const auto extensions = deviceString(CL_DEVICE_EXTENSIONS);
        if (extensions.find("cl_khr_fp64") == std::string::npos)
          continue;
        cl_bool available = CL_FALSE, compiler = CL_FALSE;
        api_.clGetDeviceInfo(d, CL_DEVICE_AVAILABLE, sizeof(available),
                             &available, nullptr);
        api_.clGetDeviceInfo(d, CL_DEVICE_COMPILER_AVAILABLE, sizeof(compiler),
                             &compiler, nullptr);
        if (!available || !compiler)
          continue;
        const auto vendor = deviceString(CL_DEVICE_VENDOR);
        cl_device_type type = 0;
        api_.clGetDeviceInfo(d, CL_DEVICE_TYPE, sizeof(type), &type, nullptr);
        int score = (type & CL_DEVICE_TYPE_GPU) ? 100 : 1;
        if (vendor.find("NVIDIA") != std::string::npos)
          score += 100;
        if (score > best) {
          best = score;
          chosen_ = d;
        }
      }
    }
    device_ = chosen_;
    if (!device_)
      throw GpuError("No available OpenCL GPU with FP64 support");
    gpuCheck(api_.clGetDeviceInfo(device_, CL_DEVICE_MAX_MEM_ALLOC_SIZE,
                                  sizeof(maxAllocation_), &maxAllocation_,
                                  nullptr),
             "GPU allocation limit");
    gpuCheck(api_.clGetDeviceInfo(device_, CL_DEVICE_GLOBAL_MEM_SIZE,
                                  sizeof(globalMemory_), &globalMemory_,
                                  nullptr),
             "GPU memory size");
    cl_int code = 0;
    context_ =
        api_.clCreateContext(nullptr, 1, &device_, nullptr, nullptr, &code);
    gpuCheck(code, "GPU context");
    queue_ = api_.clCreateCommandQueue(context_, device_, 0, &code);
    gpuCheck(code, "GPU queue");
    const char *source = kGpuKernel;
    program_ =
        api_.clCreateProgramWithSource(context_, 1, &source, nullptr, &code);
    gpuCheck(code, "GPU program");
    code = api_.clBuildProgram(program_, 1, &device_, "-cl-std=CL1.2", nullptr,
                               nullptr);
    if (code != CL_SUCCESS) {
      std::size_t size = 0;
      api_.clGetProgramBuildInfo(program_, device_, CL_PROGRAM_BUILD_LOG, 0,
                                 nullptr, &size);
      std::string log(size, '\0');
      api_.clGetProgramBuildInfo(program_, device_, CL_PROGRAM_BUILD_LOG, size,
                                 log.data(), nullptr);
      throw GpuError("GPU kernel compilation: " + log);
    }
    for (int k = 0; k < 7; ++k) {
      kernels_[k] = api_.clCreateKernel(program_, kernelNames_[k], &code);
      gpuCheck(code, "GPU kernel");
    }
    params_ = allocate(512 * sizeof(float));
    geometry_ = allocate(11 * sizeof(double));
    ready_ = true;
    status_ = deviceString(CL_DEVICE_NAME);
    diagnostic("GPU OpenCL initialized", 0, status_.c_str());
  }
  cl_device_id chosen_ = nullptr;
  std::array<float, 512> configuration(const Pipeline &pipe,
                                       const FrameGeometry &g, int width,
                                       int height, int left, int bottom,
                                       bool premult) {
    std::array<float, 512> p{};
    const auto adv = pipe.advanced();
    const auto settings = adv ? adv->settings() : AdvSettings{};
    for (std::size_t i = 0; i < kAdvCount; ++i)
      p[i] = static_cast<float>(settings.values[i]);
    const auto &c = pipe.controls();
    const double values[] = {
        c.exposure,    c.contrast, c.pivot,        c.gamma,
        c.temperature, c.tint,     c.saturation,   c.black,
        c.white,       c.mix,      c.lookStrength, static_cast<double>(c.look)};
    for (int i = 0; i < 12; ++i)
      p[128 + i] = static_cast<float>(values[i]);
    auto full = c;
    full.mix = 1;
    p[140] = Grade(full).isIdentity() ? 1.f : 0.f;
    auto recipe = [&](int start, const LookDefinition &look) {
      const double temp = c.temperature + look.temperature,
                   tint = c.tint + look.tint,
                   exposure = std::exp2(c.exposure + look.exposure);
      const RGB gain{std::exp2(temp * .35 + tint * .12), std::exp2(-tint * .24),
                     std::exp2(-temp * .35 + tint * .12)};
      for (int i = 0; i < 3; ++i) {
        p[start + i] = static_cast<float>(exposure * gain[i]);
        p[start + 5 + i] = static_cast<float>(look.shadows[i]);
        p[start + 8 + i] = static_cast<float>(look.highlights[i]);
      }
      p[start + 3] = static_cast<float>(c.contrast * look.contrast);
      p[start + 4] = static_cast<float>(c.saturation * look.saturation);
      p[start + 11] = static_cast<float>(look.lift);
      p[start + 12] = static_cast<float>(look.shoulder);
      p[start + 13] = look.lift != 0 || look.shoulder != 0 ||
                              look.shadows != RGB{} || look.highlights != RGB{}
                          ? 1.f
                          : 0.f;
    };
    recipe(144, kLooks[0]);
    recipe(164, kLooks[static_cast<std::size_t>(c.look)]);
    p[201] = static_cast<float>(width);
    p[202] = static_cast<float>(height);
    p[203] = premult ? 1.f : 0.f;
    p[204] = static_cast<float>(g.legacy.amount);
    p[205] = g.local.enabled() ? 1.f : 0.f;
    p[206] = pipe.encoding() == LutEncoding::Rec709OETFToGamma24 ? 1.f : 0.f;
    p[207] = static_cast<float>(left);
    p[208] = static_cast<float>(bottom);
    auto mat = [&](int start, const Matrix &a, const Matrix &b) {
      for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) {
          double sum = 0;
          for (int k = 0; k < 3; ++k)
            sum += a[i][k] * b[k][j];
          p[start + i * 3 + j] = static_cast<float>(sum);
        }
    };
    const int in = static_cast<int>(settings.get(AdvId::InputColorSpace)),
              out = static_cast<int>(settings.get(AdvId::OutputColorSpace));
    mat(350, inverse(kToXYZ[0]), kToXYZ[in]);
    mat(359, inverse(kToXYZ[out]), kToXYZ[0]);
    for (int c0 = 0; c0 < 3; ++c0) {
      p[368 + c0] = static_cast<float>(kToXYZ[in][1][c0]);
      p[371 + c0] = static_cast<float>(kToXYZ[out][1][c0]);
    }
    p[380] = static_cast<float>(settings.get(AdvId::GrainScale) *
                                settings.get(AdvId::GrainClusterSize) * .25);
    return p;
  }

public:
  explicit GpuRenderer(bool testCpuDevice = false) : allowCpu_(testCpuDevice) {}
  GpuRenderer(const GpuRenderer &) = delete;
  void release() noexcept {
    if (queue_ && api_.clFinish)
      api_.clFinish(queue_);
    for (auto &m : frames_)
      if (m) {
        api_.clReleaseMemObject(m);
        m = nullptr;
      }
    capacities_.fill(0);
    for (auto &m : luts_)
      if (m) {
        api_.clReleaseMemObject(m);
        m = nullptr;
      }
    cubeRefs_ = {};
    if (params_)
      api_.clReleaseMemObject(params_);
    if (geometry_)
      api_.clReleaseMemObject(geometry_);
    for (auto &k : kernels_)
      if (k) {
        api_.clReleaseKernel(k);
        k = nullptr;
      }
    if (program_)
      api_.clReleaseProgram(program_);
    if (queue_)
      api_.clReleaseCommandQueue(queue_);
    if (context_)
      api_.clReleaseContext(context_);
    params_ = geometry_ = nullptr;
    program_ = nullptr;
    queue_ = nullptr;
    context_ = nullptr;
    device_ = chosen_ = nullptr;
    ready_ = false;
    attempted_ = false;
    reported_ = false;
    std::vector<float>().swap(packed_);
    std::vector<float>().swap(result_);
  }
  ~GpuRenderer() { release(); }
  void shutdown() {
    std::lock_guard<std::mutex> lock(mutex_);
    release();
  }
  const std::string &status() const { return status_; }
  template <class Reader, class Writer, class Abort>
  bool render(const Pipeline &pipe, const FrameGeometry &g, RectI source,
              RectI output, bool premult, Reader read, Writer destination,
              Abort abort) {
    if (pipe.mix() == 0 || (pipe.isIdentity() && !g.legacy.enabled()) ||
        source.empty() || output.empty())
      return false;
    std::lock_guard<std::mutex> lock(mutex_);
    try {
      if (!attempted_)
        initialize();
      if (!ready_)
        return false;
      if (abort())
        return false;
      const auto wl = static_cast<long long>(source.x2) - source.x1,
                 hl = static_cast<long long>(source.y2) - source.y1;
      if (wl > 32768 || hl > 32768 ||
          std::abs(static_cast<long long>(source.x1)) > 8388608 ||
          std::abs(static_cast<long long>(source.y1)) > 8388608)
        throw GpuError("GPU image geometry outside supported range");
      const int w = static_cast<int>(wl), h = static_cast<int>(hl);
      const std::size_t count = static_cast<std::size_t>(w) * h,
                        bytes = count * 4 * sizeof(float);
      auto src = buffer(0, bytes), a = buffer(1, bytes);
      packed_.resize(count * 4);
      result_.resize(count * 4);
      for (int y = 0; y < h; ++y) {
        if (abort())
          return false;
        const auto row = read(source.x1, source.y1 + y);
        std::copy_n(row, static_cast<std::size_t>(w) * 4,
                    packed_.data() + static_cast<std::size_t>(y) * w * 4);
      }
      write(src, bytes, packed_.data());
      const auto p =
          configuration(pipe, g, w, h, source.x1, source.y1, premult);
      write(params_, sizeof(p), p.data());
      const double angle =
          pipe.advanced() ? pipe.advanced()->value(AdvId::GrainRotation) * .25
                          : 0;
      const double geometry[] = {
          g.left,
          g.bottom,
          g.width,
          g.height,
          g.scaleX,
          g.scaleY,
          g.pixelAspect,
          g.time,
          std::cos(angle),
          std::sin(angle),
          pipe.advanced()
              ? pipe.advanced()->value(AdvId::GrainScale) *
                    pipe.advanced()->value(AdvId::GrainClusterSize) * .25
              : 1};
      write(geometry_, sizeof(geometry), geometry);
      cube(0, pipe.inputCube());
      cube(1, pipe.advanced() ? pipe.advanced()->customCube() : nullptr);
      const bool spatial = g.soft.enabled() || g.legacy.enabled() ||
                           g.local.enabled() || g.bloom.enabled();
      launch(0, count, src, a, params_, geometry_, luts_[0], luts_[1],
             spatial ? 0 : 1);
      cl_mem finalBuffer = a;
      if (spatial) {
        auto b = buffer(2, bytes), temp = buffer(3, bytes),
             scratch = buffer(4, bytes);
        if (g.soft.enabled()) {
          launch(1, count, a, temp, params_, 0);
          blur(temp, scratch, w, h, g.soft, false, b);
        }
        launch(3, count, a, g.soft.enabled() ? temp : a, b, params_, geometry_,
               g.soft.enabled() ? 1 : 0);
        cl_mem current = b;
        if (g.legacy.enabled() || g.local.enabled()) {
          auto local = buffer(5, bytes);
          launch(1, count, b, temp, params_, 1);
          blur(temp, scratch, w, h, g.local.enabled() ? g.local : g.legacy,
               true, a);
          copy(temp, local, bytes);
          cl_mem global = b;
          if (g.global.enabled()) {
            global = buffer(6, bytes);
            launch(1, count, b, temp, params_, 1);
            blur(temp, scratch, w, h, g.global, true, a);
            copy(temp, global, bytes);
          }
          launch(4, count, b, local, global, a, params_);
          current = a;
        }
        if (g.bloom.enabled()) {
          launch(1, count, current, temp, params_, 2);
          blur(temp, scratch, w, h, g.bloom, true, current == a ? b : a);
        }
        finalBuffer = current == a ? b : a;
        launch(5, count, src, current, g.bloom.enabled() ? temp : current,
               finalBuffer, params_, g.bloom.enabled() ? 1 : 0);
      }
      gpuCheck(api_.clEnqueueReadBuffer(queue_, finalBuffer, CL_TRUE, 0, bytes,
                                        result_.data(), 0, nullptr, nullptr),
               "GPU readback");
      if (abort())
        return false;
      // Publish only after a complete successful readback; CPU fallback
      // can safely overwrite the destination after any GPU/driver error.
      for (int y = output.y1; y < output.y2; ++y) {
        auto dst = destination(output.x1, y);
        const int left = std::max(output.x1, source.x1),
                  right = std::min(output.x2, source.x2);
        const auto outWidth = static_cast<std::size_t>(
            static_cast<long long>(output.x2) - output.x1);
        if (y < source.y1 || y >= source.y2 || right <= left) {
          std::fill_n(dst, outWidth * 4, 0.f);
          continue;
        }
        const auto prefix = static_cast<std::size_t>(left - output.x1) * 4;
        const auto copySize = static_cast<std::size_t>(right - left) * 4;
        std::fill_n(dst, prefix, 0.f);
        std::copy_n(result_.data() +
                        (static_cast<std::size_t>(y - source.y1) * w +
                         (left - source.x1)) *
                            4,
                    copySize, dst + prefix);
        std::fill_n(dst + prefix + copySize, outWidth * 4 - prefix - copySize,
                    0.f);
      }
      return true;
    } catch (const std::exception &error) {
      const std::string reason = error.what();
      release(); // Do not hold failed device reservations during CPU fallback.
      attempted_ = true;
      status_ = reason;
      if (!reported_) {
        diagnostic("GPU fallback to CPU", -1, status_.c_str());
        reported_ = true;
      }
      return false;
    }
  }
};
inline GpuRenderer &gpuRenderer() {
  static GpuRenderer renderer;
  return renderer;
}
} // namespace mendes
