#pragma once

#include <algorithm>
#include <array>
#include <cctype>
#include <cstdint>
#include <stdexcept>
#include <string>
#include <vector>

namespace mendes::license {

inline std::string base64Url(const unsigned char *data, std::size_t size) {
    static constexpr char alphabet[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    std::string out;
    out.reserve((size * 4 + 2) / 3);
    std::uint32_t bits = 0;
    unsigned count = 0;
    for (std::size_t i = 0; i < size; ++i) {
        bits = (bits << 8) | data[i];
        count += 8;
        while (count >= 6) {
            count -= 6;
            out.push_back(alphabet[(bits >> count) & 63]);
        }
    }
    if (count)
        out.push_back(alphabet[(bits << (6 - count)) & 63]);
    return out;
}

inline std::vector<unsigned char> base64UrlDecode(const std::string &text) {
    std::array<signed char, 256> lookup{};
    lookup.fill(-1);
    const std::string alphabet =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    for (std::size_t i = 0; i < alphabet.size(); ++i)
        lookup[static_cast<unsigned char>(alphabet[i])] = static_cast<signed char>(i);
    if (text.empty() || text.size() % 4 == 1)
        throw std::invalid_argument("Invalid license encoding.");
    std::vector<unsigned char> out;
    out.reserve(text.size() * 3 / 4);
    std::uint32_t bits = 0;
    unsigned count = 0;
    for (unsigned char c : text) {
        const int value = lookup[c];
        if (value < 0)
            throw std::invalid_argument("Invalid license encoding.");
        bits = (bits << 6) | static_cast<unsigned>(value);
        count += 6;
        if (count >= 8) {
            count -= 8;
            out.push_back(static_cast<unsigned char>((bits >> count) & 255));
        }
    }
    if (count && (bits & ((1U << count) - 1U)))
        throw std::invalid_argument("Non-canonical license encoding.");
    return out;
}

struct Fields {
    std::string machine;
    std::string expiry;
    std::string customer;
};

inline bool validMachine(const std::string &value) {
    // MC- plus eight groups of four hexadecimal digits (128-bit identifier).
    if (value.size() != 42 || value.compare(0, 3, "MC-") != 0)
        return false;
    for (std::size_t i = 3; i < value.size(); ++i) {
        if ((i - 3) % 5 == 4) {
            if (value[i] != '-')
                return false;
        } else if (!std::isxdigit(static_cast<unsigned char>(value[i])) ||
                   std::islower(static_cast<unsigned char>(value[i]))) {
            return false;
        }
    }
    return true;
}

inline bool validExpiry(const std::string &value) {
    if (value == "PERPETUAL")
        return true;
    if (value.size() != 10 || value[4] != '-' || value[7] != '-')
        return false;
    for (std::size_t i = 0; i < value.size(); ++i)
        if (i != 4 && i != 7 && !std::isdigit(static_cast<unsigned char>(value[i])))
            return false;
    const int year = std::stoi(value.substr(0, 4));
    const int month = std::stoi(value.substr(5, 2));
    const int day = std::stoi(value.substr(8, 2));
    if (year < 2024 || year > 9999 || month < 1 || month > 12 || day < 1)
        return false;
    static constexpr int days[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int limit = days[month];
    if (month == 2 && (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)))
        limit = 29;
    return day <= limit;
}

inline std::string payload(const Fields &fields) {
    if (!validMachine(fields.machine) || !validExpiry(fields.expiry) || fields.customer.empty() ||
        fields.customer.size() > 96 || fields.customer.find('\n') != std::string::npos ||
        fields.customer.find('\r') != std::string::npos)
        throw std::invalid_argument("Invalid license fields.");
    const auto encoded = base64Url(reinterpret_cast<const unsigned char *>(fields.customer.data()),
                                   fields.customer.size());
    return "MC16\n" + fields.machine + "\n" + fields.expiry + "\n" + encoded;
}

inline Fields parsePayload(const std::string &text) {
    std::array<std::string, 4> lines{};
    std::size_t start = 0;
    for (int i = 0; i < 4; ++i) {
        const auto end = text.find('\n', start);
        if (i < 3 && end == std::string::npos)
            throw std::invalid_argument("Incomplete license payload.");
        if (i == 3 && end != std::string::npos)
            throw std::invalid_argument("Extra license payload data.");
        lines[i] = text.substr(start, end == std::string::npos ? end : end - start);
        start = end == std::string::npos ? text.size() : end + 1;
    }
    if (lines[0] != "MC16")
        throw std::invalid_argument("Wrong license product/version.");
    const auto customerBytes = base64UrlDecode(lines[3]);
    Fields fields{lines[1], lines[2],
                  std::string(reinterpret_cast<const char *>(customerBytes.data()), customerBytes.size())};
    if (payload(fields) != text)
        throw std::invalid_argument("Non-canonical license payload.");
    return fields;
}

struct Token {
    std::string payload;
    std::array<unsigned char, 64> signature{};
};

inline std::string token(const std::string &payloadText,
                         const std::array<unsigned char, 64> &signature) {
    return "MC16." +
           base64Url(reinterpret_cast<const unsigned char *>(payloadText.data()), payloadText.size()) +
           "." + base64Url(signature.data(), signature.size());
}

inline Token parseToken(std::string text) {
    text.erase(std::remove_if(text.begin(), text.end(), [](unsigned char c) { return std::isspace(c); }),
               text.end());
    if (text.compare(0, 5, "MC16.") != 0)
        throw std::invalid_argument("License must start with MC16.");
    const auto split = text.find('.', 5);
    if (split == std::string::npos || text.find('.', split + 1) != std::string::npos)
        throw std::invalid_argument("Invalid license token structure.");
    const auto payloadBytes = base64UrlDecode(text.substr(5, split - 5));
    const auto signatureBytes = base64UrlDecode(text.substr(split + 1));
    if (signatureBytes.size() != 64)
        throw std::invalid_argument("Invalid license signature size.");
    Token result;
    result.payload.assign(reinterpret_cast<const char *>(payloadBytes.data()), payloadBytes.size());
    std::copy(signatureBytes.begin(), signatureBytes.end(), result.signature.begin());
    parsePayload(result.payload);
    if (token(result.payload, result.signature) != text)
        throw std::invalid_argument("Non-canonical license token.");
    return result;
}

} // namespace mendes::license
