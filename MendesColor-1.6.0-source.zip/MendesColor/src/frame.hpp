#pragma once
#include "pipeline.hpp"

namespace mendes {
struct FrameGeometry {
  double left = 0, bottom = 0, width = 1, height = 1080, scaleX = 1, scaleY = 1,
         pixelAspect = 1, time = 0;
  HalationPlan legacy{}, soft{}, local{}, global{}, bloom{};
  PixelPosition position(int x, int y) const {
    const double cx = (x + .5) * pixelAspect / scaleX - left,
                 cy = (y + .5) / scaleY - bottom;
    return {cx / width, cy / height, cx * 1080 / height, cy * 1080 / height,
            time};
  }
  int haloX() const {
    return std::max({legacy.supportX(), local.supportX(), global.supportX()});
  }
  int haloY() const {
    return std::max({legacy.supportY(), local.supportY(), global.supportY()});
  }
  int supportX() const { return soft.supportX() + haloX() + bloom.supportX(); }
  int supportY() const { return soft.supportY() + haloY() + bloom.supportY(); }
};
inline HalationPlan spatialPlan(double radius, const FrameGeometry &g) {
  auto size = [](double v) {
    return static_cast<int>(std::round(std::clamp(v, 1.0, 128.0)));
  };
  const double r = radius * g.height / 1080;
  return {size(r * g.scaleX / g.pixelAspect), size(r * g.scaleY), 1};
}
inline void configureFrame(FrameGeometry &g, const Pipeline &pipe,
                           HalationPreset preset) {
  const auto a = pipe.advanced();
  g.legacy = {};
  g.soft = {};
  g.local = {};
  g.global = {};
  g.bloom = {};
  if (pipe.mix() == 0)
    return;
  if (!a || !a->enabled(AdvId::HalationEnable))
    g.legacy =
        halationPlan(preset, g.height, g.scaleX, g.scaleY, g.pixelAspect);
  if (!a)
    return;
  if (a->enabled(AdvId::GrainEnable) && a->value(AdvId::GrainBlur) > 0 &&
      a->value(AdvId::GrainIntensity) > 0)
    g.soft = spatialPlan(1 + a->value(AdvId::GrainBlur) * .035, g);
  if (a->enabled(AdvId::HalationEnable)) {
    g.local = spatialPlan(1 + a->value(AdvId::HalationLocalDiffusion) * .18, g);
    g.global =
        spatialPlan(1 + a->value(AdvId::HalationGlobalDiffusion) * .50, g);
  }
  if (a->enabled(AdvId::BloomEnable))
    g.bloom = spatialPlan(1 + a->value(AdvId::BloomDiffusion) * .35, g);
}

// One immutable RGB result per source pixel, shared by the spatial stages.
// Keep double precision until the same float blur stores as the original
// engine.
class StagePixels {
  RectI bounds_{};
  std::size_t width_ = 0;
  std::vector<RGB> pixels_;

public:
  bool empty() const { return pixels_.empty(); }
  void allocate(RectI bounds) {
    bounds_ = bounds;
    pixels_.clear();
    width_ = 0;
    if (bounds.empty())
      return;
    width_ =
        static_cast<std::size_t>(static_cast<long long>(bounds.x2) - bounds.x1);
    const auto height =
        static_cast<std::size_t>(static_cast<long long>(bounds.y2) - bounds.y1);
    if (height > pixels_.max_size() / width_)
      throw std::bad_alloc();
    pixels_.resize(width_ * height);
  }
  RGB &at(int x, int y) {
    return pixels_
        [static_cast<std::size_t>(static_cast<long long>(y) - bounds_.y1) *
             width_ +
         static_cast<std::size_t>(static_cast<long long>(x) - bounds_.x1)];
  }
  RGB sample(int x, int y) const {
    if (x < bounds_.x1 || x >= bounds_.x2 || y < bounds_.y1 || y >= bounds_.y2)
      return {};
    return pixels_
        [static_cast<std::size_t>(static_cast<long long>(y) - bounds_.y1) *
             width_ +
         static_cast<std::size_t>(static_cast<long long>(x) - bounds_.x1)];
  }
};

template <class Reader> class FrameEngine {
  const Pipeline &pipe_;
  const Advanced *adv_;
  FrameGeometry g_;
  Reader read_;
  bool premult_, identity_, spatial_, vignette_, grain_;
  std::uint32_t grainFrame_;
  StagePixels pixels_;
  std::array<HaloBuffer, 3> soft_, bloom_;
  HaloBuffer coverage_, local_, global_;
  double alpha(int x, int y) const {
    const auto p = read_(x, y);
    return p && std::isfinite(p[3]) ? std::clamp<double>(p[3], 0, 1) : 0;
  }
  RGB base(int x, int y) const {
    const auto p = read_(x, y);
    if (!p || p[3] == 0)
      return {};
    RGB v{p[0], p[1], p[2]};
    if (premult_)
      for (double &c : v)
        c /= p[3];
    v = pipe_.postGrade(v);
    return vignette_ ? adv_->position(v, g_.position(x, y)) : v;
  }
  RGB addGrain(RGB v, int x, int y) const {
    if (g_.soft.enabled()) {
      const double coverage = coverage_.at(x, y);
      if (coverage > 1e-9) {
        RGB soft{};
        for (int c = 0; c < 3; ++c)
          soft[c] = soft_[c].at(x, y) / coverage;
        v = blend(v, soft,
                  adv_->value(AdvId::GrainBlur) / 100 *
                      adv_->value(AdvId::GrainIntensity) / 100);
      }
    }
    return grain_ ? adv_->grain(v, g_.position(x, y), grainFrame_) : v;
  }
  double emission(RGB rgb, int x, int y) const {
    return g_.local.enabled() ? adv_->haloEmission(rgb, alpha(x, y))
                              : halationEmission(rgb, alpha(x, y));
  }
  RGB addHalo(RGB v, int x, int y) const {
    if (g_.local.enabled()) {
      const auto add =
          adv_->halo(v, local_.at(x, y), global_.at(x, y), emission(v, x, y));
      if (adv_->enabled(AdvId::HalationMaskMode))
        return add;
      for (int c = 0; c < 3; ++c)
        v[c] += add[c];
    } else if (g_.legacy.enabled()) {
      const auto add =
          halationColor(local_.at(x, y), emission(v, x, y), g_.legacy);
      for (int c = 0; c < 3; ++c)
        v[c] += add[c];
    }
    return v;
  }

public:
  FrameEngine(const Pipeline &p, FrameGeometry g, Reader reader, bool premult)
      : pipe_(p), adv_(p.advanced()), g_(g), read_(reader), premult_(premult),
        identity_(p.isIdentity() && !g.legacy.enabled()),
        spatial_(g.soft.enabled() || g.local.enabled() || g.legacy.enabled() ||
                 g.bloom.enabled()),
        vignette_(adv_ && adv_->enabled(AdvId::VignetteEnable)),
        grain_(adv_ && adv_->enabled(AdvId::GrainEnable)),
        grainFrame_(grain_ ? Advanced::grainFrame(g.time) : 0) {}
  template <class Abort>
  bool build(RectI output, RectI source, Abort abort,
             const RowExecutor &exec = RowExecutor{}) {
    if (pipe_.mix() == 0 || identity_ || !spatial_ || output.empty())
      return true;
    const RectI haloOutput =
        expand(output, g_.bloom.supportX(), g_.bloom.supportY());
    const RectI grainOutput = expand(haloOutput, g_.haloX(), g_.haloY());
    const RectI bounds = intersect(
        expand(grainOutput, g_.soft.supportX(), g_.soft.supportY()), source);
    pixels_.allocate(bounds);
    if (!exec.rows(bounds.y1, bounds.y2, [&](int y) {
          if (abort())
            return false;
          for (int x = bounds.x1; x < bounds.x2; ++x)
            pixels_.at(x, y) = base(x, y);
          return true;
        }))
      return false;
    if (g_.soft.enabled()) {
      if (!coverage_.build(
              grainOutput, source, g_.soft,
              [&](int x, int y) { return alpha(x, y); }, abort, true, exec))
        return false;
      for (int c = 0; c < 3; ++c)
        if (!soft_[c].build(
                grainOutput, source, g_.soft,
                [&](int x, int y) {
                  const auto v = pixels_.sample(x, y);
                  return std::isfinite(v[c]) ? v[c] * alpha(x, y) : 0;
                },
                abort, false, exec))
          return false;
    }
    const RectI grainBounds = intersect(grainOutput, source);
    if (!exec.rows(grainBounds.y1, grainBounds.y2, [&](int y) {
          if (abort())
            return false;
          for (int x = grainBounds.x1; x < grainBounds.x2; ++x)
            pixels_.at(x, y) = addGrain(pixels_.at(x, y), x, y);
          return true;
        }))
      return false;
    for (auto &b : soft_)
      b.release();
    coverage_.release();
    if (g_.legacy.enabled() || g_.local.enabled()) {
      const auto plan = g_.local.enabled() ? g_.local : g_.legacy;
      if (!local_.build(
              haloOutput, source, plan,
              [&](int x, int y) {
                return emission(pixels_.sample(x, y), x, y);
              },
              abort, true, exec))
        return false;
    }
    if (g_.global.enabled() &&
        !global_.build(
            haloOutput, source, g_.global,
            [&](int x, int y) { return emission(pixels_.sample(x, y), x, y); },
            abort, true, exec))
      return false;
    const RectI haloBounds = intersect(haloOutput, source);
    if (!exec.rows(haloBounds.y1, haloBounds.y2, [&](int y) {
          if (abort())
            return false;
          for (int x = haloBounds.x1; x < haloBounds.x2; ++x)
            pixels_.at(x, y) = addHalo(pixels_.at(x, y), x, y);
          return true;
        }))
      return false;
    local_.release();
    global_.release();
    if (g_.bloom.enabled())
      for (int c = 0; c < 3; ++c)
        if (!bloom_[c].build(
                output, source, g_.bloom,
                [&](int x, int y) {
                  return adv_->bloomEmission(pixels_.sample(x, y),
                                             alpha(x, y))[c];
                },
                abort, true, exec))
          return false;
    return true;
  }
  void pixel(const float *src, float *dst, int x, int y) const {
    if (pipe_.mix() == 0 || identity_) {
      std::copy_n(src, 4, dst);
      return;
    }
    const float a = src[3];
    if (premult_ && a == 0) {
      dst[0] = dst[1] = dst[2] = 0;
      dst[3] = a;
      return;
    }
    RGB input{src[0], src[1], src[2]};
    if (premult_)
      for (double &c : input)
        c /= a;
    auto result = spatial_ ? pixels_.sample(x, y)
                           : (!vignette_ && !grain_
                                  ? (a == 0 ? RGB{} : pipe_.postGrade(input))
                                  : addGrain(base(x, y), x, y));
    if (g_.bloom.enabled()) {
      RGB blurred{};
      for (int c = 0; c < 3; ++c)
        blurred[c] = bloom_[c].at(x, y);
      const auto add = adv_->bloom(result, blurred,
                                   adv_->bloomEmission(result, alpha(x, y)));
      if (adv_->enabled(AdvId::BloomMaskMode))
        result = add;
      else
        for (int c = 0; c < 3; ++c)
          result[c] += add[c];
    }
    result = pipe_.finish(input, result);
    for (int c = 0; c < 3; ++c)
      dst[c] = static_cast<float>(result[c] * (premult_ ? a : 1));
    dst[3] = a;
  }
};
} // namespace mendes
