#pragma once
#define MENDES_COLOR_VERSION "1.6.0"
#define MENDES_WIDE_LITERAL_INNER(value) L##value
#define MENDES_WIDE_LITERAL(value) MENDES_WIDE_LITERAL_INNER(value)
namespace mendes {
inline constexpr unsigned kOfxVersionMajor = 1;
inline constexpr unsigned kOfxVersionMinor = 600;
}
