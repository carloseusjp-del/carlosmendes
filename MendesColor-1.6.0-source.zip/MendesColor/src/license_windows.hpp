#pragma once

#include "license_format.hpp"
#include "license_public.hpp"
#include <array>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <limits>
#include <sstream>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <bcrypt.h>
#endif

namespace mendes::license {

enum class State { Valid, Missing, Invalid, Expired, WrongMachine };
struct Result {
    State state = State::Missing;
    Fields fields{};
    std::string detail;
    bool valid() const { return state == State::Valid; }
};

#ifdef _WIN32
inline void cryptoCheck(NTSTATUS status, const char *operation) {
    if (status < 0)
        throw std::runtime_error(std::string(operation) + " failed.");
}

inline std::array<unsigned char, 32> sha256(const unsigned char *data, std::size_t bytes) {
    if (bytes > std::numeric_limits<ULONG>::max())
        throw std::runtime_error("Hash input too large.");
    BCRYPT_ALG_HANDLE algorithm = nullptr;
    BCRYPT_HASH_HANDLE hash = nullptr;
    std::array<unsigned char, 32> digest{};
    try {
        cryptoCheck(BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0),
                    "SHA-256 provider");
        cryptoCheck(BCryptCreateHash(algorithm, &hash, nullptr, 0, nullptr, 0, 0), "SHA-256 hash");
        cryptoCheck(BCryptHashData(hash, const_cast<PUCHAR>(data), static_cast<ULONG>(bytes), 0),
                    "SHA-256 data");
        cryptoCheck(BCryptFinishHash(hash, digest.data(), static_cast<ULONG>(digest.size()), 0),
                    "SHA-256 finish");
    } catch (...) {
        if (hash)
            BCryptDestroyHash(hash);
        if (algorithm)
            BCryptCloseAlgorithmProvider(algorithm, 0);
        throw;
    }
    BCryptDestroyHash(hash);
    BCryptCloseAlgorithmProvider(algorithm, 0);
    return digest;
}

inline std::string utf8(const std::wstring &text) {
    if (text.empty())
        return {};
    const int size = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, text.data(),
                                         static_cast<int>(text.size()), nullptr, 0, nullptr, nullptr);
    if (size <= 0)
        throw std::runtime_error("Invalid Windows text.");
    std::string result(static_cast<std::size_t>(size), '\0');
    if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()),
                            result.data(), size, nullptr, nullptr) != size)
        throw std::runtime_error("Windows text conversion failed.");
    return result;
}

inline std::wstring wide(const std::string &text) {
    if (text.empty())
        return {};
    const int size = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(),
                                         static_cast<int>(text.size()), nullptr, 0);
    if (size <= 0)
        throw std::runtime_error("Invalid UTF-8 text.");
    std::wstring result(static_cast<std::size_t>(size), L'\0');
    if (MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()),
                            result.data(), size) != size)
        throw std::runtime_error("UTF-8 conversion failed.");
    return result;
}

inline std::string machineId() {
    wchar_t value[256]{};
    DWORD bytes = sizeof(value);
    const LSTATUS status = RegGetValueW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Cryptography",
                                        L"MachineGuid", RRF_RT_REG_SZ, nullptr, value, &bytes);
    if (status != ERROR_SUCCESS || !value[0])
        throw std::runtime_error("Cannot read the Windows machine identifier.");
    const std::string source = "MendesColor-License-Machine-1\n" + utf8(value);
    const auto digest = sha256(reinterpret_cast<const unsigned char *>(source.data()), source.size());
    static constexpr char hex[] = "0123456789ABCDEF";
    std::string result = "MC";
    for (std::size_t i = 0; i < 16; ++i) {
        if (i % 2 == 0)
            result.push_back('-');
        result.push_back(hex[digest[i] >> 4]);
        result.push_back(hex[digest[i] & 15]);
    }
    return result;
}

inline std::filesystem::path licensePath() {
    wchar_t local[MAX_PATH]{};
    const DWORD length = GetEnvironmentVariableW(L"LOCALAPPDATA", local, MAX_PATH);
    if (!length || length >= MAX_PATH)
        throw std::runtime_error("Cannot locate LOCALAPPDATA.");
    return std::filesystem::path(local) / L"MendesColor" / L"license.key";
}

inline bool verifySignature(const std::string &payloadText,
                            const std::array<unsigned char, 64> &signature) {
    BCRYPT_ALG_HANDLE algorithm = nullptr;
    BCRYPT_KEY_HANDLE key = nullptr;
    try {
        cryptoCheck(BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_ECDSA_P256_ALGORITHM, nullptr, 0),
                    "ECDSA provider");
        cryptoCheck(BCryptImportKeyPair(algorithm, nullptr, BCRYPT_ECCPUBLIC_BLOB, &key,
                                       const_cast<PUCHAR>(kPublicKeyBlob),
                                       static_cast<ULONG>(kPublicKeyBlobSize), 0),
                    "Public key import");
        const auto digest = sha256(reinterpret_cast<const unsigned char *>(payloadText.data()),
                                   payloadText.size());
        const NTSTATUS status = BCryptVerifySignature(
            key, nullptr, const_cast<PUCHAR>(digest.data()), static_cast<ULONG>(digest.size()),
            const_cast<PUCHAR>(signature.data()), static_cast<ULONG>(signature.size()), 0);
        BCryptDestroyKey(key);
        BCryptCloseAlgorithmProvider(algorithm, 0);
        return status >= 0;
    } catch (...) {
        if (key)
            BCryptDestroyKey(key);
        if (algorithm)
            BCryptCloseAlgorithmProvider(algorithm, 0);
        throw;
    }
}

inline std::string todayUtc() {
    SYSTEMTIME time{};
    GetSystemTime(&time);
    char value[11]{};
    std::snprintf(value, sizeof(value), "%04u-%02u-%02u", time.wYear, time.wMonth, time.wDay);
    return value;
}

inline Result validate(const std::string &licenseText) {
    try {
        const auto parsed = parseToken(licenseText);
        const auto fields = parsePayload(parsed.payload);
        if (!verifySignature(parsed.payload, parsed.signature))
            return {State::Invalid, {}, "A assinatura da licença não é válida."};
        if (fields.machine != machineId())
            return {State::WrongMachine, fields, "A licença pertence a outro computador."};
        if (fields.expiry != "PERPETUAL" && fields.expiry < todayUtc())
            return {State::Expired, fields, "A licença expirou em " + fields.expiry + "."};
        return {State::Valid, fields,
                fields.expiry == "PERPETUAL" ? "Licença perpétua ativa."
                                              : "Licença ativa até " + fields.expiry + "."};
    } catch (const std::exception &error) {
        return {State::Invalid, {}, error.what()};
    }
}

inline Result readAndValidate() {
    try {
        const auto path = licensePath();
        std::ifstream input(path, std::ios::binary);
        if (!input)
            return {State::Missing, {}, "Mendes Color ainda não foi ativado."};
        input.seekg(0, std::ios::end);
        const auto size = input.tellg();
        if (size <= 0 || size > 8192)
            return {State::Invalid, {}, "O arquivo de licença tem tamanho inválido."};
        input.seekg(0);
        std::string text(static_cast<std::size_t>(size), '\0');
        input.read(text.data(), size);
        if (!input)
            return {State::Invalid, {}, "Não foi possível ler a licença."};
        return validate(text);
    } catch (const std::exception &error) {
        return {State::Invalid, {}, error.what()};
    }
}

inline bool save(const std::string &licenseText, std::string &error) {
    const auto result = validate(licenseText);
    if (!result.valid()) {
        error = result.detail;
        return false;
    }
    try {
        const auto path = licensePath();
        std::filesystem::create_directories(path.parent_path());
        const auto temporary = path.parent_path() / L"license.key.tmp";
        {
            std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
            output.write(licenseText.data(), static_cast<std::streamsize>(licenseText.size()));
            output << '\n';
            if (!output)
                throw std::runtime_error("Não foi possível gravar a licença.");
        }
        std::error_code ignored;
        std::filesystem::remove(path, ignored);
        std::filesystem::rename(temporary, path);
        return true;
    } catch (const std::exception &exception) {
        error = exception.what();
        return false;
    }
}

#else
inline Result readAndValidate() { return {State::Valid, {"", "PERPETUAL", "Development"}, ""}; }
#endif

class Gate {
    std::mutex mutex_;
    Result cached_{};
    bool initialized_ = false;

  public:
    Result current() {
#ifdef _WIN32
        std::lock_guard<std::mutex> lock(mutex_);
        // Resolve calls render repeatedly and may split one frame into tiles. Read and
        // verify the license once per process; the activator already asks the user to
        // restart Resolve after changing the license.
        if (!initialized_) {
            cached_ = readAndValidate();
            initialized_ = true;
        }
        return cached_;
#else
        return readAndValidate();
#endif
    }
    void refresh() {
        std::lock_guard<std::mutex> lock(mutex_);
        initialized_ = false;
    }
};

inline Gate &gate() {
    static Gate value;
    return value;
}

} // namespace mendes::license
