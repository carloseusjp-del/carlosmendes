#pragma once
#include "color.hpp"

namespace mendes {
using Matrix = std::array<RGB, 3>;
inline RGB transform(const Matrix &m, RGB v) {
    RGB out{};
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            out[i] += m[i][j] * v[j];
    return out;
}
inline Matrix inverse(const Matrix &m) {
    Matrix out{};
    const double determinant = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
                               m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
                               m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) {
            const int a = (j + 1) % 3, b = (j + 2) % 3, c = (i + 1) % 3, d = (i + 2) % 3;
            out[i][j] = (m[a][c] * m[b][d] - m[a][d] * m[b][c]) / determinant;
        }
    return out;
}
inline constexpr Matrix kToXYZ[] = {{{{0.412390799266, 0.357584339384, 0.180480788402},
                                      {0.212639005872, 0.715168678768, 0.072192315361},
                                      {0.019330818716, 0.119194779795, 0.95053215225}}},
                                    {{{0.70062239, 0.14877482, 0.10105872},
                                      {0.27411851, 0.87363190, -0.14775041},
                                      {-0.09896291, -0.13789533, 1.32591599}}},
                                    {{{0.636958048301, 0.144616903586, 0.168880975164},
                                      {0.262700212011, 0.677998071519, 0.05930171647},
                                      {0, 0.028072693049, 1.060985057711}}}};
inline double signedPower(double x, double exponent) {
    return std::copysign(std::pow(std::abs(x), exponent), x);
}
inline double diDecode(double v) {
    return v <= 0.02740668 ? v / 10.44426855 : std::exp2(v / 0.07329248 - 7) - 0.0075;
}
inline double diEncode(double v) {
    return v <= 0.00262409 ? v * 10.44426855 : (std::log2(v + 0.0075) + 7) * 0.07329248;
}
inline double pqDecode(double v) {
    // ST 2084, relative to 203 cd/m2. A reversible linear extension outside
    // [0,1] and odd negative extension retain float data outside the standard.
    const double magnitude = std::abs(v);
    if (magnitude > 1)
        return std::copysign((10000 + (magnitude - 1) * 95541.8) / 203, v);
    const double p = std::pow(magnitude, 1.0 / (2523.0 / 32));
    const double n = std::max(p - 3424.0 / 4096, 0.0) / (2413.0 / 128 - (2392.0 / 128) * p);
    return std::copysign(10000.0 / 203 * std::pow(n, 1.0 / (2610.0 / 16384)), v);
}
inline double pqEncode(double v) {
    const double n = std::abs(v) * 203;
    if (n > 10000)
        return std::copysign(1 + (n - 10000) / 95541.8, v);
    const double p = std::pow(n / 10000, 2610.0 / 16384);
    return std::copysign(
        std::pow((3424.0 / 4096 + (2413.0 / 128) * p) / (1 + (2392.0 / 128) * p), 2523.0 / 32), v);
}
inline double hlgDecodeOETF(double v) {
    const double x = std::abs(v);
    return std::copysign(x <= 0.5 ? x * x / 3 : (std::exp((x - 0.55991073) / 0.17883277) + 0.28466892) / 12,
                         v);
}
inline double hlgEncodeOETF(double v) {
    const double x = std::abs(v);
    return std::copysign(
        x <= 1.0 / 12 ? std::sqrt(3 * x) : 0.17883277 * std::log(12 * x - 0.28466892) + 0.55991073, v);
}
inline double decodeTransfer(double v, int gamma) {
    switch (gamma) {
    case 0:
        return signedPower(v, 2.4);
    case 1:
        return signedPower(v, 2.2);
    case 2:
        return signedPower(v, 1.96);
    case 3:
        return std::copysign(
            std::abs(v) <= 0.04045 ? std::abs(v) / 12.92 : std::pow((std::abs(v) + 0.055) / 1.055, 2.4), v);
    case 4:
        return v;
    case 5:
        return pqDecode(v);
    default:
        return hlgDecodeOETF(v);
    }
}
inline double encodeTransfer(double v, int gamma) {
    switch (gamma) {
    case 0:
        return signedPower(v, 1 / 2.4);
    case 1:
        return signedPower(v, 1 / 2.2);
    case 2:
        return signedPower(v, 1 / 1.96);
    case 3:
        return std::copysign(std::abs(v) <= 0.0031308 ? std::abs(v) * 12.92
                                                      : 1.055 * std::pow(std::abs(v), 1 / 2.4) - 0.055,
                             v);
    case 4:
        return v;
    case 5:
        return pqEncode(v);
    default:
        return hlgEncodeOETF(v);
    }
}
class ColorConversion {
    int input_, inputGamma_, output_, outputGamma_;
    Matrix inputToWorking_{}, workingToOutput_{};
    static Matrix product(const Matrix &a, const Matrix &b) {
        Matrix m{};
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                for (int k = 0; k < 3; ++k)
                    m[i][j] += a[i][k] * b[k][j];
        return m;
    }
    static double luminance(RGB rgb, int primaries) {
        return kToXYZ[primaries][1][0] * rgb[0] + kToXYZ[primaries][1][1] * rgb[1] +
               kToXYZ[primaries][1][2] * rgb[2];
    }

  public:
    ColorConversion(int input, int inputGamma, int output, int outputGamma)
        : input_(input), inputGamma_(inputGamma), output_(output), outputGamma_(outputGamma),
          inputToWorking_(product(inverse(kToXYZ[0]), kToXYZ[input])),
          workingToOutput_(product(inverse(kToXYZ[output]), kToXYZ[0])) {}
    bool identity() const { return input_ == output_ && (input_ == 1 || inputGamma_ == outputGamma_); }
    RGB input(RGB rgb) const {
        if (input_ == 0 && inputGamma_ == 0)
            return rgb;
        for (double &v : rgb)
            v = input_ == 1 ? diDecode(v) : decodeTransfer(v, inputGamma_);
        if (input_ != 1 && inputGamma_ == 6) {
            const double gain =
                1000.0 / 203 * std::pow(std::max(std::abs(luminance(rgb, input_)), 1e-15), 0.2);
            for (double &v : rgb)
                v *= gain;
        }
        rgb = transform(inputToWorking_, rgb);
        for (double &v : rgb)
            v = signedPower(v, 1 / 2.4);
        return rgb;
    }
    RGB output(RGB rgb) const {
        if (output_ == 0 && outputGamma_ == 0)
            return rgb;
        for (double &v : rgb)
            v = signedPower(v, 2.4);
        rgb = transform(workingToOutput_, rgb);
        if (output_ != 1 && outputGamma_ == 6) {
            const double displayLuma = std::max(std::abs(luminance(rgb, output_)), 1e-15);
            const double sceneLuma = std::pow(displayLuma / (1000.0 / 203), 1 / 1.2);
            const double gain = 1000.0 / 203 * std::pow(sceneLuma, 0.2);
            for (double &v : rgb)
                v /= gain;
        }
        for (double &v : rgb)
            v = output_ == 1 ? diEncode(v) : encodeTransfer(v, outputGamma_);
        return rgb;
    }
};
} // namespace mendes
