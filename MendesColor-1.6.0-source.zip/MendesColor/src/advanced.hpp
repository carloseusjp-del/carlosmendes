#pragma once
#include "advanced_specs.hpp"
#include "color_space.hpp"
#include "cube.hpp"
#include "halation.hpp"
#include <cstdint>
#include <utility>

namespace mendes {
inline double luma(RGB v) { return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]; }
inline double smoothstep(double a, double b, double x) {
    const double t = std::clamp((x - a) / std::max(b - a, 1e-9), 0.0, 1.0);
    return t * t * (3 - 2 * t);
}
inline RGB blend(RGB a, RGB b, double amount) {
    for (int c = 0; c < 3; ++c) {
        a[c] += amount * (b[c] - a[c]);
    }
    return a;
}
inline RGB saturate(RGB v, double amount) {
    const double y = luma(v);
    for (double &c : v)
        c = y + amount * (c - y);
    return v;
}
inline RGB hsv(RGB v) {
    const double hi = *std::max_element(v.begin(), v.end()), lo = *std::min_element(v.begin(), v.end()),
                 d = hi - lo;
    double h = 0;
    if (d > 1e-12) {
        if (hi == v[0])
            h = 60 * std::fmod((v[1] - v[2]) / d, 6);
        else if (hi == v[1])
            h = 60 * ((v[2] - v[0]) / d + 2);
        else
            h = 60 * ((v[0] - v[1]) / d + 4);
    }
    if (h < 0)
        h += 360;
    return {h, hi > 1e-12 ? d / hi : 0, hi};
}
inline RGB hueColor(double angle) {
    const double h = std::fmod(std::fmod(angle, 360.0) + 360, 360) / 60;
    const double x = 1 - std::abs(std::fmod(h, 2) - 1);
    if (h < 1) {
        return {1, x, 0};
    }
    if (h < 2) {
        return {x, 1, 0};
    }
    if (h < 3) {
        return {0, 1, x};
    }
    if (h < 4) {
        return {0, x, 1};
    }
    if (h < 5) {
        return {x, 0, 1};
    }
    return {1, 0, x};
}
inline double hueDistance(double a, double b) {
    double d = std::fmod(std::abs(a - b), 360.0);
    return std::min(d, 360 - d);
}
inline RGB rotateHueCS(RGB v, double co, double si) {
    // Rotate the chroma plane around the neutral RGB axis (orthonormal basis).
    constexpr RGB u{0.7071067811865475, -0.7071067811865475, 0},
        w{0.408248290463863, 0.408248290463863, -0.816496580927726};
    double a = 0, b = 0;
    for (int c = 0; c < 3; ++c) {
        a += v[c] * u[c];
        b += v[c] * w[c];
    }
    const double aa = a * co - b * si, bb = a * si + b * co;
    for (int c = 0; c < 3; ++c) {
        v[c] += (aa - a) * u[c] + (bb - b) * w[c];
    }
    return v;
}
inline RGB rotateHue(RGB v,double degrees) {
    const double angle=degrees*0.017453292519943295;
    return rotateHueCS(v,std::cos(angle),std::sin(angle));
}
struct PixelPosition {
    double u = 0.5, v = 0.5, x1080 = 0, y1080 = 0, time = 0;
};

inline bool validAdvanced(const AdvSettings &settings) {
    for (const auto &s : kAdvSpecs) {
        if (s.type == AdvType::Button)
            continue;
        const double v = settings.get(s.id);
        if (!std::isfinite(v) || v < s.min || v > s.max)
            return false;
        if ((s.type == AdvType::Boolean || s.type == AdvType::Choice) && std::floor(v) != v)
            return false;
    }
    return true;
}
class Advanced {
    AdvSettings s_;
    std::shared_ptr<const Cube3D> custom_;
    ColorConversion conversion_;
    double basicGain_=1,basicGamma_=1;
    RGB basicGains_{},splitHigh_{},splitLow_{};
    double splitHighLuma_=0,splitLowLuma_=0,skinGain_=1,skinCo_=1,skinSi_=0;
    double vignetteX_=1,vignetteY_=1,grainCo_=1,grainSi_=0;

    double get(AdvId id) const { return s_.get(id); }
    bool on(AdvId id) const { return get(id) != 0; }
    RGB basic(RGB v) const {
        const auto input = v;
        if(get(AdvId::BasicIntensity)==0)return v;
        const double gain=basicGain_,lift=get(AdvId::Lift)/400,gamma=basicGamma_;
        const auto& gains=basicGains_;
        for (int c = 0; c < 3; ++c) {
            v[c] += lift * (1 - v[c]);
            v[c] = (gamma==1?v[c]:signedPower(v[c],gamma)) * gain * gains[c];
        }
        const double highlight = smoothstep(.35, 1.2, luma(v));
        const double highlights = get(AdvId::Highlights)==0?1:std::exp2(get(AdvId::Highlights) / 200 * highlight);
        for (double &c : v)
            c = (c * highlights - .18) * get(AdvId::Contrast) + .18;
        v = saturate(v, get(AdvId::Saturation));
        const double richness = get(AdvId::ColourRichness) / 100;
        const auto hs = richness==0?RGB{}:hsv(v);
        v = saturate(v, 1 + richness * .35 * (1 - std::clamp(hs[1], 0.0, 1.0)));
        const double density = richness==0?1:std::exp2(-richness * std::clamp(hs[1], 0.0, 1.0) * .20);
        const double fade = get(AdvId::Fade) / 100 * .12;
        for (double &c : v)
            c = c * density * (1 - fade) + fade;
        RGB bleach = saturate(v, .12);
        for (double &c : bleach)
            c = (c - .18) * 1.30 + .18;
        v = blend(v, bleach, get(AdvId::BleachBypass) / 100);
        return blend(input, v, get(AdvId::BasicIntensity) / 100);
    }
    RGB points(RGB v) const {
        const auto input = v;
        const double black = get(AdvId::BlackPoint) / 100, white = 1 + get(AdvId::WhitePoint) / 100;
        const double denominator = std::max(.02, white - black);
        const int mode = static_cast<int>(get(AdvId::ColorMode));
        if (mode == 1)
            for (double &c : v)
                c = (c - black) / denominator;
        else if (mode == 2) {
            const double y = luma(v), mapped = (y - black) / denominator;
            if (std::abs(y) > 1e-9)
                for (double &c : v)
                    c *= mapped / y;
            else
                for (double &c : v)
                    c += mapped - y;
        } else {
            const double shadow = 1 - smoothstep(0, 1, luma(v)), high = 1 - shadow;
            for (double &c : v)
                c = c - black * shadow + (1 - white) * high;
        }
        return blend(input, v, get(AdvId::BwIntensity) / 100);
    }
    RGB finishing(RGB v) const {
        const int index = static_cast<int>(get(AdvId::FinishingTones));
        if (!index)
            return v;
        // Original Mendes recipes. Names express an aesthetic, not a recovered LUT.
        struct Recipe {
            double saturation, contrast, warm;
            RGB shadow, high;
        };
        static constexpr Recipe recipes[] = {{1, 1, 0, {}, {}},
                                             {0, 1.08, 0, {-.01, 0, .025}, {0, 0, .01}},
                                             {1.12, 1.12, -.08, {-.04, .01, .09}, {}},
                                             {.72, 1.08, -.1, {-.015, .01, .045}, {}},
                                             {1.02, 1.08, -.03, {-.035, .04, .055}, {.03, .01, -.015}},
                                             {.90, 1.08, -.02, {0, .02, .01}, {-.02, .05, -.01}},
                                             {1.2, 1.08, 0, {0, .025, 0}, {-.02, .06, -.025}},
                                             {.68, .93, -.02, {.01, .035, .01}, {}},
                                             {.88, 1.04, .12, {.02, .035, -.015}, {.04, .025, -.04}},
                                             {.80, 1.18, -.04, {-.02, .04, -.01}, {}},
                                             {1.08, 1.06, .24, {.01, 0, -.02}, {.08, .035, -.06}},
                                             {.9, 1.08, .08, {.07, -.01, -.02}, {}},
                                             {.75, .96, .10, {.025, .005, .015}, {.035, .01, -.035}},
                                             {.42, 1.20, -.16, {-.04, .01, .08}, {}},
                                             {.94, 1.12, -.04, {-.02, .055, .005}, {.02, .02, -.015}},
                                             {.76, 1.04, .04, {.015, .04, -.02}, {}},
                                             {.65, 1.24, -.10, {-.03, .04, .05}, {}},
                                             {.70, .92, .13, {.035, .01, .025}, {.04, .015, -.03}}};
        const auto &r = recipes[index];
        RGB result = saturate(v, r.saturation);
        const double y = luma(result), shadow = 1 - smoothstep(.08, .70, y), high = smoothstep(.3, 1, y);
        for (int c = 0; c < 3; ++c)
            result[c] = ((result[c] - .18) * r.contrast + .18) * std::exp2((c == 0   ? 1
                                                                            : c == 2 ? -1
                                                                                     : 0) *
                                                                           r.warm * .35) +
                        std::max(0.0, y) * (r.shadow[c] * shadow + r.high[c] * high);
        return blend(v, result, get(AdvId::FinishingIntensity) / 100);
    }
    RGB split(RGB v) const {
        const auto input = v;
        const auto& hi=splitHigh_;const auto& lo=splitLow_;
        const double y = luma(v), pivot = get(AdvId::SplitPivot);
        const double high = smoothstep(pivot - .22, pivot + .22, y), low = 1 - high;
        const double protection = on(AdvId::SplitProtectNeutrals) ? smoothstep(.01, .25, hsv(v)[1]) : 1;
        const double amount = get(AdvId::SplitAmount) * protection * std::max(0.0, y);
        for (int c = 0; c < 3; ++c)
            v[c] += amount * ((hi[c] - splitHighLuma_) * high + (lo[c] - splitLowLuma_) * low);
        return blend(input, v, get(AdvId::SplitIntensity) / 100);
    }
    RGB skin(RGB v) const {
        const auto h = hsv(v);
        const double y = luma(v), center = 25 + get(AdvId::SkinCenter), range = get(AdvId::SkinRange);
        const double hueMask = 1 - smoothstep(range * .45, range, hueDistance(h[0], center));
        const double width = get(AdvId::SkinBrightnessRange) * .5;
        const double brightness =
            1 - smoothstep(width * .55, width, std::abs(y - get(AdvId::SkinBrightness)));
        const double mask = hueMask * brightness * smoothstep(.02, .20, h[1]);
        if (on(AdvId::ShowSkinSelection))
            return {mask, mask, mask};
        auto corrected = rotateHueCS(v, skinCo_,skinSi_);
        corrected = saturate(corrected, 1 + get(AdvId::SkinSaturate));
        const double exposure = skinGain_;
        for (double &c : corrected)
            c *= exposure;
        return blend(v, corrected, mask * get(AdvId::SkinIntensity) / 100);
    }
    RGB punch(RGB v) const {
        constexpr AdvId channels[] = {AdvId::ColorIntensityRed,   AdvId::ColorIntensityYellow,
                                      AdvId::ColorIntensityGreen, AdvId::ColorIntensityCyan,
                                      AdvId::ColorIntensityBlue,  AdvId::ColorIntensityMagenta};
        const double h = hsv(v)[0];
        double adjustment = 0;
        for (int i = 0; i < 6; ++i)
            adjustment += std::max(0.0, 1 - hueDistance(h, i * 60) / 60) * get(channels[i]);
        const double amount = std::max(0.0, get(AdvId::ColorIntensityGlobal) * (1 + adjustment));
        const double high = on(AdvId::ColorIntensityHighlight) ? smoothstep(.25, .9, luma(v)) : 1;
        return blend(v, saturate(v, amount), high * get(AdvId::ColorIntensityIntensity) / 100);
    }
    static std::uint32_t hash(std::uint32_t x) {
        x ^= x >> 16;
        x *= 0x7feb352dU;
        x ^= x >> 15;
        x *= 0x846ca68bU;
        x ^= x >> 16;
        return x;
    }
    static double noise(double x, double y, std::uint32_t seed) {
        if(std::abs(x)>=1048576.0)x=std::fmod(x,1048576.0);
        if(std::abs(y)>=1048576.0)y=std::fmod(y,1048576.0);
        const auto ix = static_cast<std::int64_t>(std::floor(x)),
                   iy = static_cast<std::int64_t>(std::floor(y));
        const double fx = x - ix, fy = y - iy, tx = fx * fx * (3 - 2 * fx),
                     ty = fy * fy * (3 - 2 * fy);
        auto value = [&](std::int64_t a, std::int64_t b) {
            return hash(static_cast<std::uint32_t>(a) * 0x9e3779b9U ^
                        static_cast<std::uint32_t>(b) * 0x85ebca6bU ^ seed) /
                       4294967295.0 * 2 -
                   1;
        };
        const double a = value(ix, iy) * (1 - tx) + value(ix + 1, iy) * tx,
                     b = value(ix, iy + 1) * (1 - tx) + value(ix + 1, iy + 1) * tx;
        return a * (1 - ty) + b * ty;
    }

  public:
    explicit Advanced(AdvSettings settings, std::shared_ptr<const Cube3D> custom = {})
        : s_(std::move(settings)), custom_(std::move(custom)),
          conversion_(static_cast<int>(get(AdvId::InputColorSpace)), static_cast<int>(get(AdvId::InputGamma)),
                      static_cast<int>(get(AdvId::OutputColorSpace)),
                      static_cast<int>(get(AdvId::ConversionOutput))) {
        basicGain_=std::exp2(get(AdvId::Exposure)+get(AdvId::Gain)/100);
        basicGamma_=std::exp2(-get(AdvId::Gamma)/100);
        const double temp=get(AdvId::Temperature)/100,tint=get(AdvId::Tint)/100;
        basicGains_={std::exp2(temp*.35+tint*.12),std::exp2(-tint*.24),std::exp2(-temp*.35+tint*.12)};
        splitHigh_=hueColor(get(AdvId::SplitHueAngle));splitLow_=hueColor(get(AdvId::SplitHueAngle)+180);
        splitHighLuma_=luma(splitHigh_);splitLowLuma_=luma(splitLow_);
        skinGain_=std::exp2(get(AdvId::SkinColour));
        const double skinAngle=get(AdvId::SkinPop)*0.017453292519943295;
        skinCo_=std::cos(skinAngle);skinSi_=std::sin(skinAngle);
        vignetteX_=std::exp2(-get(AdvId::VignetteAspectRatio));vignetteY_=std::exp2(get(AdvId::VignetteAspectRatio));
        const double grainAngle=get(AdvId::GrainRotation)*.25;
        grainCo_=std::cos(grainAngle);grainSi_=std::sin(grainAngle);
    }
    const AdvSettings &settings() const { return s_; }
    std::shared_ptr<const Cube3D> customCube() const {return custom_;}
    bool enabled(AdvId id) const { return on(id); }
    double value(AdvId id) const { return get(id); }
    bool identity() const {
        for (auto id : {AdvId::BasicEnable, AdvId::BwEnable, AdvId::SplitToningEnable, AdvId::SkinEnable,
                        AdvId::ColorIntensityEnable, AdvId::VignetteEnable, AdvId::GrainEnable,
                        AdvId::HalationEnable, AdvId::BloomEnable})
            if (on(id))
                return false;
        return !custom_ && !on(AdvId::FinishingTones) &&
               (!on(AdvId::ColorSpaceEnable) || conversion_.identity());
    }
    bool geometryNeeded() const {
        return on(AdvId::VignetteEnable) || on(AdvId::GrainEnable) || on(AdvId::HalationEnable) ||
               on(AdvId::BloomEnable);
    }
    RGB input(RGB v) const { return on(AdvId::ColorSpaceEnable) ? conversion_.input(v) : v; }
    RGB output(RGB v) const { return on(AdvId::ColorSpaceEnable) ? conversion_.output(v) : v; }
    RGB color(RGB v) const {
        if (on(AdvId::BasicEnable))
            v = basic(v);
        if (on(AdvId::BwEnable))
            v = points(v);
        if (custom_)
            v = blend(v, custom_->sample(v), get(AdvId::CustomIntensity) / 100);
        v = finishing(v);
        if (on(AdvId::SplitToningEnable))
            v = split(v);
        if (on(AdvId::SkinEnable))
            v = skin(v);
        if (on(AdvId::ColorIntensityEnable))
            v = punch(v);
        return v;
    }
    RGB position(RGB v, const PixelPosition &p) const {
        if (!on(AdvId::VignetteEnable))
            return v;
        const double x =
            (p.u * 2 - 1 - get(AdvId::VignetteCenterX)) * vignetteX_;
        const double y =
            (p.v * 2 - 1 - get(AdvId::VignetteCenterY)) * vignetteY_;
        const double radius = std::hypot(x, y), start = get(AdvId::VignetteSize) / 100;
        const double feather = get(AdvId::VignetteFeather) / 100 * 1.4;
        const double mask =
            feather == 0 ? (radius >= start ? 1 : 0) : smoothstep(start, start + feather, radius);
        if (on(AdvId::VignetteMaskMode))
            return {mask, mask, mask};
        const double gain =
            std::exp2(get(AdvId::VignetteExposure) * mask * get(AdvId::VignetteIntensity) / 100);
        for (double &c : v) {
            c *= gain;
        }
        return v;
    }
    static std::uint32_t grainFrame(double time) {
        return static_cast<std::uint32_t>(static_cast<std::int64_t>(std::floor(std::fmod(time,1e9))));
    }
    RGB grain(RGB v,const PixelPosition& p) const {return grain(v,p,grainFrame(p.time));}
    RGB grain(RGB v, const PixelPosition &p,std::uint32_t frame) const {
        if (!on(AdvId::GrainEnable))
            return v;
        const double y = std::clamp(luma(v), 0.0, 1.0), low = (1 - y) * (1 - y), high = y * y,
                     mid = 4 * y * (1 - y);
        const double zone = (low * get(AdvId::GrainShadows) + mid * get(AdvId::GrainMidtones) +
                             high * get(AdvId::GrainHighlights)) /
                            100;
        const double amount = .08 * get(AdvId::GrainAmount) / 100 * get(AdvId::GrainIntensity) / 100 * zone;
        const double scale = get(AdvId::GrainScale) * get(AdvId::GrainClusterSize) * .25;
        const double co=grainCo_,si=grainSi_;
        const double x = (p.x1080 * co - p.y1080 * si) / scale, yy = (p.x1080 * si + p.y1080 * co) / scale;
        const double mono = noise(x, yy, hash(frame + 12345)),
                     color = on(AdvId::GrainIsColored) ? get(AdvId::GrainColor) / 100 : 0;
        for (int c = 0; c < 3; ++c)
            v[c] +=
                amount * ((1 - color) * mono +
                          (color==0?0:color * noise(x, yy, hash(frame + static_cast<std::uint32_t>(c) * 3299 + 8171))));
        return v;
    }
    double haloEmission(RGB v, double alpha) const {
        if (!std::isfinite(alpha) || alpha <= 0 ||
            !std::all_of(v.begin(), v.end(), [](double x) { return std::isfinite(x); }))
            return 0;
        const double threshold = .35 + .55 * get(AdvId::HalationSourceLimiter) / 100;
        const double knee = .04 + .30 * get(AdvId::HalationSmoothness) / 100;
        const double y = luma(v);
        return smoothstep(threshold, threshold + knee, y) * std::clamp(y, 0.0, 4.0) * std::min(alpha, 1.0);
    }
    RGB halo(RGB base, double local, double global, double emission) const {
        const double background = 1 - smoothstep(get(AdvId::HalationBackgroundGain) / 150,
                                                 get(AdvId::HalationBackgroundGain) / 150 + .45, luma(base));
        const double energy = (std::max(0.0, local - emission) + .35 * std::max(0.0, global - emission)) *
                              background * .20 * std::exp2(get(AdvId::HalationAmplify) / 25 - 2) *
                              get(AdvId::HalationImpact) / 100;
        return {energy, energy * (.03 + .5 * get(AdvId::HalationHue) / 100),
                energy * (.02 - .05 * get(AdvId::HalationBlueComp) / 100 * std::clamp(base[2], 0.0, 1.0))};
    }
    RGB bloomEmission(RGB v, double alpha) const {
        if (!std::isfinite(alpha) || alpha <= 0 ||
            !std::all_of(v.begin(), v.end(), [](double x) { return std::isfinite(x); }))
            return {};
        const double threshold = get(AdvId::BloomHighlights) * .006 + get(AdvId::BloomSourceLimiter) * .003;
        const double mask =
            smoothstep(threshold, threshold + .05 + .25 * (1 - get(AdvId::BloomDetails) / 100), luma(v)) *
            std::min(alpha, 1.0);
        for (double &c : v) {
            c = std::clamp(c, 0.0, 4.0) * mask;
        }
        return v;
    }
    RGB bloom(RGB base, RGB blurred, RGB local) const {
        for (int c = 0; c < 3; ++c)
            blurred[c] = std::max(0.0, blurred[c] - get(AdvId::BloomDetails) / 100 * local[c]);
        blurred = saturate(blurred, get(AdvId::BloomSaturation) / 100);
        const double protection = 1 - get(AdvId::BloomSaveLights) / 100 * smoothstep(.4, 1, luma(base));
        const double amount =
            .8 * get(AdvId::BloomAmplify) / 100 * get(AdvId::BloomImpact) / 100 * protection;
        for (double &c : blurred) {
            c *= amount;
        }
        return blurred;
    }
};

using PresetValues = std::vector<std::pair<AdvId, double>>;
inline AdvId groupPreset(const char *group) {
    const std::string name(group);
    if (name == "BwGroup") {
        return AdvId::BwPreset;
    }
    if (name == "SplitToningGroup") {
        return AdvId::SplitToningPreset;
    }
    if (name == "SkinTonesGroup") {
        return AdvId::SkinPreset;
    }
    if (name == "ColorIntensityGroup") {
        return AdvId::ColorIntensityPreset;
    }
    if (name == "VignetteGroup") {
        return AdvId::VignettePreset;
    }
    if (name == "GrainGroup") {
        return AdvId::GrainPreset;
    }
    if (name == "HalationGroup") {
        return AdvId::HalationProfile;
    }
    if (name == "BloomGroup") {
        return AdvId::BloomProfile;
    }
    return AdvId::Count;
}
inline PresetValues designedPreset(AdvId id, int index) {
    PresetValues result;
    if (index == 0)
        return result;
    const auto &spec = advSpec(id);
    for (const auto &s : kAdvSpecs)
        if (std::string(s.group) == spec.group && (s.type == AdvType::Number || s.type == AdvType::Boolean))
            result.emplace_back(s.id, s.value);
    auto set = [&](AdvId field, double v) {
        for (auto &p : result)
            if (p.first == field) {
                p.second = v;
                return;
            }
        result.emplace_back(field, v);
    };
    using I = AdvId;
    if (id == I::BwPreset) {
        set(I::BwEnable, 1);
        if (index == 2) {
            set(I::BlackPoint, -5);
            set(I::WhitePoint, 12);
        }
        if (index == 3) {
            set(I::BlackPoint, 12);
            set(I::WhitePoint, 0);
        }
    }
    if (id == I::SplitToningPreset) {
        set(I::SplitToningEnable, 1);
        if (index == 2) {
            set(I::SplitHueAngle, 35);
            set(I::SplitPivot, .6);
            set(I::SplitAmount, .22);
        }
        if (index == 3) {
            set(I::SplitHueAngle, 42);
            set(I::SplitPivot, .16);
            set(I::SplitAmount, .20);
        }
        if (index == 4) {
            set(I::SplitHueAngle, 220);
            set(I::SplitAmount, .12);
            set(I::SplitProtectNeutrals, 0);
        }
        if (index == 5) {
            set(I::SplitHueAngle, 65);
            set(I::SplitAmount, .36);
            set(I::SplitPivot, .48);
        }
    }
    if (id == I::SkinPreset) {
        set(I::SkinEnable, 1);
        if (index == 2)
            set(I::SkinSaturate, -.22);
        if (index == 3) {
            set(I::SkinSaturate, -.08);
            set(I::SkinPop, -8);
        }
        if (index == 4) {
            set(I::SkinPop, 7);
            set(I::SkinColour, .08);
        }
        if (index == 5) {
            set(I::SkinColour, -.16);
            set(I::SkinSaturate, -.1);
            set(I::SkinBrightness, .72);
        }
    }
    if (id == I::ColorIntensityPreset) {
        set(I::ColorIntensityEnable, 1);
        if (index == 2) {
            set(I::ColorIntensityRed, .18);
            set(I::ColorIntensityYellow, .2);
        }
        if (index == 3)
            set(I::ColorIntensityBlue, -.45);
        if (index == 4) {
            set(I::ColorIntensityCyan, .22);
            set(I::ColorIntensityBlue, .2);
        }
        if (index == 5) {
            set(I::ColorIntensityRed, -.3);
            set(I::ColorIntensityYellow, -.35);
        }
        if (index == 6)
            set(I::ColorIntensityGreen, -.45);
        if (index == 7) {
            set(I::ColorIntensityGreen, .22);
            set(I::ColorIntensityCyan, .1);
        }
    }
    if (id == I::VignettePreset) {
        set(I::VignetteEnable, 1);
        if (index == 2) {
            set(I::VignetteExposure, -.55);
            set(I::VignetteSize, 45);
            set(I::VignetteFeather, 75);
        }
        if (index == 3) {
            set(I::VignetteExposure, -1.2);
            set(I::VignetteSize, 30);
            set(I::VignetteFeather, 55);
        }
        if (index == 4) {
            set(I::VignetteExposure, -1.5);
            set(I::VignetteSize, 70);
            set(I::VignetteFeather, 25);
            set(I::VignetteAspectRatio, 1);
        }
    }
    if (id == I::GrainPreset) {
        set(I::GrainEnable, 1);
        if (index == 6)
            return result;
        const int family = (index - 1) / 2;
        const bool high = index % 2 == 0;
        set(I::GrainScale, 32 - family * 8);
        set(I::GrainAmount, (high ? 58 : 34) - family * 7);
        set(I::GrainColor, high ? 65 : 30);
        set(I::GrainBlur, 24 - family * 6);
        set(I::GrainClusterSize, 2.3 - family * .4);
    }
    if (id == I::HalationProfile) {
        set(I::HalationEnable, 1);
        const double factor = 1 - (index - 1) * .22;
        set(I::HalationAmplify, 70 * factor);
        set(I::HalationLocalDiffusion, 25 * factor);
        set(I::HalationGlobalDiffusion, 35 * factor);
        set(I::HalationImpact, 100 - (index - 1) * 18);
    }
    if (id == I::BloomProfile) {
        set(I::BloomEnable, 1);
        constexpr double diffusion[] = {0, 85, 65, 50, 28};
        set(I::BloomDiffusion, diffusion[index]);
        set(I::BloomAmplify, index == 1 ? 70 : index == 2 ? 60 : index == 3 ? 50 : 35);
    }
    return result;
}
} // namespace mendes
