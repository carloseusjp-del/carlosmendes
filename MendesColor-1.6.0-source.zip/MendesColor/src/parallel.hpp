#pragma once
#include "ofxMultiThread.h"
#include <algorithm>
#include <atomic>
#include <exception>
#include <mutex>

namespace mendes {
// Use the host's CPU budget/pool; never create a private pool or recursively
// spawn threads. Each stage joins before its buffers can be read or released.
class RowExecutor {
  const OfxMultiThreadSuiteV1 *suite_ = nullptr;
  unsigned lanes_ = 1;

public:
  explicit RowExecutor(const OfxMultiThreadSuiteV1 *suite = nullptr)
      : suite_(suite) {
    unsigned cpus = 1;
    if (suite_ && suite_->multiThread && suite_->multiThreadNumCPUs &&
        suite_->multiThreadNumCPUs(&cpus) == kOfxStatOK)
      lanes_ = std::clamp(cpus, 1U, 16U);
  }
  template <class Row>
  bool rows(int first, int last, Row row, unsigned minimumRows = 16) const {
    const auto count = static_cast<long long>(last) - first;
    if (count <= 0)
      return true;
    const auto lanes = static_cast<unsigned>(
        std::min<long long>(lanes_, std::max(1LL, count / minimumRows)));
    if (lanes <= 1 || (suite_->multiThreadIsSpawnedThread &&
                       suite_->multiThreadIsSpawnedThread())) {
      for (int y = first; y < last; ++y)
        if (!row(y))
          return false;
      return true;
    }
    struct Job {
      int first;
      long long count;
      Row &row;
      std::atomic<bool> cancelled{false}, started{false};
      std::exception_ptr error;
      std::mutex mutex;
      static void invoke(unsigned index, unsigned total, void *data) noexcept {
        auto &job = *static_cast<Job *>(data);
        job.started.store(true, std::memory_order_relaxed);
        try {
          const int a = static_cast<int>(job.first + job.count * index / total);
          const int b =
              static_cast<int>(job.first + job.count * (index + 1) / total);
          for (int y = a;
               y < b && !job.cancelled.load(std::memory_order_relaxed); ++y)
            if (!job.row(y)) {
              job.cancelled.store(true, std::memory_order_relaxed);
              break;
            }
        } catch (...) {
          std::lock_guard<std::mutex> lock(job.mutex);
          if (!job.error)
            job.error = std::current_exception();
          job.cancelled.store(true, std::memory_order_relaxed);
        }
      }
    } job{first, count, row, false, false, {}, {}};
    const auto status = suite_->multiThread(Job::invoke, lanes, &job);
    if (job.error)
      std::rethrow_exception(job.error);
    if (status != kOfxStatOK) {
      // Suites may refuse nested dispatch without invoking a callback.
      if (!job.started.load(std::memory_order_relaxed)) {
        for (int y = first; y < last; ++y)
          if (!row(y))
            return false;
        return true;
      }
      throw status;
    }
    return !job.cancelled.load(std::memory_order_relaxed);
  }
};
} // namespace mendes
