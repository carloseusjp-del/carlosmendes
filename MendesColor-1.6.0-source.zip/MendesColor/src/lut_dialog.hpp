#pragma once
#include "cube.hpp"
#include <filesystem>
#include <string>
#include <vector>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#define WIN32_LEAN_AND_MEAN
// clang-format off: commdlg.h requires the Windows types first.
#include <windows.h>
#include <commdlg.h>
// clang-format on
#endif
namespace mendes {
inline std::vector<std::string> chooseLuts() {
    std::vector<std::string> paths;
#ifdef _WIN32
    std::vector<wchar_t> buffer(65536);
    OPENFILENAMEW picker{};
    picker.lStructSize = sizeof(picker);
    picker.hwndOwner = GetActiveWindow();
    picker.lpstrFilter = L"LUTs 3D (*.cube;*.3dl)\0*.cube;*.3dl\0Todos os arquivos\0*.*\0\0";
    picker.lpstrFile = buffer.data();
    picker.nMaxFile = static_cast<DWORD>(buffer.size());
    picker.lpstrTitle = L"Mendes Color — carregar até 16 LUTs";
    picker.Flags =
        OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_ALLOWMULTISELECT | OFN_NOCHANGEDIR;
    if (!GetOpenFileNameW(&picker)) {
        if (CommDlgExtendedError() != 0)
            throw LutError("Could not open the LUT picker. Use the File field instead.");
        return paths;
    }
    const std::wstring first(buffer.data());
    const wchar_t *next = buffer.data() + first.size() + 1;
    if (!*next)
        paths.push_back(std::filesystem::path(first).u8string());
    else
        while (*next) {
            const std::wstring name(next);
            paths.push_back((std::filesystem::path(first) / name).u8string());
            next += name.size() + 1;
            if (paths.size() > 16)
                throw LutError("Choose at most 16 LUT files at a time.");
        }
#endif
    return paths;
}
} // namespace mendes
