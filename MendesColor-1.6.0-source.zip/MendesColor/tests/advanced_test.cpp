#include "avata2_lut.hpp"
#include "frame.hpp"
#include <cstdlib>
#include <iostream>
#include <limits>
#include <sstream>

namespace {
int checks = 0;
void require(bool ok, const char *message) {
    ++checks;
    if (!ok) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}
bool near(double a, double b, double e = 1e-7) { return std::abs(a - b) < e; }
bool same(mendes::RGB a, mendes::RGB b, double e = 1e-7) {
    return near(a[0], b[0], e) && near(a[1], b[1], e) && near(a[2], b[2], e);
}
} // namespace
int main() {
    using namespace mendes;
    using I = AdvId;
    AdvSettings settings;
    require(validAdvanced(settings) && Advanced(settings).identity(),
            "advanced defaults are a neutral opt-in addition");
    const RGB hdr{-.15, .5, 3};
    require(Advanced(settings).color(hdr) == hdr, "disabled tools preserve float HDR exactly");
    for (auto id :
         {I::BasicEnable, I::BwEnable, I::SplitToningEnable, I::SkinEnable, I::ColorIntensityEnable,
          I::VignetteEnable, I::GrainEnable, I::HalationEnable, I::BloomEnable, I::ColorSpaceEnable})
        require(settings.get(id) == 0, "new processing groups default off for old projects");
    settings.set(I::BasicEnable, 1);
    settings.set(I::Exposure, 1);
    require(same(Advanced(settings).color({.1, .2, .4}), {.2, .4, .8}),
            "advanced exposure applies a one-stop gain");
    settings.set(I::Exposure, 0);
    settings.set(I::Lift, 40);
    require(near(Advanced(settings).color({1, 1, 1})[0], 1) && Advanced(settings).color({0, 0, 0})[0] > 0,
            "lift changes black with white anchored");
    settings.set(I::Lift, 0);
    settings.set(I::Gamma, 50);
    require(same(Advanced(settings).color({0, 1, .5}), {0, 1, std::pow(.5, std::exp2(-.5))}),
            "tonal gamma preserves black and white anchors");
    settings.set(I::Gamma, 0);
    settings.set(I::Gain, 100);
    require(same(Advanced(settings).color({0, .2, .4}), {0, .4, .8}), "gain anchors black");
    settings.set(I::Gain, 0);
    settings.set(I::Fade, 50);
    require(Advanced(settings).color({0, 0, 0})[0] > 0, "fade lifts black");
    settings.set(I::BasicIntensity, 0);
    require(Advanced(settings).color(hdr) == hdr, "basic wet/dry zero preserves input");
    settings = {};
    settings.set(I::BwEnable, 1);
    const RGB color{.12, .36, .72};
    const auto normal = Advanced(settings).color(color);
    settings.set(I::ColorMode, 1);
    const auto rgb = Advanced(settings).color(color);
    settings.set(I::ColorMode, 2);
    const auto lum = Advanced(settings).color(color);
    require(!same(normal, rgb) && !same(rgb, lum), "normal, RGB and luma points modes are distinct");
    require(near(lum[0] / color[0], lum[2] / color[2]), "luma points preserve channel ratios");
    settings = {};
    settings.set(I::SplitToningEnable, 1);
    require(same(Advanced(settings).color({.4, .4, .4}), {.4, .4, .4}),
            "split neutral protection retains gray");
    settings.set(I::SplitProtectNeutrals, 0);
    require(!same(Advanced(settings).color({.4, .4, .4}), {.4, .4, .4}),
            "split toning can tint neutral pixels when requested");
    settings = {};
    settings.set(I::SkinEnable, 1);
    settings.set(I::ShowSkinSelection, 1);
    const RGB skin{.7, .42, .28};
    const auto mask = Advanced(settings).color(skin);
    require(mask[0] > .7 && mask[0] == mask[1] && mask[1] == mask[2], "skin mask selects a warm test color");
    require(Advanced(settings).color({.15, .7, .2})[0] == 0, "skin hue selection rejects green");
    require(Advanced(settings).color({.5, .5, .5})[0] == 0, "skin hue selection rejects achromatic pixels");
    settings.set(I::ShowSkinSelection, 0);
    settings.set(I::SkinSaturate, .6);
    require(!same(Advanced(settings).color(skin), skin), "skin correction changes selected colors");
    settings = {};
    settings.set(I::ColorIntensityEnable, 1);
    settings.set(I::ColorIntensityGlobal, 1);
    settings.set(I::ColorIntensityBlue, -.6);
    const RGB blue{.12, .2, .8};
    const auto changed = Advanced(settings).color(blue);
    require(changed[2] < blue[2] && near(luma(changed), luma(blue)),
            "per-hue punch reduces blue saturation without a luma shift");
    settings = {};
    settings.set(I::VignetteEnable, 1);
    Advanced vignette(settings);
    require(same(vignette.position(color, {.5, .5, 0, 0, 0}), color),
            "vignette clear center stays unchanged");
    require(vignette.position(color, {0, 0, 0, 0, 0})[0] < color[0], "vignette darkens edges");
    settings.set(I::VignetteMaskMode, 1);
    require(Advanced(settings).position(color, {0, 0, 0, 0, 0})[0] > 0,
            "vignette has a grayscale mask preview");
    settings = {};
    settings.set(I::GrainEnable, 1);
    settings.set(I::GrainIsColored, 0);
    PixelPosition position{.4, .4, 130.4, 280.7, 7};
    const auto grain = Advanced(settings).grain(color, position);
    require(grain == Advanced(settings).grain(color, position),
            "grain is deterministic at a coordinate and frame");
    require(near(grain[0] - color[0], grain[2] - color[2]),
            "monochrome grain has equal channel contributions");
    position.time = 8;
    require(!same(Advanced(settings).grain(color, position), grain), "grain changes with frame time");
    settings.set(I::GrainAmount, 0);
    require(Advanced(settings).grain(color, position) == color, "zero grain strength has no noise");

    for (const auto &spec : kAdvSpecs) {
        if (spec.type != AdvType::Choice || spec.id != groupPreset(spec.group))
            continue;
        for (int n = 1; n < static_cast<int>(spec.options.size()); ++n) {
            AdvSettings recipe;
            const auto assignments = designedPreset(spec.id, n);
            require(!assignments.empty(), "every selectable preset has a real recipe");
            for (const auto &[id, value] : assignments)
                recipe.set(id, value);
            require(validAdvanced(recipe), "designed preset assignments respect every parameter range");
            Advanced processor(recipe);
            for (const auto &sample : {RGB{-.1, .3, .7}, RGB{.7, .4, .25}, RGB{2, 3, 4}}) {
                auto result =
                    processor.grain(processor.position(processor.color(sample), position), position);
                require(std::all_of(result.begin(), result.end(), [](double x) { return std::isfinite(x); }),
                        "presets retain finite signed/HDR test colors");
            }
        }
    }
    for (int n = 1; n <= 17; ++n) {
        settings = {};
        settings.set(I::FinishingTones, n);
        const auto v = Advanced(settings).color(color);
        require(!same(v, color), "each finishing tone processes color");
    }
    for (const auto &spec : kAdvSpecs)
        if (spec.type != AdvType::Button) {
            settings = {};
            settings.set(spec.id, std::numeric_limits<double>::quiet_NaN());
            require(!validAdvanced(settings), "nonfinite advanced controls rejected");
            settings = {};
            settings.set(spec.id, spec.max + 1);
            require(!validAdvanced(settings), "out-of-range advanced controls rejected");
        }

    require(near(decodeTransfer(.5, 3), .21404114048223255), "sRGB published midpoint");
    require(near(pqDecode(.508078421517399), 100.0 / 203, 1e-7), "PQ published 100-nit code value");
    require(near(pqDecode(1), 10000.0 / 203, 1e-7), "PQ peak is 10000 nits relative to 203-nit white");
    require(near(hlgDecodeOETF(.5), 1.0 / 12), "HLG OETF midpoint maps to one-twelfth scene light");
    for (int primaries = 0; primaries < 3; ++primaries)
        for (int gamma = 0; gamma < 7; ++gamma) {
            ColorConversion conversion(primaries, gamma, primaries, gamma);
            for (const auto &sample : {RGB{.12, .3, .6}, RGB{.4, .4, .4}, RGB{-.03, .2, 1.1}}) {
                const auto roundtrip = conversion.output(conversion.input(sample));
                require(same(roundtrip, sample, 3e-5),
                        "all primary/transfer pairs round-trip signed float test colors");
            }
        }
    ColorConversion white(2, 4, 0, 4);
    require(same(white.output(white.input({1, 1, 1})), {1, 1, 1}, 1e-6),
            "D65 white is preserved between Rec2020 and Rec709");

    auto table = [](int n, bool nonuniform) {
        std::ostringstream out;
        if (n == 2)
            out << "0 1023\n";
        else
            out << (nonuniform ? "0 256 1023\n" : "0 512 1023\n");
        for (int r = 0; r < n; ++r)
            for (int g = 0; g < n; ++g)
                for (int b = 0; b < n; ++b)
                    out << std::lround(r * 4095.0 / (n - 1)) << ' ' << std::lround(g * 4095.0 / (n - 1))
                        << ' ' << std::lround(b * 4095.0 / (n - 1)) << '\n';
        return out.str();
    };
    {
        std::istringstream stream(table(2, false));
        const auto lut = Cube3D::read3dl(stream);
        require(same(lut.sample(color), color), "blue-fast 3DL identity preserves all channels");
    }
    {
        std::istringstream stream(table(3, true));
        const auto lut = Cube3D::read3dl(stream);
        require(same(lut.sample({256.0 / 1023, 256.0 / 1023, 256.0 / 1023}),
                     {2048.0 / 4095, 2048.0 / 4095, 2048.0 / 4095}),
                "nonuniform 3DL mesh uses its actual knots");
    }
    for (const auto &invalid :
         {std::string(""), std::string("0 0 1023\n"), std::string("Mesh 4 12\n0 1023\n"),
          std::string("0 1023\n0 0 99999\n"), table(2, false) + "0 0 0\n"}) {
        bool rejected = false;
        try {
            std::istringstream stream(invalid);
            (void)Cube3D::read3dl(stream);
        } catch (const LutError &) {
            rejected = true;
        }
        require(rejected, "invalid 3DL rejected");
    }

    // Exercise the complete spatial dependency chain with different source ROIs.
    constexpr int w = 96, h = 80, x0 = -7, y0 = 11;
    std::vector<float> pixels(w * h * 4);
    RectI source{x0, y0, x0 + w, y0 + h}, tile{x0 + 20, y0 + 18, x0 + 67, y0 + 61};
    for (int y = y0; y < y0 + h; ++y)
        for (int x = x0; x < x0 + w; ++x) {
            auto p = pixels.data() + ((y - y0) * w + x - x0) * 4;
            const float v = x > x0 + 35 && x < x0 + 54 && y > y0 + 25 && y < y0 + 46 ? .57f : .06f;
            p[0] = v;
            p[1] = v * .97f;
            p[2] = v * .92f;
            p[3] = .6f;
        }
    auto read = [&](int x, int y) -> const float * {
        if (x < source.x1 || x >= source.x2 || y < source.y1 || y >= source.y2)
            return nullptr;
        return pixels.data() + ((y - y0) * w + x - x0) * 4;
    };
    settings = {};
    for (auto id : {I::GrainEnable, I::HalationEnable, I::BloomEnable, I::VignetteEnable})
        settings.set(id, 1);
    settings.set(I::GrainBlur, 25);
    Controls controls;
    Pipeline pipeline(controls, {}, LutEncoding::Preserve, std::make_shared<const Advanced>(settings));
    FrameGeometry geometry;
    geometry.left = x0;
    geometry.bottom = y0;
    geometry.width = w;
    geometry.height = h;
    geometry.time = 5;
    configureFrame(geometry, pipeline, HalationPreset::Off);
    require(geometry.supportX() == geometry.soft.supportX() +
                                       std::max(geometry.local.supportX(), geometry.global.supportX()) +
                                       geometry.bloom.supportX(),
            "ROI includes the complete chained spatial support");
    FrameEngine full(pipeline, geometry, read, true);
    require(full.build(source, source, [] { return false; }), "full spatial chain builds");
    const auto crop = intersect(expand(tile, geometry.supportX(), geometry.supportY()), source);
    auto cropped = [&](int x, int y) -> const float * {
        return x < crop.x1 || x >= crop.x2 || y < crop.y1 || y >= crop.y2 ? nullptr : read(x, y);
    };
    FrameEngine partial(pipeline, geometry, cropped, true);
    require(partial.build(tile, crop, [] { return false; }),
            "chained spatial render supports a cropped source ROI");
    double delta = 0;
    bool alphaOK = true, finite = true;
    for (int y = tile.y1; y < tile.y2; ++y)
        for (int x = tile.x1; x < tile.x2; ++x) {
            float a[4]{}, b[4]{};
            full.pixel(read(x, y), a, x, y);
            partial.pixel(read(x, y), b, x, y);
            for (int c = 0; c < 4; ++c) {
                delta = std::max(delta, double(std::abs(a[c] - b[c])));
                finite = finite && std::isfinite(a[c]);
            }
            alphaOK = alphaOK && a[3] == .6f && b[3] == .6f;
        }
    require(delta < 2e-6, "combined grain-softness, halation and bloom have no tile seams");
    require(alphaOK && finite, "combined effects preserve alpha and produce finite values");
    AdvSettings zeroGrain;
    zeroGrain.set(I::GrainEnable,1);zeroGrain.set(I::GrainBlur,100);zeroGrain.set(I::GrainIntensity,0);
    Pipeline noGrain({}, {}, LutEncoding::Preserve,std::make_shared<const Advanced>(zeroGrain));
    FrameGeometry neutralGeometry=geometry;configureFrame(neutralGeometry,noGrain,HalationPreset::Off);
    require(!neutralGeometry.soft.enabled(),"grain master zero skips the underlying image-softening buffers");
    FrameEngine zeroEngine(noGrain,neutralGeometry,read,true);
    require(zeroEngine.build(source,source,[]{return false;}),"grain master zero builds without spatial work");
    float noGrainPixel[4]{};zeroEngine.pixel(read(x0+35,y0+25),noGrainPixel,x0+35,y0+25);
    require(std::equal(noGrainPixel,noGrainPixel+4,read(x0+35,y0+25)),"grain intensity zero bypasses both noise and image softening");
    int rows = 0;
    FrameEngine cancelled(pipeline, geometry, read, true);
    require(!cancelled.build(source, source, [&] { return ++rows > 3; }),
            "complex spatial build responds to abort");
    controls.mix = 0;
    Pipeline bypass(controls, {}, LutEncoding::Preserve, std::make_shared<const Advanced>(settings));
    FrameEngine identity(bypass, geometry, read, true);
    float output[4]{};
    identity.pixel(read(x0 + 20, y0 + 20), output, x0 + 20, y0 + 20);
    require(std::equal(output, output + 4, read(x0 + 20, y0 + 20)),
            "global mix zero exactly bypasses every advanced spatial effect");
    AdvSettings neutral;
    Pipeline normalized({}, avata2Cube(), LutEncoding::Preserve, std::make_shared<const Advanced>(neutral));
    require(same(normalized.apply({.5, .5, .5}), {.487409, .487448, .487588}),
            "new default state preserves the supplied Avata LUT exactly");
    std::cout << "Advanced tools: " << checks << " checks passed\n";
}
