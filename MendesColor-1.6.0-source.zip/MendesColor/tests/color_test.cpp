#include "color.hpp"
#include <cstdlib>
#include <iostream>
#include <limits>
#include "fixtures/legacy_looks.hpp"

int checks = 0;
void require(bool ok, const char* msg) {
    ++checks;
    if (!ok) { std::cerr << "FAIL: " << msg << '\n'; std::exit(1); }
}
bool near(double a, double b, double eps = 1e-6) { return std::abs(a - b) < eps; }
int main() {
    using namespace mendes;
    Controls c;
    require(valid(c), "default controls valid");
    RGB hdr{-0.2, 0.18, 4};
    require(Grade(c).apply(hdr) == hdr, "neutral preserves HDR and negatives exactly");
    c.exposure = 1;
    auto v = Grade(c).apply({0.25, 0.5, 1.5});
    require(near(v[0], 0.5) && near(v[1], 1) && near(v[2], 3), "one stop doubles RGB without clipping");
    c = {}; c.gamma = 2;
    v = Grade(c).apply({-0.25, 0.25, 4});
    require(near(v[0], -0.5) && near(v[1], 0.5) && near(v[2], 2), "signed gamma preserves negative sign");
    c = {}; c.saturation = 0;
    v = Grade(c).apply({1, 0, 0});
    require(near(v[0], 0.2126) && near(v[1], 0.2126) && near(v[2], 0.2126), "desaturation produces expected gray");
    c = {}; c.contrast = 2;
    v = Grade(c).apply({0.18, 0.18, 0.18});
    require(near(v[0], 0.18) && near(v[1], 0.18), "contrast leaves pivot fixed");
    c = {}; c.black = 0.1; c.white = 0.9;
    v = Grade(c).apply({0.1, 0.5, 0.9});
    require(near(v[0], 0) && near(v[1], 0.5) && near(v[2], 1), "black and white map endpoints");
    c = {}; c.exposure = 1; c.mix = 0.5;
    v = Grade(c).apply({0.2, 0.4, 1});
    require(near(v[0], 0.3) && near(v[1], 0.6) && near(v[2], 1.5), "mix blends original and grade");
    c.mix = 0;
    require(Grade(c).apply(hdr) == hdr, "zero mix is exact bypass");
    c = {}; c.temperature = 1;
    v = Grade(c).apply({0.5, 0.5, 0.5});
    require(v[0] > v[1] && v[1] > v[2], "positive temperature warms neutrals");
    c = {}; c.tint = 1;
    v = Grade(c).apply({0.5, 0.5, 0.5});
    require(v[0] > v[1] && v[2] > v[1], "positive tint favors magenta");
    float rgba[] = {0.1f, 0.2f, 0.3f, 0.5f}, output[4]{};
    c = {}; c.exposure = 1;
    Grade(c).pixel(rgba, output, true);
    require(near(output[0], 0.2) && near(output[1], 0.4) && near(output[2], 0.6) && output[3] == rgba[3], "premultiplied alpha is preserved");
    float zero[] = {0, 0, 0, 0};
    c.black = -0.1; Grade(c).pixel(zero, output, true);
    require(output[0] == 0 && output[1] == 0 && output[2] == 0 && output[3] == 0, "transparent premultiplied pixels remain transparent");
    c = {}; c.white = c.black;
    require(!valid(c), "coincident levels rejected");
    c.white = -0.1;
    require(!valid(c), "reversed levels rejected");
    c = {}; c.gamma = 0;
    require(!valid(c), "zero gamma rejected");
    c = {}; c.exposure = std::numeric_limits<double>::quiet_NaN();
    require(!valid(c), "nonfinite parameter rejected");
    for (int look = 0; look < static_cast<int>(kLookCount); ++look) {
        c = {}; c.look = static_cast<Look>(look);
        require(valid(c), "preset controls valid");
        for (int n = -10; n <= 100; ++n) {
            v = Grade(c).apply({n * 0.01, n * 0.02, n * 0.04});
            require(std::isfinite(v[0]) && std::isfinite(v[1]) && std::isfinite(v[2]), "preset ramp produces finite HDR RGB");
        }
        if (look) require(Grade(c).apply({0.2, 0.4, 0.6}) != RGB{0.2, 0.4, 0.6}, "creative preset changes color");
    }
    for (const auto& golden : mendes_test::legacyLooks) {
        c = {}; c.look = static_cast<Look>(golden.look);
        c.exposure = 0.25; c.contrast = 1.15; c.gamma = 0.9;
        c.temperature = -0.1; c.tint = 0.05; c.saturation = 1.12;
        c.black = 0.01; c.white = 1.05; c.mix = 0.65;
        v = Grade(c).apply(golden.input);
        require(near(v[0], golden.output[0], 1e-10) && near(v[1], golden.output[1], 1e-10) && near(v[2], golden.output[2], 1e-10), "original six looks retain published 1.1.0 output with manual corrections");
    }
    c = {}; c.look = Look::GoldenHour;
    v = Grade(c).apply({0.4, 0.4, 0.4});
    require(v[0] > v[2], "Golden Hour warms neutrals");
    c.look = Look::SunsetGlow;
    v = Grade(c).apply({0.4, 0.4, 0.4});
    require(v[0] > v[2], "Sunset Glow favors warm highlights");
    c.look = Look::MoodyForest;
    v = Grade(c).apply({0.3, 0.3, 0.3});
    require(v[1] > v[0] && v[1] > v[2], "Moody Forest favors green in mid-dark neutrals");
    c.look = Look::CommercialTeal;
    v = Grade(c).apply({0.1, 0.1, 0.1});
    require(v[1] > v[0] && v[2] > v[0], "Commercial Teal introduces green-blue shadows");
    c.look = Look::Noir;
    v = Grade(c).apply({0.1, 0.4, 0.8});
    require(near(v[0], v[1]) && near(v[1], v[2]), "Noir is achromatic on colored input");
    c.look = Look::MatteVintage;
    v = Grade(c).apply({0, 0, 0});
    require(v[0] > 0 && v[1] > 0 && v[2] > 0, "Matte Vintage lifts black");
    c.look = Look::RichFilm;
    v = Grade(c).apply({4, 4, 4});
    require(v[0] > 1 && v[0] < 4, "highlight shoulder compresses HDR without hard clipping to one");
    c.look = Look::GoldenHour; c.lookStrength = 1;
    const RGB input{0.2, 0.4, 0.6}, full = Grade(c).apply(input);
    c.lookStrength = 0.5; v = Grade(c).apply(input);
    require(near(v[0], (input[0] + full[0]) / 2) && near(v[1], (input[1] + full[1]) / 2) && near(v[2], (input[2] + full[2]) / 2), "half look strength blends style with unstyled correction");
    for (int look = 0; look < static_cast<int>(kLookCount); ++look) {
        c = {}; c.look = static_cast<Look>(look); c.lookStrength = 0; c.exposure = 1;
        v = Grade(c).apply(input);
        require(near(v[0], 0.4) && near(v[1], 0.8) && near(v[2], 1.2), "zero look strength retains manual exposure for every style");
    }
    c = {}; c.lookStrength = -0.1; require(!valid(c), "negative look strength rejected");
    c.lookStrength = 1.1; require(!valid(c), "excess look strength rejected");
    c.lookStrength = std::numeric_limits<double>::quiet_NaN(); require(!valid(c), "nonfinite look strength rejected");
    std::cout << "Color engine: " << checks << " checks passed\n";
}
