#include "halation.hpp"
#include "pipeline.hpp"
#include "avata2_lut.hpp"
#include <iostream>
#include <cstdlib>

namespace {
int checks = 0;
void require(bool ok, const char* message) {
    ++checks; if (!ok) { std::cerr << "FAIL: " << message << '\n'; std::exit(1); }
}
bool near(double a, double b, double epsilon = 1e-7) { return std::abs(a - b) < epsilon; }
}
int main() {
    using namespace mendes;
    require(!halationPlan(HalationPreset::Off, 1080).enabled(), "off has no spatial processing");
    const auto low = halationPlan(HalationPreset::Minimum, 1080);
    const auto medium = halationPlan(HalationPreset::Medium, 1080);
    const auto high = halationPlan(HalationPreset::High, 1080);
    require(low.radiusX == 3 && medium.radiusX == 5 && high.radiusX == 8, "preset widths at 1080 lines");
    require(low.amount < medium.amount && medium.amount < high.amount, "preset amounts increase");
    require(halationPlan(HalationPreset::High, 2160).radiusY == 16, "4K frame scales the halo with frame height");
    const auto proxy = halationPlan(HalationPreset::High, 2160, 0.5, 0.5);
    require(proxy.radiusX == high.radiusX && proxy.radiusY == high.radiusY, "half-resolution 4K uses 1080 halo size");
    const auto anamorphic = halationPlan(HalationPreset::High, 1080, 1, 1, 2);
    require(anamorphic.radiusX == 4 && anamorphic.radiusY == 8, "PAR preserves physical halo shape");
    require(halationPlan(HalationPreset::High, 1e9).radiusY == 128, "radius bound limits pathological geometry");
    int rejected = 0;
    for (auto preset : {static_cast<HalationPreset>(-1), static_cast<HalationPreset>(4)})
        try { (void)halationPlan(preset, 1080); } catch (const std::invalid_argument&) { ++rejected; }
    try { (void)halationPlan(HalationPreset::Medium, 0); } catch (const std::invalid_argument&) { ++rejected; }
    try { (void)halationPlan(HalationPreset::Medium, 1080, 0); } catch (const std::invalid_argument&) { ++rejected; }
    require(rejected == 4, "invalid presets and geometry rejected");
    require(halationEmission({0.6, 0.6, 0.6}, 1) == 0, "midtones do not emit");
    require(near(halationEmission({1, 1, 1}, 1), 1), "white highlight emits");
    require(near(halationEmission({1, 1, 1}, 0.25), 0.25), "alpha weights emission");
    require(halationEmission({100, 100, 100}, 0) == 0, "hidden transparent RGB cannot contaminate halo");
    require(halationEmission({NAN, 1, 1}, 1) == 0, "nonfinite pixels do not spread contamination");
    require(halationEmission({10, 10, 10}, 1) == 4, "HDR emission is bounded without clipping output RGB");
    const auto warm = halationColor(0.5, 0, high);
    require(near(warm[0], 0.24) && warm[0] > warm[1] && warm[1] > warm[2], "halo is red-orange");
    require(halationColor(0.4, 0.5, high) == RGB{}, "highlight core is not tinted globally");

    // Independent closed-form impulse oracle: convolution of three radius-1
    // uniform 1D kernels is [1,3,6,7,6,3,1]/27; 2D response is its outer product.
    HaloBuffer impulse;
    require(impulse.build({-6, -6, 7, 7}, {-6, -6, 7, 7}, {1, 1, 1},
        [](int x, int y) { return x == 0 && y == 0 ? 1.0 : 0.0; }, [] { return false; }), "impulse renders");
    constexpr double kernel[] = {1, 3, 6, 7, 6, 3, 1};
    double energy = 0;
    for (int y = -6; y <= 6; ++y) for (int x = -6; x <= 6; ++x) {
        const double expected = std::abs(x) <= 3 && std::abs(y) <= 3 ? kernel[x + 3] * kernel[y + 3] / 729 : 0;
        require(near(impulse.at(x, y), expected), "blur matches independent finite-support impulse response");
        energy += impulse.at(x, y);
    }
    require(near(energy, 1), "normalized blur conserves impulse energy");

    double previousEnergy = 0;
    for (auto plan : {low, medium, high}) {
        HaloBuffer full, tile, tight;
        const RectI source{-65, -40, 66, 41}, region{-8, -12, 17, 13};
        auto sample = [](int x, int y) { return x >= 1 && x <= 9 && y >= -4 && y <= 5 ? 1.0 : 0.0; };
        require(full.build(source, source, plan, sample, [] { return false; }), "full frame builds");
        require(tile.build(region, source, plan, sample, [] { return false; }), "tile builds with neighbors");
        require(tight.build(region, intersect(expand(region, plan.supportX(), plan.supportY()), source), plan,
            sample, [] { return false; }), "host-provided cropped ROI builds");
        for (int y = region.y1; y < region.y2; ++y) for (int x = region.x1; x < region.x2; ++x) {
            require(near(full.at(x, y), tile.at(x, y)) && near(full.at(x, y), tight.at(x, y)), "whole, tiled and cropped-neighbor results agree");
        }
        double haloEnergy = 0;
        for (int y = source.y1; y < source.y2; ++y) for (int x = source.x1; x < source.x2; ++x)
            haloEnergy += halationColor(full.at(x, y), sample(x, y), plan)[0];
        require(haloEnergy > previousEnergy, "integrated halo increases from minimum to high");
        previousEnergy = haloEnergy;
        require(full.at(0, 0) > 0 && halationColor(full.at(0, 0), 0, plan)[0] > 0, "dark neighbor receives halo from a bright source");
        require(halationColor(full.at(5, 0), 1, plan) == RGB{}, "bright core remains unchanged");
        HaloBuffer dim;
        require(dim.build(source, source, plan, [](int, int) { return halationEmission({0.3, 0.3, 0.3}, 1); }, [] { return false; }), "dim field renders");
        require(dim.at(0, 0) == 0, "no glow without highlights");
    }
    HaloBuffer cancelled;
    int rows = 0;
    require(!cancelled.build({0, 0, 30, 30}, {0, 0, 30, 30}, high, [](int, int) { return 1; },
        [&] { return ++rows > 3; }), "cancellation interrupts emission pass");
    rows = 0;
    require(!cancelled.build({0, 0, 30, 30}, {0, 0, 30, 30}, high, [](int, int) { return 1; },
        [&] { return ++rows > 35; }), "cancellation interrupts blur pass");
    require(cancelled.build({0, 0, 0, 0}, {0, 0, 30, 30}, high, [](int, int) { return 1; }, [] { return false; }), "empty tile is safe");
    require(cancelled.at(0, 0) == 0, "empty tile has no stale data");

    Controls c;
    c.look = Look::CommercialTeal; c.lookStrength = 0.6; c.mix = 0.35;
    const auto cube = avata2Cube();
    Pipeline pipe(c, cube);
    Controls full = c; full.mix = 1;
    const RGB input{0.25, 0.5, 0.75}, addition{0.1, 0.023, 0.004};
    const auto graded = Grade(full).apply(cube->sample(input));
    const auto result = pipe.apply(input, addition);
    for (int n = 0; n < 3; ++n) {
        require(near(pipe.postGrade(input)[n], graded[n]), "halation sees the converted, styled image");
        require(near(result[n], input[n] + c.mix * (graded[n] + addition[n] - input[n])), "global mix is applied after halation");
    }
    c.mix = 0;
    require(Pipeline(c, cube).apply(input, addition) == input, "mix zero bypasses LUT, style and halo exactly");
    c.mix = 1; c.lookStrength = 0;
    const auto zeroStyle = Pipeline(c, cube).apply(input, addition);
    const auto normalized = cube->sample(input);
    for (int n = 0; n < 3; ++n) require(near(zeroStyle[n], normalized[n] + addition[n]), "style zero retains LUT and halo");
    std::cout << "Halation: " << checks << " checks passed\n";
}
