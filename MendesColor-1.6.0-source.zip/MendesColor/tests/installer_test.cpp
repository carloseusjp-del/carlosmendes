#include "../installer/transaction.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <iterator>

namespace {
namespace fs = std::filesystem;
int checks = 0;
void require(bool ok, const char* text) {
    ++checks; if (!ok) throw std::runtime_error(text);
}
void write(const fs::path& path, const std::string& text) {
    fs::create_directories(path.parent_path());
    std::ofstream out(path); out << text; out.close();
    if (!out) throw std::runtime_error("Test fixture write failed");
}
std::string read(const fs::path& path) {
    std::ifstream in(path); return {std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
}
template<class Function> void fails(Function fn) {
    bool failed = false; try { fn(); } catch (const std::exception&) { failed = true; }
    require(failed, "Expected installation failure");
}
struct Temp {
    fs::path root = fs::temp_directory_path() / ("mendes-installer-" + std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    Temp() { if (!fs::create_directory(root)) throw std::runtime_error("Test directory exists"); }
    ~Temp() { std::error_code ec; fs::remove_all(root, ec); }
};
}
int main() {
    try {
        Temp temp;
        auto plugins = temp.root / "Common Files/OFX/Plugins";
        auto backups = temp.root / "Common Files/MendesColor/Backups";
        const fs::path binary = "Contents/Win64/MendesColor.ofx";
        auto first = mendes_setup::install(plugins, backups, "first", [&](const fs::path& stage) { write(stage / binary, "first build"); });
        require(first.backup.empty(), "Fresh install needs no backup");
        require(read(first.destination / binary) == "first build", "Fresh payload installed");
        write(first.destination / "user-note.txt", "preserve this note");
        auto second = mendes_setup::install(plugins, backups, "second", [&](const fs::path& stage) { write(stage / binary, "second build"); });
        require(read(second.destination / binary) == "second build", "New payload replaces old version");
        require(read(second.backup / binary) == "first build", "Old binary preserved in backup");
        require(read(second.backup / "user-note.txt") == "preserve this note", "Existing extra files preserved in backup");
        require(second.backup.parent_path() == backups, "Backup is outside the plugin scan directory");
        require(!fs::exists(plugins / ".mendes-stage-second"), "Successful install removes staging through commit");
        fails([&] { mendes_setup::install(plugins, backups, "corrupt", [&](const fs::path& stage) {
            write(stage / binary, "partial write"); throw std::runtime_error("Payload verification failed");
        }); });
        require(read(second.destination / binary) == "second build", "Verification failure leaves installed version intact");
        require(!fs::exists(plugins / ".mendes-stage-corrupt"), "Failed preparation cleans only its staging directory");
        fails([&] { mendes_setup::install(plugins, backups, "commit-error", [&](const fs::path& stage) {
            write(stage / binary, "new build"); fs::remove_all(stage); // force a real rename failure after old version moves
        }); });
        require(read(second.destination / binary) == "second build", "Commit failure restores the installed bundle");
        require(!fs::exists(backups / "commit-error-MendesColor.ofx.bundle"), "Rollback restores the whole backup to its original location");
        write(plugins / ".mendes-stage-collision/keep.txt", "pre-existing staging");
        fails([&] { mendes_setup::install(plugins, backups, "collision", [](const fs::path&) {}); });
        require(read(plugins / ".mendes-stage-collision/keep.txt") == "pre-existing staging", "Pre-existing staging is not deleted or overwritten");
        write(backups / "backup-collision-MendesColor.ofx.bundle/keep.txt", "existing backup");
        fails([&] { mendes_setup::install(plugins, backups, "backup-collision", [&](const fs::path& stage) { write(stage / binary, "new"); }); });
        require(read(second.destination / binary) == "second build", "Backup collision leaves old version installed");
        require(read(backups / "backup-collision-MendesColor.ofx.bundle/keep.txt") == "existing backup", "Backup collision preserves existing backup");
        auto foreign = temp.root / "other-plugins";
        write(foreign / "MendesColor.ofx.bundle", "unrelated file");
        fails([&] { mendes_setup::install(foreign, backups, "foreign", [](const fs::path&) {}); });
        require(read(foreign / "MendesColor.ofx.bundle") == "unrelated file", "Non-directory collision is preserved");
        fails([&] { mendes_setup::install(plugins, backups, "../escape", [](const fs::path&) {}); });
        std::cout << "Installer file transaction: " << checks << " checks passed (portable filesystem tests)\n";
    } catch (const std::exception& error) { std::cerr << "Installer test failed: " << error.what() << '\n'; return 1; }
}
