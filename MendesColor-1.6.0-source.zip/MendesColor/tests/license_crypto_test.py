"""Independent validation of the encrypted signer and public-key identity."""

import re
import struct
from pathlib import Path

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

ROOT = Path(__file__).resolve().parents[1]


def values(path: Path, name: str) -> bytes:
    source = path.read_text()
    match = re.search(rf"{name}\[\]\s*=\s*\{{(.*?)\}};", source)
    if not match:
        raise AssertionError(f"missing {name}")
    return bytes(int(item.strip(), 16) for item in match.group(1).split(","))


secret = ROOT / "admin/license_secret.hpp"
public = values(ROOT / "src/license_public.hpp", "kPublicKeyBlob")
salt = values(secret, "kSalt")
nonce = values(secret, "kNonce")
tag = values(secret, "kTag")
ciphertext = values(secret, "kEncryptedPrivateKey")
iterations = int(
    re.search(r"kPbkdf2Iterations\s*=\s*(\d+)ULL", secret.read_text()).group(1)
)
password = (ROOT / "build/private/license-studio-password.txt").read_text().strip().encode()
derived = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=iterations).derive(password)
private = AESGCM(derived).decrypt(nonce, ciphertext + tag, b"MendesColor-License-Studio-1")
public_magic, public_size = struct.unpack("<II", public[:8])
private_magic, private_size = struct.unpack("<II", private[:8])
assert (public_magic, private_magic, public_size, private_size) == (0x31534345, 0x32534345, 32, 32)
assert public[8:] == private[8:72]
x = int.from_bytes(private[8:40], "big")
y = int.from_bytes(private[40:72], "big")
d = int.from_bytes(private[72:], "big")
key = ec.derive_private_key(d, ec.SECP256R1())
numbers = key.public_key().public_numbers()
assert numbers.x == x and numbers.y == y
message = b"MC16\nMC-0123-4567-89AB-CDEF-0123-4567-89AB-CDEF\nPERPETUAL\nVGVzdA"
signature = key.sign(message, ec.ECDSA(hashes.SHA256()))
key.public_key().verify(signature, message, ec.ECDSA(hashes.SHA256()))
assert private not in secret.read_bytes()
artifacts = [
    ROOT / "dist/MendesColor.ofx.bundle/Contents/Win64/MendesColor.ofx",
    ROOT / "dist/MendesColorActivate.exe",
    ROOT / "dist/MendesColor-License-Studio-1.6.0.exe",
    ROOT / "dist/MendesColor-1.6.0-Setup.exe",
    ROOT / "dist/MendesColor-1.6.0-Windows-x64.zip",
    ROOT / "dist/MendesColor-1.6.0-source.zip",
    ROOT / "dist/MendesColor-Owner-Kit-1.6.0.zip",
]
for artifact in artifacts:
    if artifact.is_file():
        packaged = artifact.read_bytes()
        assert password not in packaged, f"administrative password leaked into {artifact.name}"
        assert private not in packaged, f"plaintext private key leaked into {artifact.name}"
studio = ROOT / "dist/MendesColor-License-Studio-1.6.0.exe"
if studio.is_file():
    assert ciphertext in studio.read_bytes(), "Studio is missing its encrypted signer"
print(
    "License crypto identity: encrypted signer/public key verified; "
    "no plaintext secret in release artifacts"
)
