#include "license_format.hpp"
#include <cstdlib>
#include <iostream>

namespace {
int checks = 0;
void require(bool value, const char *message) {
    ++checks;
    if (!value) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}
template <class Function> void rejected(Function function, const char *message) {
    bool caught = false;
    try {
        function();
    } catch (const std::exception &) {
        caught = true;
    }
    require(caught, message);
}
} // namespace

int main() {
    using namespace mendes::license;
    const Fields fields{"MC-0123-4567-89AB-CDEF-0123-4567-89AB-CDEF", "2030-12-31", "Cliente São Paulo"};
    const auto text = payload(fields);
    const auto parsed = parsePayload(text);
    require(parsed.machine == fields.machine && parsed.expiry == fields.expiry && parsed.customer == fields.customer,
            "UTF-8 customer and canonical fields round trip");
    std::array<unsigned char, 64> signature{};
    for (std::size_t i = 0; i < signature.size(); ++i)
        signature[i] = static_cast<unsigned char>(i * 17);
    const auto license = token(text, signature);
    const auto decoded = parseToken(" \n" + license + "\r\n");
    require(decoded.payload == text && decoded.signature == signature, "formatted pasted key round trips");
    require(validExpiry("PERPETUAL") && validExpiry("2028-02-29") && !validExpiry("2027-02-29"),
            "perpetual and Gregorian expiry validation");
    require(validMachine(fields.machine) && !validMachine("MC-0123-4567"), "machine identifier shape validated");
    rejected([&] { parseToken(license + "A"); }, "modified signature encoding rejected");
    rejected([&] { parsePayload("MC16\n" + fields.machine + "\n2030-02-30\nQQ"); },
             "invalid calendar date rejected");
    rejected([&] { payload({fields.machine, "PERPETUAL", "bad\nname"}); },
             "field injection rejected");
    rejected([&] { base64UrlDecode("A"); }, "impossible base64url length rejected");
    std::cout << "License format: " << checks << " checks passed\n";
}
