#include "avata2_lut.hpp"
#include "gpu.hpp"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>

namespace {
int checks = 0;
void require(bool ok, const std::string &message) {
  ++checks;
  if (!ok) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
  }
}
} // namespace
int main() {
  using namespace mendes;
  GpuRenderer device(
      true); // Test-only CPU OpenCL device; production selects GPUs only.
  constexpr int w = 96, h = 64, x0 = -13, y0 = 7;
  std::vector<float> src(w * h * 4), cpu(src.size()), gpu(src.size());
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      auto p = &src[(y * w + x) * 4];
      p[3] = (x + y) % 13 == 0 ? 0.f : ((x + y) % 7 == 0 ? .35f : 1.f);
      p[0] = static_cast<float>((x * 13 + y * 3) % 1024 / 1023.0 * 1.4 - .1) *
             p[3];
      p[1] = static_cast<float>((x * 3 + y * 17) % 1024 / 1023.0) * p[3];
      p[2] = static_cast<float>((x * 7 + y * 11) % 1024 / 1023.0 * 2) * p[3];
    }
  RectI bounds{x0, y0, x0 + w, y0 + h};
  auto read = [&](int x, int y) -> const float * {
    return x < x0 || x >= x0 + w || y < y0 || y >= y0 + h
               ? nullptr
               : &src[((y - y0) * w + x - x0) * 4];
  };
  auto write = [&](int x, int y) { return &gpu[((y - y0) * w + x - x0) * 4]; };
  double maxDelta = 0;
  for (int scenario = 0; scenario < 50; ++scenario) {
    Controls c;
    c.look = Look::CommercialTeal;
    c.lookStrength = .8;
    AdvSettings s;
    auto preset = [&](AdvId id, int index) {
      for (auto [field, v] : designedPreset(id, index))
        s.set(field, v);
    };
    auto input = avata2Cube();
    std::shared_ptr<const Cube3D> custom;
    HalationPreset quick = HalationPreset::Off;
    if (scenario == 1 || scenario == 2 || scenario == 6 || scenario == 7) {
      preset(AdvId::HalationProfile, 2);
      preset(AdvId::BloomProfile, 3);
    }
    if (scenario == 2 || scenario == 6 || scenario == 7) {
      preset(AdvId::GrainPreset, 3);
      preset(AdvId::VignettePreset, 2);
      preset(AdvId::SkinPreset, 4);
      preset(AdvId::SplitToningPreset, 2);
      s.set(AdvId::BasicEnable, 1);
      s.set(AdvId::Exposure, .2);
    }
    if (scenario == 3)
      quick = HalationPreset::High;
    if (scenario == 4) {
      preset(AdvId::GrainPreset, 6);
      s.set(AdvId::GrainIsColored, 0);
    }
    if (scenario == 5) {
      s.set(AdvId::VignetteEnable, 1);
      s.set(AdvId::VignetteMaskMode, 1);
    }
    if (scenario == 6)
      s.set(AdvId::HalationMaskMode, 1);
    if (scenario == 7)
      s.set(AdvId::BloomMaskMode, 1);
    if (scenario >= 8 && scenario < 25)
      s.set(AdvId::FinishingTones, scenario - 7);
    if (scenario == 25) {
      s.set(AdvId::SkinEnable, 1);
      s.set(AdvId::ShowSkinSelection, 1);
    }
    if (scenario == 26) {
      preset(AdvId::ColorIntensityPreset, 4);
      s.set(AdvId::ColorIntensityHighlight, 1);
    }
    if (scenario == 27) {
      preset(AdvId::BwPreset, 2);
      s.set(AdvId::ColorMode, 2);
    }
    if (scenario == 28) {
      s.set(AdvId::BasicEnable, 1);
      s.set(AdvId::Gamma, 25);
      s.set(AdvId::Temperature, 20);
      s.set(AdvId::Highlights, -25);
      s.set(AdvId::ColourRichness, 35);
      s.set(AdvId::BleachBypass, 25);
      c.mix = .45;
    }
    if (scenario >= 29 && scenario <= 35) {
      input.reset();
      s.set(AdvId::ColorSpaceEnable, 1);
      s.set(AdvId::InputColorSpace, 2);
      s.set(AdvId::InputGamma, scenario - 29);
      s.set(AdvId::OutputColorSpace, 2);
      s.set(AdvId::ConversionOutput, scenario - 29);
      c.look = Look::WarmCinema;
    }
    if (scenario == 36) {
      std::istringstream text("LUT_3D_SIZE 2\n0 0 0\n0 0 1\n0 1 0\n0 1 1\n1 0 "
                              "0\n1 0 1\n1 1 0\n1 1 1\n");
      custom = std::make_shared<const Cube3D>(Cube3D::read(text));
      s.set(AdvId::CustomIntensity, 60);
    }
    if (scenario == 37) {
      preset(AdvId::BwPreset, 3);
      s.set(AdvId::ColorMode, 1);
    }
    if (scenario == 38) {
      input.reset();
      s.set(AdvId::ColorSpaceEnable, 1);
      s.set(AdvId::InputColorSpace, 1);
      s.set(AdvId::OutputColorSpace, 2);
      s.set(AdvId::ConversionOutput, 4);
    }
    if (scenario == 39) {
      preset(AdvId::GrainPreset, 8);
      s.set(AdvId::GrainRotation, 7);
    }
    if (scenario == 40) {
      std::ifstream file("tests/fixtures/identity.3dl");
      custom = std::make_shared<const Cube3D>(Cube3D::read3dl(file));
    }
    if (scenario == 41) {
      std::ostringstream text;
      text << "0 128 1023\n";
      const int values[] = {0, 512, 4095};
      for (int r = 0; r < 3; ++r)
        for (int green = 0; green < 3; ++green)
          for (int b = 0; b < 3; ++b)
            text << values[r] << ' ' << values[green] << ' ' << values[b]
                 << '\n';
      std::istringstream data(text.str());
      custom = std::make_shared<const Cube3D>(Cube3D::read3dl(data));
    }
    if (scenario == 42)
      preset(AdvId::BwPreset, 3);
    if (scenario == 43) {
      preset(AdvId::GrainPreset, 6);
      s.set(AdvId::GrainIntensity, 0);
    }
    if (scenario == 44) {
      preset(AdvId::VignettePreset, 3);
      preset(AdvId::BloomProfile, 4);
    }
    if (scenario == 45) {
      preset(AdvId::GrainPreset, 3);
      preset(AdvId::HalationProfile, 3);
      preset(AdvId::BloomProfile, 4);
    }
    if (scenario == 46) {
      quick = HalationPreset::Minimum;
      preset(AdvId::BloomProfile, 4);
    }
    if (scenario == 47) {
      s.set(AdvId::BasicEnable, 1);
      s.set(AdvId::Gamma, -75);
      s.set(AdvId::Gain, 75);
      s.set(AdvId::Temperature, -60);
    }
    if (scenario == 48) {
      s.set(AdvId::ColorSpaceEnable, 1);
      s.set(AdvId::InputColorSpace, 1);
      s.set(AdvId::OutputColorSpace, 2);
      s.set(AdvId::ConversionOutput, 5);
    }
    if (scenario == 49) {
      preset(AdvId::SplitToningPreset, 5);
      s.set(AdvId::SplitProtectNeutrals, 0);
    }
    const bool premult = scenario != 44;
    const auto encoding = scenario == 37 ? LutEncoding::Rec709OETFToGamma24
                                         : LutEncoding::Preserve;
    Pipeline pipeline(c, input, encoding,
                      std::make_shared<const Advanced>(s, custom));
    FrameGeometry g;
    g.left = x0;
    g.bottom = y0;
    g.width = w;
    g.height = h;
    g.time = 13.5;
    if (scenario == 45) {
      g.scaleX = .5;
      g.scaleY = .5;
      g.pixelAspect = 1.5;
      g.left = x0 * g.pixelAspect / g.scaleX;
      g.bottom = y0 / g.scaleY;
      g.width = w * g.pixelAspect / g.scaleX;
      g.height = h / g.scaleY;
    }
    configureFrame(g, pipeline, quick);
    FrameEngine engine(pipeline, g, read, premult);
    require(engine.build(bounds, bounds, [] { return false; }),
            "CPU reference builds");
    for (int y = y0; y < y0 + h; ++y)
      for (int x = x0; x < x0 + w; ++x)
        engine.pixel(read(x, y), &cpu[((y - y0) * w + x - x0) * 4], x, y);
    require(device.render(pipeline, g, bounds, bounds, premult, read, write,
                          [] { return false; }),
            "OpenCL render " + std::to_string(scenario) + ": " +
                device.status());
    double error = 0, relative = 0;
    bool finite = true, alpha = true;
    for (std::size_t i = 0; i < cpu.size(); ++i) {
      error = std::max(error, std::abs(double(cpu[i]) - gpu[i]));
      relative = std::max(relative, std::abs(double(cpu[i]) - gpu[i]) /
                                        (1 + std::abs(cpu[i])));
      finite = finite && std::isfinite(gpu[i]);
      if (i % 4 == 3)
        alpha = alpha && gpu[i] == src[i];
    }
    maxDelta = std::max(maxDelta, error);
    std::cout << "scenario=" << scenario << " max_error=" << error
              << " relative=" << relative << '\n';
    require(relative < 2e-4 && alpha && finite,
            "OpenCL/CPU parity scenario " + std::to_string(scenario));
    // Smaller output with a full source must agree with its full-frame output.
    auto reference = gpu;
    RectI tile{x0 + 17, y0 + 13, x0 + 54, y0 + 38};
    std::fill(gpu.begin(), gpu.end(), -77);
    require(device.render(pipeline, g, bounds, tile, premult, read, write,
                          [] { return false; }),
            "OpenCL tile renders");
    bool same = true;
    for (int y = y0; y < y0 + h; ++y)
      for (int x = x0; x < x0 + w; ++x) {
        bool inside =
            x >= tile.x1 && x < tile.x2 && y >= tile.y1 && y < tile.y2;
        for (int k = 0; k < 4; ++k) {
          auto i = ((y - y0) * w + x - x0) * 4 + k;
          same = same && gpu[i] == (inside ? reference[i] : -77);
        }
      }
    require(same, "OpenCL tile writes only the requested window");
    if (scenario == 2 || scenario == 45) {
      const auto crop =
          intersect(expand(tile, g.supportX(), g.supportY()), bounds);
      std::fill(gpu.begin(), gpu.end(), -77);
      require(device.render(pipeline, g, crop, tile, premult, read, write,
                            [] { return false; }),
              "OpenCL accepts source cropped to the requested dependency ROI");
      double error = 0;
      for (int y = tile.y1; y < tile.y2; ++y)
        for (int x = tile.x1; x < tile.x2; ++x)
          for (int k = 0; k < 4; ++k) {
            auto i = ((y - y0) * w + x - x0) * 4 + k;
            error = std::max(error, std::abs(double(reference[i]) - gpu[i]));
          }
      require(
          error < 2e-5,
          "cropped OpenCL source preserves full-frame pixels without seams");
    }
  }
  for (std::size_t look = 0; look < kLookCount; ++look) {
    Controls c;
    c.look = static_cast<Look>(look);
    c.lookStrength = .73;
    c.gamma = 1.15;
    Pipeline pipe(c, avata2Cube());
    FrameGeometry g;
    g.left = x0;
    g.bottom = y0;
    g.width = w;
    g.height = h;
    FrameEngine engine(pipe, g, read, true);
    engine.build(bounds, bounds, [] { return false; });
    require(device.render(pipe, g, bounds, bounds, true, read, write,
                          [] { return false; }),
            "OpenCL creative look dispatch");
    double error = 0;
    for (int y = y0; y < y0 + h; ++y)
      for (int x = x0; x < x0 + w; ++x) {
        float result[4]{};
        engine.pixel(read(x, y), result, x, y);
        auto actual = write(x, y);
        for (int k = 0; k < 4; ++k)
          error = std::max(error, std::abs(double(actual[k]) - result[k]));
      }
    require(error < 2e-5, "every GPU look agrees with the CPU recipe");
  }
  require(!device.render(Pipeline({}), FrameGeometry{}, bounds, bounds, true,
                         read, write, [] { return false; }),
          "identity bypass skips device work");
  std::fill(gpu.begin(), gpu.end(), -77);
  require(!device.render(Pipeline(Controls{1}), FrameGeometry{}, bounds, bounds,
                         true, read, write, [] { return true; }),
          "GPU cancellation falls back without publishing");
  require(std::all_of(gpu.begin(), gpu.end(), [](float x) { return x == -77; }),
          "cancelled GPU render never publishes partial pixels");
  device.shutdown();
  Controls again;
  again.look = Look::WarmCinema;
  Pipeline restart(again, avata2Cube());
  FrameGeometry restartGeometry;
  restartGeometry.left = x0;
  restartGeometry.bottom = y0;
  restartGeometry.width = w;
  restartGeometry.height = h;
  require(device.render(restart, restartGeometry, bounds, bounds, true, read,
                        write, [] { return false; }),
          "OpenCL cleanly reinitializes after an OFX unload/load cycle");
  std::cout << "OpenCL parity: " << checks
            << " checks passed; max abs error=" << maxDelta
            << "; device=" << device.status() << '\n';
}
