#include "avata2_lut.hpp"
#include "frame.hpp"
#include <atomic>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <thread>

namespace {
int checks = 0;
std::atomic<int> dispatches{0};
bool refuse = false, nested = false, partialFail = false;
void require(bool ok, const char *message) {
  ++checks;
  if (!ok) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
  }
}
OfxStatus spawn(OfxThreadFunctionV1 fn, unsigned n, void *arg) {
  ++dispatches;
  if (refuse)
    return kOfxStatErrExists;
  if (partialFail) {
    fn(0, n, arg);
    return kOfxStatFailed;
  }
  std::vector<std::thread> workers;
  for (unsigned i = 1; i < n; ++i)
    workers.emplace_back([=] { fn(i, n, arg); });
  fn(0, n, arg);
  for (auto &t : workers)
    t.join();
  return kOfxStatOK;
}
OfxStatus cpus(unsigned *n) {
  *n = 4;
  return kOfxStatOK;
}
int spawned() { return nested ? 1 : 0; }
} // namespace
int main() {
  using namespace mendes;
  OfxMultiThreadSuiteV1 suite{};
  suite.multiThread = spawn;
  suite.multiThreadNumCPUs = cpus;
  suite.multiThreadIsSpawnedThread = spawned;
  RowExecutor parallel(&suite), serial;
  std::array<int, 128> visits{};
  require(parallel.rows(-64, 64,
                        [&](int y) {
                          ++visits[static_cast<std::size_t>(y + 64)];
                          return true;
                        }),
          "parallel work completes");
  require(dispatches > 0 && std::all_of(visits.begin(), visits.end(),
                                        [](int v) { return v == 1; }),
          "nonzero-origin rows assigned once across real threads");
  refuse = true;
  visits.fill(0);
  require(parallel.rows(0, 128,
                        [&](int y) {
                          ++visits[static_cast<std::size_t>(y)];
                          return true;
                        }) &&
              std::all_of(visits.begin(), visits.end(),
                          [](int v) { return v == 1; }),
          "host dispatch refusal falls back without losing rows");
  refuse = false;
  nested = true;
  const int before = dispatches;
  require(parallel.rows(0, 128, [](int) { return true; }) &&
              dispatches == before,
          "nested host jobs stay serial");
  nested = false;
  require(!parallel.rows(0, 128, [](int) { return false; }),
          "worker cancellation reaches caller");
  bool caught = false;
  try {
    parallel.rows(0, 128,
                  [](int) -> bool { throw std::runtime_error("worker"); });
  } catch (const std::runtime_error &) {
    caught = true;
  }
  require(caught, "worker exceptions join and rethrow on the calling thread");
  partialFail = true;
  caught = false;
  try {
    parallel.rows(0, 128, [](int) { return true; });
  } catch (OfxStatus status) {
    caught = status == kOfxStatFailed;
  }
  require(caught,
          "partial host failure cannot return a partially written success");
  partialFail = false;
  constexpr int w = 96, h = 64;
  std::vector<float> source(w * h * 4), output(source.size()),
      single(source.size()), gold(source.size());
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      auto p = &source[(y * w + x) * 4];
      p[3] = (x + y) % 13 == 0 ? 0.0f : ((x + y) % 7 == 0 ? .35f : 1.0f);
      p[0] = static_cast<float>((x * 13 + y * 3) % 1024 / 1023.0);
      p[1] = static_cast<float>((x * 3 + y * 17) % 1024 / 1023.0);
      p[2] = static_cast<float>((x * 7 + y * 11) % 1024 / 1023.0);
      p[0] = (p[0] * 1.4f - .1f) * p[3];
      p[1] *= p[3];
      p[2] = (p[2] * 2.0f) * p[3];
    }
  std::ifstream fixture("tests/fixtures/v140-render.rgba32f", std::ios::binary);
  require(bool(fixture), "independent v1.4.0 render fixtures available");
  for (int scenario = 0; scenario < 8; ++scenario) {
    Controls c;
    c.look = Look::CommercialTeal;
    c.lookStrength = .8;
    AdvSettings settings;
    auto preset = [&](AdvId id, int index) {
      for (auto [field, v] : designedPreset(id, index))
        settings.set(field, v);
    };
    if (scenario == 1 || scenario == 2 || scenario >= 4) {
      preset(AdvId::HalationProfile, 2);
      preset(AdvId::BloomProfile, 3);
    }
    if (scenario == 2 || scenario >= 5) {
      preset(AdvId::GrainPreset, 3);
      preset(AdvId::VignettePreset, 2);
      preset(AdvId::SkinPreset, 4);
      preset(AdvId::SplitToningPreset, 2);
      settings.set(AdvId::BasicEnable, 1);
      settings.set(AdvId::Exposure, .2);
    }
    if (scenario == 6)
      settings.set(AdvId::HalationMaskMode, 1);
    if (scenario == 7)
      settings.set(AdvId::BloomMaskMode, 1);
    Pipeline pipeline(c, avata2Cube(), LutEncoding::Preserve,
                      std::make_shared<const Advanced>(settings));
    FrameGeometry geometry;
    geometry.width = w;
    geometry.height = h;
    geometry.time = 13.5;
    configureFrame(geometry, pipeline,
                   scenario == 3 ? HalationPreset::Medium
                                 : HalationPreset::Off);
    auto read = [&](int x, int y) -> const float * {
      return x < 0 || x >= w || y < 0 || y >= h ? nullptr
                                                : &source[(y * w + x) * 4];
    };
    auto render = [&](const RowExecutor &exec, std::vector<float> &dst) {
      FrameEngine engine(pipeline, geometry, read, true);
      if (!engine.build({0, 0, w, h}, {0, 0, w, h}, [] { return false; }, exec))
        return false;
      return exec.rows(0, h, [&](int y) {
        for (int x = 0; x < w; ++x)
          engine.pixel(read(x, y), &dst[(y * w + x) * 4], x, y);
        return true;
      });
    };
    require(render(parallel, output) && render(serial, single),
            "serial and parallel full processing complete");
    require(output == single,
            "parallelism preserves serial pixel results exactly");
    fixture.read(reinterpret_cast<char *>(gold.data()),
                 static_cast<std::streamsize>(gold.size() * sizeof(float)));
    require(bool(fixture), "reference frame complete");
    double error = 0;
    bool finite = true, alpha = true;
    for (std::size_t i = 0; i < gold.size(); ++i) {
      error = std::max(error, std::abs(double(output[i]) - gold[i]));
      finite = finite && std::isfinite(output[i]);
      if (i % 4 == 3)
        alpha = alpha && output[i] == source[i];
    }
    require(error <= 2e-6 && finite && alpha,
            "optimized frame preserves v1.4.0 appearance, alpha, signed/HDR "
            "and masks");
  }
  // Force multithreaded vertical strips (rather than just sampling/final rows).
  HaloBuffer a, b;
  HalationPlan plan{8, 5, 1};
  const RectI region{-11, 3, 2200, 67};
  auto impulse = [](int x, int y) { return x == 501 && y == 35 ? 1.0 : 0.0; };
  require(a.build(
              region, region, plan, impulse, [] { return false; }, true,
              parallel) &&
              b.build(region, region, plan, impulse, [] { return false; }),
          "wide spatial filter builds in parallel");
  bool same = true;
  for (int y = region.y1; y < region.y2; ++y)
    for (int x = region.x1; x < region.x2; ++x)
      same = same && a.at(x, y) == b.at(x, y);
  require(same, "vertical and horizontal parallel filters match scalar "
                "summation exactly");
  std::cout << "Performance regression: " << checks << " checks passed\n";
}
