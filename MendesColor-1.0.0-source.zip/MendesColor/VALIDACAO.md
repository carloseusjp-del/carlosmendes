# Validação da primeira versão

O pacote Windows entregue nesta sessão foi compilado com MinGW-w64 GCC 14
POSIX para x86-64, em modo otimizado, com avisos tratados como erros e runtimes
C++/GCC estáticos. O formato PE/DLL e os pontos de entrada foram conferidos.

Resultados executados no ambiente Linux:

- `make test`: **694 verificações** do motor e **88 verificações** do host OpenFX
  simulado passaram. A biblioteca Linux foi carregada dinamicamente pelo teste.
- O mesmo teste do host, recompilado com **AddressSanitizer e UndefinedBehaviorSanitizer**,
  passou sem diagnóstico, incluindo detecção de vazamentos habilitada.
- O **REA 6.8.0**, em Node.js 24.22.1, inspecionou o binário Windows gerado:
  exportações `OfxGetNumberOfPlugins` e `OfxGetPlugin`; arquitetura AMD64;
  importações de `KERNEL32.dll` e `msvcrt.dll`. Não há dependência declarada de
  DLLs externas do MinGW no import table examinado.

O SHA-256 do binário distribuído está no `manifest.json`. As evidências REA
incluídas em `verification/` referem-se a esse mesmo digest. A inspeção de
importações não substitui teste do carregador Windows nem garante a ausência
de toda forma de dependência dinâmica.

**Não executado:** Windows, DaVinci Resolve real, instalação PowerShell,
compilação MSVC, validação visual e medição de desempenho. Não foi estabelecida
uma versão mínima do Resolve. O pacote é uma primeira versão para validação
no host, não uma versão certificada para produção.

Os testes de RGB verificam comportamento da implementação própria. Não
demonstram equivalência com ToneLab e não foram comparados com sua saída.
