#include "color.hpp"
#include <cstdlib>
#include <iostream>
#include <limits>

int checks = 0;
void require(bool ok, const char* msg) {
    ++checks;
    if (!ok) { std::cerr << "FAIL: " << msg << '\n'; std::exit(1); }
}
bool near(double a, double b, double eps = 1e-6) { return std::abs(a - b) < eps; }
int main() {
    using namespace mendes;
    Controls c;
    require(valid(c), "default controls valid");
    RGB hdr{-0.2, 0.18, 4};
    require(Grade(c).apply(hdr) == hdr, "neutral preserves HDR and negatives exactly");
    c.exposure = 1;
    auto v = Grade(c).apply({0.25, 0.5, 1.5});
    require(near(v[0], 0.5) && near(v[1], 1) && near(v[2], 3), "one stop doubles RGB without clipping");
    c = {}; c.gamma = 2;
    v = Grade(c).apply({-0.25, 0.25, 4});
    require(near(v[0], -0.5) && near(v[1], 0.5) && near(v[2], 2), "signed gamma preserves negative sign");
    c = {}; c.saturation = 0;
    v = Grade(c).apply({1, 0, 0});
    require(near(v[0], 0.2126) && near(v[1], 0.2126) && near(v[2], 0.2126), "desaturation produces expected gray");
    c = {}; c.contrast = 2;
    v = Grade(c).apply({0.18, 0.18, 0.18});
    require(near(v[0], 0.18) && near(v[1], 0.18), "contrast leaves pivot fixed");
    c = {}; c.black = 0.1; c.white = 0.9;
    v = Grade(c).apply({0.1, 0.5, 0.9});
    require(near(v[0], 0) && near(v[1], 0.5) && near(v[2], 1), "black and white map endpoints");
    c = {}; c.exposure = 1; c.mix = 0.5;
    v = Grade(c).apply({0.2, 0.4, 1});
    require(near(v[0], 0.3) && near(v[1], 0.6) && near(v[2], 1.5), "mix blends original and grade");
    c.mix = 0;
    require(Grade(c).apply(hdr) == hdr, "zero mix is exact bypass");
    c = {}; c.temperature = 1;
    v = Grade(c).apply({0.5, 0.5, 0.5});
    require(v[0] > v[1] && v[1] > v[2], "positive temperature warms neutrals");
    c = {}; c.tint = 1;
    v = Grade(c).apply({0.5, 0.5, 0.5});
    require(v[0] > v[1] && v[2] > v[1], "positive tint favors magenta");
    float rgba[] = {0.1f, 0.2f, 0.3f, 0.5f}, output[4]{};
    c = {}; c.exposure = 1;
    Grade(c).pixel(rgba, output, true);
    require(near(output[0], 0.2) && near(output[1], 0.4) && near(output[2], 0.6) && output[3] == rgba[3], "premultiplied alpha is preserved");
    float zero[] = {0, 0, 0, 0};
    c.black = -0.1; Grade(c).pixel(zero, output, true);
    require(output[0] == 0 && output[1] == 0 && output[2] == 0 && output[3] == 0, "transparent premultiplied pixels remain transparent");
    c = {}; c.white = c.black;
    require(!valid(c), "coincident levels rejected");
    c.white = -0.1;
    require(!valid(c), "reversed levels rejected");
    c = {}; c.gamma = 0;
    require(!valid(c), "zero gamma rejected");
    c = {}; c.exposure = std::numeric_limits<double>::quiet_NaN();
    require(!valid(c), "nonfinite parameter rejected");
    for (int look = 0; look < 6; ++look) {
        c = {}; c.look = static_cast<Look>(look);
        require(valid(c), "preset controls valid");
        for (int n = -10; n <= 100; ++n) {
            v = Grade(c).apply({n * 0.01, n * 0.02, n * 0.04});
            require(std::isfinite(v[0]) && std::isfinite(v[1]) && std::isfinite(v[2]), "preset ramp produces finite HDR RGB");
        }
        if (look) require(Grade(c).apply({0.2, 0.4, 0.6}) != RGB{0.2, 0.4, 0.6}, "creative preset changes color");
    }
    std::cout << "Color engine: " << checks << " checks passed\n";
}
