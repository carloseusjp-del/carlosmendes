# Execute in an x64 Native Tools Command Prompt / Developer PowerShell for VS 2022.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) {
    throw 'Use Developer PowerShell for Visual Studio with the x64 C++ build tools.'
}
$out = Join-Path $root 'dist\MendesColor.ofx.bundle\Contents\Win64'
$build = Join-Path $root 'build\msvc'
New-Item -ItemType Directory -Path $out, $build -Force | Out-Null
Push-Location $build
try {
    & cl.exe /nologo /std:c++17 /EHsc /O2 /W4 /MT /LD "/I$root\src" "/I$root\vendor\openfx\include" "$root\src\plugin.cpp" /link "/OUT:$out\MendesColor.ofx"
    if ($LASTEXITCODE -ne 0) { throw 'Plugin compilation failed.' }
    & cl.exe /nologo /std:c++17 /EHsc /O2 /W4 /MT "/I$root\src" "$root\tests\color_test.cpp" /Fe:color_test.exe
    if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed.' }
    & .\color_test.exe
    if ($LASTEXITCODE -ne 0) { throw 'Color tests failed.' }
} finally { Pop-Location }
Write-Host ('Windows bundle generated in ' + $out)
Write-Host 'To package, run: python scripts/package.py'
