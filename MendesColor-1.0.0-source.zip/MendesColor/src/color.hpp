#pragma once

#include <algorithm>
#include <array>
#include <cmath>

namespace mendes {
// Independent creative RGB operations. No ToneLab code or LUTs are used.
enum class Look { Neutral, CoolCinema, WarmCinema, Vivid, SoftGreen, Earth };
struct Controls {
    double exposure = 0, contrast = 1, pivot = 0.18, gamma = 1;
    double temperature = 0, tint = 0, saturation = 1;
    double black = 0, white = 1, mix = 1;
    Look look = Look::Neutral;
};
using RGB = std::array<double, 3>;

inline bool valid(const Controls& c) {
    return std::isfinite(c.exposure) && std::abs(c.exposure) <= 10 &&
        std::isfinite(c.contrast) && c.contrast >= 0 && c.contrast <= 4 &&
        std::isfinite(c.pivot) && c.pivot >= 0.001 && c.pivot <= 1 &&
        std::isfinite(c.gamma) && c.gamma >= 0.1 && c.gamma <= 4 &&
        std::isfinite(c.temperature) && std::abs(c.temperature) <= 1 &&
        std::isfinite(c.tint) && std::abs(c.tint) <= 1 &&
        std::isfinite(c.saturation) && c.saturation >= 0 && c.saturation <= 3 &&
        std::isfinite(c.black) && c.black >= -1 && c.black <= 0.99 &&
        std::isfinite(c.white) && c.white >= 0.01 && c.white <= 16 &&
        c.white - c.black >= 0.0001 &&
        std::isfinite(c.mix) && c.mix >= 0 && c.mix <= 1 &&
        static_cast<int>(c.look) >= 0 && static_cast<int>(c.look) <= 5;
}
inline bool identity(const Controls& c) {
    return c.mix == 0 || (c.look == Look::Neutral && c.exposure == 0 &&
        c.contrast == 1 && c.gamma == 1 && c.temperature == 0 &&
        c.tint == 0 && c.saturation == 1 && c.black == 0 && c.white == 1);
}

class Grade {
    Controls c_;
    RGB gains_{};
    double exposure_ = 1, contrast_ = 1, saturation_ = 1;
public:
    explicit Grade(Controls c) : c_(c), contrast_(c.contrast), saturation_(c.saturation) {
        double temp = c.temperature, tint = c.tint, ev = c.exposure;
        switch (c.look) {
            case Look::CoolCinema: temp -= 0.22; contrast_ *= 1.12; saturation_ *= 0.9; break;
            case Look::WarmCinema: temp += 0.22; contrast_ *= 1.08; saturation_ *= 0.95; break;
            case Look::Vivid: contrast_ *= 1.15; saturation_ *= 1.2; break;
            case Look::SoftGreen: temp -= 0.05; tint -= 0.16; contrast_ *= 0.92; saturation_ *= 0.85; break;
            case Look::Earth: temp += 0.18; tint += 0.04; saturation_ *= 0.78; contrast_ *= 1.1; break;
            case Look::Neutral: break;
        }
        exposure_ = std::exp2(ev);
        // Artistic channel gains, not a calibrated Kelvin or chromatic-adaptation model.
        gains_ = {std::exp2(temp * 0.35 + tint * 0.12),
                  std::exp2(-tint * 0.24), std::exp2(-temp * 0.35 + tint * 0.12)};
    }
    bool isIdentity() const { return identity(c_); }
    RGB apply(RGB input) const {
        if (isIdentity()) return input;
        RGB v{};
        for (int i = 0; i < 3; ++i) {
            double x = (input[i] - c_.black) / (c_.white - c_.black);
            x = x * exposure_ * gains_[i];
            x = (x - c_.pivot) * contrast_ + c_.pivot;
            // Signed power retains negative/out-of-gamut values and does not clip HDR.
            if (c_.gamma != 1) x = std::copysign(std::pow(std::abs(x), 1.0 / c_.gamma), x);
            v[i] = x;
        }
        const double luma = 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
        for (int i = 0; i < 3; ++i) {
            const double graded = luma + saturation_ * (v[i] - luma);
            v[i] = input[i] + c_.mix * (graded - input[i]);
        }
        return v;
    }
    void pixel(const float* src, float* dst, bool premultiplied) const {
        const float alpha = src[3];
        if (isIdentity()) {
            std::copy_n(src, 4, dst);
            return;
        }
        RGB rgb{src[0], src[1], src[2]};
        if (premultiplied) {
            if (alpha == 0) { dst[0] = dst[1] = dst[2] = 0; dst[3] = alpha; return; }
            for (double& v : rgb) v /= alpha;
        }
        rgb = apply(rgb);
        for (int i = 0; i < 3; ++i) dst[i] = static_cast<float>(rgb[i] * (premultiplied ? alpha : 1.0));
        dst[3] = alpha;
    }
};
} // namespace mendes
