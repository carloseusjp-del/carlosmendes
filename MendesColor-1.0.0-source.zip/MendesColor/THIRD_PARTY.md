# Third-party notices

The `vendor/openfx/include` headers are from the official OpenFX project:
https://github.com/AcademySoftwareFoundation/openfx

Pinned revision: `c3f1c2dcf4f51762b794c4fc21181b4a501be1bf`.
Their license is reproduced in `vendor/openfx/LICENSE.md` and in the Windows
package as `OPENFX-LICENSE.md`. Individual copyright notices remain in the headers.
No OpenFX support library was linked.

The Windows release was cross-compiled with Debian MinGW-w64 GCC 14 (POSIX),
using statically linked GCC/C++ runtimes under the GCC Runtime Library Exception:
https://www.gnu.org/licenses/gcc-exception-3.1.html
MinGW-w64 runtime notices: https://www.mingw-w64.org/license/
The compiler itself is not redistributed in this package.

No ToneLab executable, code, artwork, preset, LUT, license key or SDK is included.
REA 6.8.0 was used to inspect the supplied installer; its output informed the
feature investigation, not the implementation of proprietary processing.
