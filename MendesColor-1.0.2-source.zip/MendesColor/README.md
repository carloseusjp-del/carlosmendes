# Mendes Color 1.0.2

Plugin OpenFX de correção de cor para **DaVinci Resolve no Windows x64**.
Implementação própria em C++17: não reproduz os algoritmos nem as aparências
exatas do ToneLab. O REA foi utilizado para investigar o instalador fornecido;
os efeitos deste projeto foram escritos independentemente.

## Instalar no Windows

1. Extraia **todo** o ZIP `MendesColor-1.0.2-Windows-x64.zip`.
2. Feche o DaVinci Resolve.
3. Copie a pasta **`MendesColor.ofx.bundle` inteira** para:

   ```text
   C:\Program Files\Common Files\OFX\Plugins\
   ```

   O caminho final do binário deve ser:

   ```text
   C:\Program Files\Common Files\OFX\Plugins\MendesColor.ofx.bundle\Contents\Win64\MendesColor.ofx
   ```

4. Reinicie o Resolve e procure **Mendes Color** na biblioteca **Effects / Open FX**,
   grupo **Mendes**. Se necessário, confira a habilitação do plugin em
   **Preferences > System > Video Plugins**; nomes de menus variam por versão.
5. Aplique a um node na página Color e abra seus controles no painel de efeitos.

Alternativa: execute o `Install.ps1` da pasta extraída em um PowerShell como
administrador. O script confere o SHA-256 e preserva uma versão anterior em
`C:\ProgramData\MendesColor\backups`. `-WhatIf` mostra o destino sem instalar.
Não é necessário executar script para fazer a instalação manual acima.

O pacote é uma DLL OpenFX, não um aplicativo que abre com duplo clique. Não há
servidor, cadastro, assinatura ou chave de licença. Para remover, feche o Resolve
e retire apenas a pasta `MendesColor.ofx.bundle` desse diretório.

## Correção 1.0.2: descrição opcional interrompia o registro

O log enviado do Resolve **21.1.1 build 10** mostra `OfxActionLoad` com status 0,
seguido de rejeição de `OfxPropPluginDescription` com status 3 (`ErrUnknown`) e
falha de `OfxActionDescribe` com o mesmo código. A versão anterior tratava essa
descrição cosmética como requisito e interrompia a descoberta do efeito.

A versão 1.0.2 permite que o host rejeite **essa propriedade opcional** com
`ErrUnknown` ou `ErrUnsupported`, prosseguindo com o registro de contextos,
formatos, clipes e controles. Erros reais (como falha de memória) e falhas de
propriedades obrigatórias continuam sendo propagados. Não há supressão geral
de erros. O motor de cores e o identificador do plugin foram preservados.

A versão 1.0.1 acrescentou suporte aos contextos **Filter e General**, mantido
aqui. O log demonstrou uma falha anterior à seleção do contexto, portanto a
correção de General, sozinha, não resolvia o erro reportado.

A regressão foi reproduzida em teste e passou após a correção, incluindo criação
e destruição de instâncias em hosts que rejeitam a descrição. A **nova versão
ainda precisa ser confirmada no Resolve real**; os testes locais não o executam.

Para atualizar, feche o Resolve e substitua a pasta completa já instalada pela
nova `MendesColor.ofx.bundle`. Evite manter uma segunda cópia antiga dentro do
diretório de plugins. `Install.ps1` preserva a versão anterior fora desse diretório.
Reabra o Resolve, verifique a habilitação em Video Plugins, abra um projeto e,
na página **Color**, abra o painel **Effects / Open FX**. Limpe a busca e confira
se a visualização não está limitada aos favoritos; procure **Mendes Color** no
grupo **Mendes**.

No Windows, o plugin registra as etapas de descoberta e seus códigos de
retorno em:

```text
%LOCALAPPDATA%\MendesColor\OpenFX.log
```

Cole esse caminho na barra do Explorador. Se o efeito continuar ausente, envie
o arquivo de log para identificar qual ação falhou ou foi solicitada. O log
contém apenas versão, ação/contexto, nome de propriedade que falhou e código de
retorno; não registra quadros, valores de controles ou caminhos do projeto.
O registro é de diagnóstico de inicialização, não de render por quadro.

Nesta versão, uma linha `optional property skipped | status=3` para
`OfxPropPluginDescription` é apenas o registro da incompatibilidade tolerada.
O importante é que a linha posterior `OfxActionDescribe` tenha **status 0** e
que `OfxImageEffectActionDescribeInContext` também termine com **status 0**.
Confira o prefixo **Mendes Color 1.0.2** para distinguir entradas novas das antigas.

## Controles

| Controle | Funcionamento |
|---|---|
| Creative Look | Neutral, Cool Cinema, Warm Cinema, Vivid, Soft Green ou Earth |
| Exposure | Ganho RGB `2^stops`, de -10 a +10 stops |
| Contrast | Contraste linear em torno do Pivot; 1 é neutro |
| Pivot | Ponto fixo do contraste; padrão 0,18 |
| Gamma | Potência RGB com preservação do sinal; 1 é neutro |
| Warm / Cool | Ganhos criativos por canal; positivo aquece, negativo esfria |
| Magenta / Green | Ganhos criativos por canal; positivo favorece magenta |
| Saturation | Saturação em torno de luminância ponderada RGB; 0 produz cinza |
| Black Point | Nível de entrada mapeado para 0 antes dos demais ajustes |
| White Point | Nível de entrada mapeado para 1 antes dos demais ajustes |
| Effect Mix | Mistura da correção completa com o original; 0 desliga o efeito |

**White Point deve superar Black Point em pelo menos 0,0001.** Uma combinação
inválida interrompe o render; ajuste os dois controles para retomar.

Todas as escolhas/controles podem ser animados pelo host. O padrão Neutral não
altera os pixels; o canal alfa é preservado. A renderização trata imagens
pré-multiplicadas e não pré-multiplicadas, tiles e stride negativo de memória.

As aparências são ajustes próprios de balanço, contraste e saturação; não são
LUTs extraídas, modelos de película ou cópias dos pacotes do ToneLab.

## Ordem e matemática

1. Níveis: `(RGB - black) / (white - black)`.
2. Exposição e ganhos RGB de temperatura/tint.
3. Contraste: `(RGB - pivot) * contrast + pivot`.
4. Gamma: `sign(RGB) * abs(RGB)^(1/gamma)`.
5. Saturação: `Y + saturation * (RGB - Y)`, com pesos
   `Y = 0.2126 R + 0.7152 G + 0.0722 B`.
6. Mistura entre entrada e correção.

O look modifica contraste, saturação e balanço antes dessas operações. O código
em `src/color.hpp` define integralmente os ajustes de cada aparência.
Não há clipping automático: valores negativos e acima de 1 são preservados
quando a operação permite. Isso não equivale a validação HDR colorimétrica.

O plugin recebe RGB no espaço de trabalho do host e **não faz transformação
automática de log, gamut, ACES ou Rec.709**. Os pesos são uma aproximação criativa
em espaços diferentes de Rec.709. Para exposição fisicamente significativa,
use entrada linear e gerencie as transformações com nodes CST/gestão de cor do
Resolve. Temperatura não representa Kelvin nem adaptação cromática calibrada.

## Estado da validação e limites

- Binário Windows x64 compilado por MinGW-w64, com runtime C++ estático.
- Motor testado com referências numéricas, rampas HDR/negativas, transparência,
  mistura, presets e parâmetros inválidos.
- Adaptador testado como biblioteca carregada por um **host OpenFX simulado**:
  descoberta, parâmetros, tempo, região, tiles, padding, stride negativo,
  premultiplicação, erros, cancelamento e liberação de imagens.
- **Esta versão 1.0.2 ainda não foi executada no Windows nem carregada no DaVinci Resolve real**:
  compatibilidade com versões, menus, exportação e aparência final precisam
  desse teste. Os testes simulados não demonstram validação no Resolve.
- Primeira versão **CPU**, RGBA float32. Não há implementação CUDA/OpenCL,
  máscara própria, curvas, scopes, redução de ruído, rastreamento ou LUTs.
  Não foi medido desempenho em 4K, e não se promete tempo real.
- O binário não tem assinatura digital de editor.

Teste inicial sugerido no Resolve: projeto de teste com rampa e imagem conhecida;
aplique Neutral e compare o bypass, aumente Exposure em 1 stop, confira Effect
Mix=0, experimente cada look, anime um controle e exporte alguns quadros.
Confira alfa num clipe transparente. Registre sua versão do Resolve e o resultado.

## Compilar e testar

Os headers oficiais OpenFX estão incluídos com licença e revisão em
`THIRD_PARTY.md`; não é necessário baixá-los durante a compilação.

### Linux (testes e biblioteca de teste)

Requer GCC/G++ com C++17 e GNU Make:

```sh
make test
```

### Gerar Windows a partir do Linux

Requer o compilador MinGW-w64 x64:

```sh
make windows WIN_CXX=x86_64-w64-mingw32-g++
python3 scripts/package.py
```

### Compilar no Windows

Abra **Developer PowerShell for VS 2022** com ferramentas C++ **x64**:

```powershell
.\scripts\build-windows.ps1
python scripts/package.py
```

O fluxo MSVC é fornecido para reconstrução local e **não foi executado neste
ambiente Linux**. O binário entregue foi gerado pelo fluxo MinGW acima.
O empacotamento requer Python 3 e cria ZIPs do plugin e do código-fonte em `dist`.
