# Validação da versão 1.0.2

O pacote Windows entregue nesta sessão foi compilado com MinGW-w64 GCC 14
POSIX para x86-64, em modo otimizado, com avisos tratados como erros e runtimes
C++/GCC estáticos. O formato PE/DLL e os pontos de entrada foram conferidos.

Resultados executados no ambiente Linux:

- `make test`: **694 verificações** do motor e **107 verificações** do host OpenFX
  simulado passaram. A biblioteca Linux foi carregada dinamicamente pelo teste.
- Regressão reportada pelo usuário reproduzida antes da correção: um host que
  devolve `ErrUnknown` para `OfxPropPluginDescription` faz `OfxActionDescribe`
  falhar. Após a correção, hosts que rejeitam essa propriedade com `ErrUnknown`
  ou `ErrUnsupported` completam a descrição, registram contextos/controles e
  criam/destroem a instância. Falhas de memória na descrição e rejeição de uma
  propriedade obrigatória continuam falhando, como esperado.
- Os testes de registro em Filter e General, incluídos na 1.0.1, continuam passando.
- O mesmo teste do host, recompilado com **AddressSanitizer e UndefinedBehaviorSanitizer**,
  passou sem diagnóstico, incluindo detecção de vazamentos habilitada.
- O **REA 6.8.0**, em Node.js 24.22.1, inspecionou o binário Windows gerado:
  exportações `OfxGetNumberOfPlugins` e `OfxGetPlugin`; arquitetura AMD64;
  importações de `KERNEL32.dll` e `msvcrt.dll`. Não há dependência declarada de
  DLLs externas do MinGW no import table examinado.

O SHA-256 do binário distribuído está no `manifest.json`. As evidências REA
incluídas em `verification/` referem-se a esse mesmo digest. A inspeção de
importações não substitui teste do carregador Windows nem garante a ausência
de toda forma de dependência dinâmica.

O log da **versão 1.0.1** enviado pelo usuário no Resolve **21.1.1 build 10**
confirma carga da biblioteca (status 0), rejeição de `OfxPropPluginDescription`
(status 3) e interrupção de `OfxActionDescribe` (status 3). Isso identifica um
bloqueio concreto de descoberta, anterior à seleção de contexto. A versão 1.0.2
corrige esse bloqueio; a confirmação do resultado no host real permanece pendente.

**Não executado aqui:** Windows, DaVinci Resolve real, instalação PowerShell,
compilação MSVC, validação visual e medição de desempenho. Não foi estabelecida
uma versão mínima do Resolve. O pacote é uma primeira versão para validação
no host, não uma versão certificada para produção. A escrita do log Windows da
1.0.1 foi confirmada pelo arquivo enviado pelo usuário; os logs da 1.0.2 ainda
precisam ser observados nesse ambiente.

Os testes de RGB verificam comportamento da implementação própria. Não
demonstram equivalência com ToneLab e não foram comparados com sua saída.
