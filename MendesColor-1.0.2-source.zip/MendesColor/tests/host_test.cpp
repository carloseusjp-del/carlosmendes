#include "ofxImageEffect.h"
#include <algorithm>
#include <cstdarg>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <iostream>
#include <map>
#include <memory>
#include <string>
#include <vector>

struct OfxPropertySetStruct {
    std::map<std::string, OfxStatus> stringFailures;
    std::map<std::string, std::vector<int>> ints;
    std::map<std::string, std::vector<double>> doubles;
    std::map<std::string, std::vector<std::string>> strings;
    std::map<std::string, std::vector<void*>> pointers;
};
struct OfxParamStruct { std::string type; OfxPropertySetStruct props; double value = 0; bool animated = false; };
struct OfxParamSetStruct { std::map<std::string, std::unique_ptr<OfxParamStruct>> values; };
struct OfxImageClipStruct { OfxPropertySetStruct props, image; bool fail = false; };
struct OfxImageEffectStruct {
    OfxPropertySetStruct props;
    OfxParamSetStruct params;
    std::map<std::string, std::unique_ptr<OfxImageClipStruct>> clips;
    bool abort = false;
};
namespace mock {
int checks = 0, acquired = 0, released = 0;
double sampledTime = -1;
void require(bool ok, const char* text) {
    ++checks; if (!ok) { std::cerr << "FAIL: " << text << '\n'; std::exit(1); }
}
template<class T> OfxStatus set(std::map<std::string, std::vector<T>>& m, const char* k, int n, T v) {
    if (n < 0) return kOfxStatErrBadIndex;
    auto& a = m[k]; if (a.size() <= static_cast<std::size_t>(n)) a.resize(n + 1);
    a[n] = v; return kOfxStatOK;
}
template<class T> OfxStatus get(std::map<std::string, std::vector<T>>& m, const char* k, int n, T* v) {
    auto a = m.find(k);
    if (a == m.end() || n < 0 || static_cast<std::size_t>(n) >= a->second.size()) return kOfxStatErrUnknown;
    *v = a->second[n]; return kOfxStatOK;
}
OfxStatus setInt(OfxPropertySetHandle p, const char* k, int n, int v) { return set(p->ints, k, n, v); }
OfxStatus setDouble(OfxPropertySetHandle p, const char* k, int n, double v) { return set(p->doubles, k, n, v); }
OfxStatus setString(OfxPropertySetHandle p, const char* k, int n, const char* v) {
    const auto failure = p->stringFailures.find(k);
    if (failure != p->stringFailures.end()) return failure->second;
    return set(p->strings, k, n, std::string(v));
}
OfxStatus setPointer(OfxPropertySetHandle p, const char* k, int n, void* v) { return set(p->pointers, k, n, v); }
OfxStatus getInt(OfxPropertySetHandle p, const char* k, int n, int* v) { return get(p->ints, k, n, v); }
OfxStatus getDouble(OfxPropertySetHandle p, const char* k, int n, double* v) { return get(p->doubles, k, n, v); }
OfxStatus getPointer(OfxPropertySetHandle p, const char* k, int n, void** v) { return get(p->pointers, k, n, v); }
OfxStatus getString(OfxPropertySetHandle p, const char* k, int n, char** v) {
    auto a = p->strings.find(k); if (a == p->strings.end() || n < 0 || static_cast<std::size_t>(n) >= a->second.size()) return kOfxStatErrUnknown;
    *v = a->second[n].data(); return kOfxStatOK;
}
OfxStatus getIntN(OfxPropertySetHandle p, const char* k, int n, int* v) {
    for (int i = 0; i < n; ++i) { auto s = getInt(p, k, i, v + i); if (s) return s; } return kOfxStatOK;
}
OfxStatus setDoubleN(OfxPropertySetHandle p, const char* k, int n, const double* v) {
    for (int i = 0; i < n; ++i) setDouble(p, k, i, v[i]);
    return kOfxStatOK;
}
OfxStatus effectProps(OfxImageEffectHandle e, OfxPropertySetHandle* p) { *p = &e->props; return kOfxStatOK; }
OfxStatus paramSet(OfxImageEffectHandle e, OfxParamSetHandle* p) { *p = &e->params; return kOfxStatOK; }
OfxStatus clipDefine(OfxImageEffectHandle e, const char* name, OfxPropertySetHandle* p) {
    auto c = std::make_unique<OfxImageClipStruct>(); *p = &c->props; e->clips[name] = std::move(c); return kOfxStatOK;
}
OfxStatus clipHandle(OfxImageEffectHandle e, const char* name, OfxImageClipHandle* c, OfxPropertySetHandle* p) {
    if (!e->clips.count(name)) return kOfxStatErrUnknown;
    *c = e->clips[name].get(); if (p) *p = &(*c)->props; return kOfxStatOK;
}
OfxStatus clipProps(OfxImageClipHandle c, OfxPropertySetHandle* p) { *p = &c->props; return kOfxStatOK; }
OfxStatus image(OfxImageClipHandle c, OfxTime, const OfxRectD*, OfxPropertySetHandle* p) {
    if (c->fail) return kOfxStatFailed;
    *p = &c->image; ++acquired; return kOfxStatOK;
}
OfxStatus release(OfxPropertySetHandle) { ++released; return kOfxStatOK; }
int abort(OfxImageEffectHandle e) { return e->abort ? 1 : 0; }
OfxStatus rod(OfxImageClipHandle, OfxTime, OfxRectD* r) { *r = {-2, 3, 2, 6}; return kOfxStatOK; }
OfxStatus defineParam(OfxParamSetHandle s, const char* type, const char* name, OfxPropertySetHandle* p) {
    auto a = std::make_unique<OfxParamStruct>(); a->type = type; *p = &a->props; s->values[name] = std::move(a); return kOfxStatOK;
}
OfxStatus paramHandle(OfxParamSetHandle s, const char* name, OfxParamHandle* p, OfxPropertySetHandle* props) {
    if (!s->values.count(name)) return kOfxStatErrUnknown;
    *p = s->values[name].get();
    if ((*p)->type == kOfxParamTypeDouble) (*p)->value = (*p)->props.doubles[kOfxParamPropDefault][0];
    else (*p)->value = (*p)->props.ints[kOfxParamPropDefault][0];
    if (props) *props = &(*p)->props;
    return kOfxStatOK;
}
OfxStatus valueAt(OfxParamHandle p, OfxTime time, ...) {
    va_list args; va_start(args, time);
    if (p->type == kOfxParamTypeChoice) *va_arg(args, int*) = static_cast<int>(p->value);
    else *va_arg(args, double*) = p->value + (p->animated ? time : 0);
    va_end(args); sampledTime = time; return kOfxStatOK;
}
OfxPropertySuiteV1 properties{};
OfxImageEffectSuiteV1 images{};
OfxParameterSuiteV1 parameters{};
const void* fetch(OfxPropertySetHandle, const char* name, int version) {
    if (version != 1) return nullptr;
    if (std::strcmp(name, kOfxPropertySuite) == 0) return &properties;
    if (std::strcmp(name, kOfxImageEffectSuite) == 0) return &images;
    if (std::strcmp(name, kOfxParameterSuite) == 0) return &parameters;
    return nullptr;
}
void init() {
    properties.propSetInt = setInt; properties.propSetDouble = setDouble;
    properties.propSetString = setString; properties.propSetPointer = setPointer;
    properties.propGetInt = getInt; properties.propGetDouble = getDouble;
    properties.propGetString = getString; properties.propGetPointer = getPointer;
    properties.propGetIntN = getIntN; properties.propSetDoubleN = setDoubleN;
    images.getPropertySet = effectProps; images.getParamSet = paramSet; images.clipDefine = clipDefine;
    images.clipGetHandle = clipHandle; images.clipGetPropertySet = clipProps;
    images.clipGetImage = image; images.clipReleaseImage = release; images.abort = abort;
    images.clipGetRegionOfDefinition = rod;
    parameters.paramDefine = defineParam; parameters.paramGetHandle = paramHandle; parameters.paramGetValueAtTime = valueAt;
}
void setupImage(OfxImageClipStruct* c, float* data, bool premult, int stride) {
    auto p = &c->image;
    setPointer(p, kOfxImagePropData, 0, data);
    setString(p, kOfxImageEffectPropPixelDepth, 0, kOfxBitDepthFloat);
    setString(p, kOfxImageEffectPropComponents, 0, kOfxImageComponentRGBA);
    auto mode = premult ? kOfxImagePreMultiplied : kOfxImageUnPreMultiplied;
    setString(p, kOfxImageEffectPropPreMultiplication, 0, mode);
    setString(&c->props, kOfxImageEffectPropPreMultiplication, 0, mode);
    int bounds[] = {-2, 3, 2, 6};
    for (int n = 0; n < 4; ++n) setInt(p, kOfxImagePropBounds, n, bounds[n]);
    setInt(p, kOfxImagePropRowBytes, 0, stride);
}
} // namespace mock

int main(int argc, char** argv) {
    using namespace mock;
    require(argc == 2, "shared plugin path supplied");
    void* library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!library) { std::cerr << dlerror() << '\n'; return 1; }
    auto getCount = reinterpret_cast<int (*)()>(dlsym(library, "OfxGetNumberOfPlugins"));
    auto getPlugin = reinterpret_cast<OfxPlugin* (*)(int)>(dlsym(library, "OfxGetPlugin"));
    require(getCount && getPlugin && getCount() == 1, "exports and plugin count");
    require(!getPlugin(-1) && !getPlugin(1), "out-of-range plugin index");
    auto plugin = getPlugin(0); init();
    require(plugin->pluginVersionMajor == 1 && plugin->pluginVersionMinor == 2, "updated OpenFX version identifies the replacement build");
    OfxHost host{nullptr, fetch}; plugin->setHost(&host);
    auto call = plugin->mainEntry;
    require(call(kOfxActionLoad, nullptr, nullptr, nullptr) == kOfxStatOK, "load obtains host suites");
    for (OfxStatus status : {kOfxStatErrUnknown, kOfxStatErrUnsupported}) {
        OfxImageEffectStruct withoutDescription;
        withoutDescription.props.stringFailures[kOfxPropPluginDescription] = status;
        require(call(kOfxActionDescribe, &withoutDescription, nullptr, nullptr) == kOfxStatOK, "host rejecting optional plugin description still completes discovery");
        require(withoutDescription.props.strings[kOfxImageEffectPropSupportedContexts].size() == 2, "rejected description does not stop context registration");
        OfxPropertySetStruct contextIn;
        setString(&contextIn, kOfxImageEffectPropContext, 0, kOfxImageEffectContextGeneral);
        require(call(kOfxImageEffectActionDescribeInContext, &withoutDescription, &contextIn, nullptr) == kOfxStatOK, "host without description can describe controls");
        require(call(kOfxActionCreateInstance, &withoutDescription, nullptr, nullptr) == kOfxStatOK, "host without description can create an instance");
        require(call(kOfxActionDestroyInstance, &withoutDescription, nullptr, nullptr) == kOfxStatOK, "host without description can destroy its instance");
    }
    OfxImageEffectStruct descriptionMemoryFailure;
    descriptionMemoryFailure.props.stringFailures[kOfxPropPluginDescription] = kOfxStatErrMemory;
    require(call(kOfxActionDescribe, &descriptionMemoryFailure, nullptr, nullptr) == kOfxStatErrMemory, "real descriptor failure remains fatal even for optional metadata");
    OfxImageEffectStruct requiredFailure;
    requiredFailure.props.stringFailures[kOfxImageEffectPropSupportedContexts] = kOfxStatErrUnknown;
    require(call(kOfxActionDescribe, &requiredFailure, nullptr, nullptr) == kOfxStatErrUnknown, "missing required context property is not silently ignored");
    OfxImageEffectStruct effect;
    require(call(kOfxActionDescribe, &effect, nullptr, nullptr) == kOfxStatOK, "describe plugin");
    const auto contexts = effect.props.strings[kOfxImageEffectPropSupportedContexts];
    require(std::find(contexts.begin(), contexts.end(), kOfxImageEffectContextGeneral) != contexts.end(), "advertise General context for hosts that select it");
    require(std::find(contexts.begin(), contexts.end(), kOfxImageEffectContextFilter) != contexts.end(), "retain Filter context");
    OfxImageEffectStruct generalEffect;
    OfxPropertySetStruct generalIn;
    setString(&generalIn, kOfxImageEffectPropContext, 0, kOfxImageEffectContextGeneral);
    require(call(kOfxImageEffectActionDescribeInContext, &generalEffect, &generalIn, nullptr) == kOfxStatOK, "describe in General context");
    require(call(kOfxActionCreateInstance, &generalEffect, nullptr, nullptr) == kOfxStatOK, "create General instance");
    require(call(kOfxActionDestroyInstance, &generalEffect, nullptr, nullptr) == kOfxStatOK, "destroy General instance");
    OfxImageEffectStruct unsupportedEffect;
    OfxPropertySetStruct unsupportedIn;
    setString(&unsupportedIn, kOfxImageEffectPropContext, 0, kOfxImageEffectContextGenerator);
    require(call(kOfxImageEffectActionDescribeInContext, &unsupportedEffect, &unsupportedIn, nullptr) == kOfxStatErrUnsupported, "unsupported contexts remain rejected");
    OfxPropertySetStruct in, out;
    setString(&in, kOfxImageEffectPropContext, 0, kOfxImageEffectContextFilter);
    require(call(kOfxImageEffectActionDescribeInContext, &effect, &in, nullptr) == kOfxStatOK, "describe filter and controls");
    require(effect.params.values.size() == 12, "eleven controls plus page");
    require(call(kOfxActionCreateInstance, &effect, nullptr, nullptr) == kOfxStatOK, "create instance");
    setDouble(&in, kOfxPropTime, 0, 0);
    require(call(kOfxImageEffectActionIsIdentity, &effect, &in, &out) == kOfxStatOK, "neutral identity action");
    require(out.strings[kOfxPropName][0] == "Source", "identity source clip");
    require(call(kOfxImageEffectActionGetRegionOfDefinition, &effect, &in, &out) == kOfxStatOK, "source region of definition");
    require(out.doubles[kOfxImageEffectPropRegionOfDefinition] == std::vector<double>({-2, 3, 2, 6}), "region propagated");
    constexpr int row = 20;
    std::vector<float> source(row * 3, -99), dest(row * 3, -77);
    for (int y = 0; y < 3; ++y) for (int x = 0; x < 4; ++x) {
        auto s = source.data() + y * row + x * 4;
        for (int c = 0; c < 3; ++c) s[c] = (c + 1) * 0.1f + y * 0.01f + x * 0.005f;
        s[3] = 0.5f;
    }
    auto src = effect.clips["Source"].get(), dst = effect.clips["Output"].get();
    setupImage(src, source.data() + 2 * row, true, -row * static_cast<int>(sizeof(float)));
    setupImage(dst, dest.data(), true, row * sizeof(float));
    require(call(kOfxImageEffectActionGetClipPreferences, &effect, nullptr, &out) == kOfxStatOK, "clip preferences");
    require(out.strings[kOfxImageEffectPropPreMultiplication][0] == kOfxImagePreMultiplied, "premultiplication negotiated");
    int tile[] = {-1, 4, 1, 6};
    for (int n = 0; n < 4; ++n) setInt(&in, kOfxImageEffectPropRenderWindow, n, tile[n]);
    effect.params.values["exposure"]->animated = true;
    setDouble(&in, kOfxPropTime, 0, 1);
    require(call(kOfxImageEffectActionIsIdentity, &effect, &in, &out) == kOfxStatReplyDefault, "animated grade is not identity");
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "render animated tile, nonzero origin, negative input stride");
    require(sampledTime == 1, "parameters sampled at requested time");
    for (int y = 0; y < 3; ++y) for (int x = 0; x < row; ++x) {
        bool inside = y >= 1 && x >= 4 && x < 12;
        const float value = 2 * ((x % 4 + 1) * 0.1f + (2 - y) * 0.01f + (x / 4) * 0.005f);
        float expected = !inside ? -77.0f : (x % 4 == 3 ? 0.5f : value);
        require(std::abs(dest[y * row + x] - expected) < 1e-6f, "tile pixels, alpha and padding preserved");
    }
    require(acquired == released, "all normal images released");
    effect.params.values["white"]->value = 0.01;
    effect.params.values["black"]->value = 0.2;
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatErrValue, "invalid levels fail before render");
    effect.params.values["white"]->value = 1; effect.params.values["black"]->value = 0;
    dst->fail = true;
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatFailed, "output acquisition failure preserved");
    require(acquired == released, "source released when output acquisition fails"); dst->fail = false;
    setString(&dst->image, kOfxImageEffectPropPixelDepth, 0, kOfxBitDepthByte);
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatErrImageFormat, "unsupported depth rejected");
    require(acquired == released, "images released after format failure");
    setString(&dst->image, kOfxImageEffectPropPixelDepth, 0, kOfxBitDepthFloat);
    effect.abort = true;
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatFailed, "host abort observed");
    require(acquired == released, "images released after abort");
    require(call(kOfxActionDestroyInstance, &effect, nullptr, nullptr) == kOfxStatOK, "instance destroyed");
    require(effect.props.pointers[kOfxPropInstanceData][0] == nullptr, "instance data cleared");
    require(call(kOfxActionUnload, nullptr, nullptr, nullptr) == kOfxStatOK, "unload");
    dlclose(library);
    std::cout << "Mock OpenFX host: " << checks << " checks passed (not a Resolve validation)\n";
}
