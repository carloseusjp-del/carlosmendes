#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <bcrypt.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <tlhelp32.h>
#include <array>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <sstream>
#include <vector>
#include "version.hpp"
#include "transaction.hpp"
#include "setup_payloads.hpp"

namespace {
constexpr const wchar_t* title = L"Mendes Color — Instalador";
struct ComOwner {
    bool initialized=false;
    ComOwner(){const HRESULT status=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);initialized=SUCCEEDED(status);if(FAILED(status)&&status!=RPC_E_CHANGED_MODE)throw std::runtime_error("Cannot initialize Windows COM.");}
    ~ComOwner(){if(initialized)CoUninitialize();}
};
void checkHashStatus(NTSTATUS status) {
    if (status < 0) throw std::runtime_error("Windows SHA-256 verification failed.");
}
std::string sha256(const unsigned char* data, std::size_t size) {
    if (size > std::numeric_limits<ULONG>::max()) throw std::runtime_error("Payload too large.");
    struct Hash {
        BCRYPT_ALG_HANDLE algorithm = nullptr;
        BCRYPT_HASH_HANDLE hash = nullptr;
        ~Hash() { if (hash) BCryptDestroyHash(hash); if (algorithm) BCryptCloseAlgorithmProvider(algorithm, 0); }
    } owner;
    checkHashStatus(BCryptOpenAlgorithmProvider(&owner.algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0));
    checkHashStatus(BCryptCreateHash(owner.algorithm, &owner.hash, nullptr, 0, nullptr, 0, 0));
    checkHashStatus(BCryptHashData(owner.hash, const_cast<PUCHAR>(data), static_cast<ULONG>(size), 0));
    std::array<unsigned char, 32> digest{};
    checkHashStatus(BCryptFinishHash(owner.hash, digest.data(), static_cast<ULONG>(digest.size()), 0));
    std::ostringstream text; text << std::hex << std::setfill('0');
    for (auto value : digest) text << std::setw(2) << static_cast<unsigned>(value);
    return text.str();
}
std::filesystem::path commonFiles() {
    PWSTR value = nullptr;
    const HRESULT status = SHGetKnownFolderPath(FOLDERID_ProgramFilesCommon, 0, nullptr, &value);
    if (FAILED(status) || !value) throw std::runtime_error("Cannot locate the Windows Common Files directory.");
    const std::filesystem::path result(value);
    CoTaskMemFree(value);
    return result;
}
bool resolveRunning() {
    const HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) throw std::runtime_error("Cannot inspect running processes. Close Resolve and try again.");
    PROCESSENTRY32W entry{}; entry.dwSize = sizeof(entry);
    BOOL found = Process32FirstW(snapshot, &entry);
    if (!found) { CloseHandle(snapshot); throw std::runtime_error("Cannot inspect running processes."); }
    bool running = false;
    do {
        if (_wcsicmp(entry.szExeFile, L"Resolve.exe") == 0) { running = true; break; }
    } while (Process32NextW(snapshot, &entry));
    CloseHandle(snapshot);
    return running;
}
std::string identifier() {
    GUID id{};
    if (FAILED(CoCreateGuid(&id))) throw std::runtime_error("Cannot create installer staging identifier.");
    wchar_t wide[40]{};
    if (!StringFromGUID2(id, wide, 40)) throw std::runtime_error("Cannot format installer staging identifier.");
    std::string value;
    for (wchar_t c : wide) if ((c >= L'0' && c <= L'9') || (c >= L'A' && c <= L'F') || (c >= L'a' && c <= L'f') || c == L'-')
        value.push_back(static_cast<char>(c));
    return value;
}
void writePayloads(HINSTANCE module, const std::filesystem::path& root) {
    for (const auto& file : mendes_setup::payloads) {
        HRSRC resource = FindResourceW(module, MAKEINTRESOURCEW(file.id), MAKEINTRESOURCEW(10));
        if (!resource) throw std::runtime_error("An installer resource is missing.");
        const DWORD bytes = SizeofResource(module, resource);
        HGLOBAL loaded = LoadResource(module, resource);
        if (!loaded) throw std::runtime_error("An installer resource could not be loaded.");
        const auto data = static_cast<const unsigned char*>(LockResource(loaded));
        if (!data || bytes != file.bytes || sha256(data, bytes) != file.sha256)
            throw std::runtime_error("Installer payload checksum mismatch. Download the installer again.");
        const auto target = root / file.path;
        std::filesystem::create_directories(target.parent_path());
        std::ofstream out(target, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(data), bytes); out.close();
        if (!out) throw std::runtime_error("Cannot write plugin files. Check disk space and permissions.");
        std::ifstream in(target, std::ios::binary);
        const std::vector<unsigned char> written{std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
        if (in.bad() || written.size() != bytes || sha256(written.data(), written.size()) != file.sha256)
            throw std::runtime_error("Written plugin checksum mismatch. Previous version was not replaced.");
    }
}
void shortcut(const std::filesystem::path& target) {
    PWSTR programsValue=nullptr;
    if(FAILED(SHGetKnownFolderPath(FOLDERID_CommonPrograms,0,nullptr,&programsValue))||!programsValue)
        throw std::runtime_error("Cannot locate the Windows Start Menu.");
    const std::filesystem::path folder=std::filesystem::path(programsValue)/L"Mendes Color";
    CoTaskMemFree(programsValue);
    std::filesystem::create_directories(folder);
    IShellLinkW* link=nullptr;
    if(FAILED(CoCreateInstance(CLSID_ShellLink,nullptr,CLSCTX_INPROC_SERVER,IID_IShellLinkW,
                               reinterpret_cast<void**>(&link)))||!link)
        throw std::runtime_error("Cannot create the activation shortcut.");
    HRESULT status=link->SetPath(target.c_str());
    if(SUCCEEDED(status))status=link->SetDescription(L"Ativar a licença offline do Mendes Color");
    if(SUCCEEDED(status))status=link->SetIconLocation(target.c_str(),0);
    IPersistFile* file=nullptr;
    if(SUCCEEDED(status))status=link->QueryInterface(IID_IPersistFile,reinterpret_cast<void**>(&file));
    if(SUCCEEDED(status))status=file->Save((folder/L"Ativar Mendes Color.lnk").c_str(),TRUE);
    if(file)
        file->Release();
    link->Release();
    if(FAILED(status))throw std::runtime_error("Cannot save the activation shortcut.");
}
HFONT interfaceFont(int points,bool bold=false) {
    HDC screen=GetDC(nullptr);const int height=-MulDiv(points,GetDeviceCaps(screen,LOGPIXELSY),72);
    ReleaseDC(nullptr,screen);
    return CreateFontW(height,0,0,0,bold?FW_SEMIBOLD:FW_NORMAL,FALSE,FALSE,FALSE,
        DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,
        DEFAULT_PITCH|FF_DONTCARE,L"Segoe UI");
}
void fill(HDC dc,const RECT& rectangle,COLORREF color) {
    HBRUSH brush=CreateSolidBrush(color);FillRect(dc,&rectangle,brush);DeleteObject(brush);
}
void roundBox(HDC dc,const RECT& rectangle,COLORREF background,COLORREF border,int radius=12) {
    HBRUSH brush=CreateSolidBrush(background);HPEN pen=CreatePen(PS_SOLID,1,border);
    const auto previousBrush=SelectObject(dc,brush);const auto previousPen=SelectObject(dc,pen);
    RoundRect(dc,rectangle.left,rectangle.top,rectangle.right,rectangle.bottom,radius,radius);
    SelectObject(dc,previousPen);SelectObject(dc,previousBrush);DeleteObject(pen);DeleteObject(brush);
}
void drawLabel(HDC dc,const std::wstring& value,RECT rectangle,HFONT font,COLORREF color,
               UINT format=DT_LEFT|DT_VCENTER|DT_SINGLELINE) {
    const auto previous=SelectObject(dc,font);SetTextColor(dc,color);SetBkMode(dc,TRANSPARENT);
    DrawTextW(dc,value.c_str(),-1,&rectangle,format);SelectObject(dc,previous);
}
struct InstallerPrompt {
    HINSTANCE module{};std::wstring destination,backup;HWND window{};bool approved=false,hover=false;
    HFONT titleFont{},subtitleFont{},labelFont{},bodyFont{},smallFont{},buttonFont{};HICON icon{};
    RECT installButton{32,491,788,546};
    ~InstallerPrompt(){
        for(HFONT font:{titleFont,subtitleFont,labelFont,bodyFont,smallFont,buttonFont})if(font)DeleteObject(font);
        if(icon)DestroyIcon(icon);
    }
    void paint(HDC dc) {
        const COLORREF background=RGB(17,20,24),panel=RGB(21,26,31),border=RGB(45,53,61);
        const COLORREF white=RGB(239,243,246),muted=RGB(138,149,159);
        RECT client{};GetClientRect(window,&client);fill(dc,client,background);
        DrawIconEx(dc,32,22,icon,62,62,0,nullptr,DI_NORMAL);
        drawLabel(dc,L"MENDES COLOR",{112,25,530,62},titleFont,white);
        drawLabel(dc,L"Color grading cinematográfico • DaVinci Resolve • OpenFX",
                  {112,63,610,87},subtitleFont,muted);
        roundBox(dc,{648,28,788,62},RGB(43,34,30),RGB(121,69,49),10);
        drawLabel(dc,L"●  LICENÇA OFFLINE",{660,28,779,62},smallFont,RGB(242,151,105),
                  DT_CENTER|DT_VCENTER|DT_SINGLELINE);
        fill(dc,{32,105,788,106},border);
        drawLabel(dc,L"ATIVAÇÃO E LICENÇA",{32,119,300,141},labelFont,muted);
        roundBox(dc,{32,146,788,208},panel,RGB(43,78,88),12);
        roundBox(dc,{48,162,80,194},RGB(40,93,88),RGB(66,147,135),8);
        drawLabel(dc,L"✓",{48,162,80,194},bodyFont,RGB(111,224,180),DT_CENTER|DT_VCENTER|DT_SINGLELINE);
        drawLabel(dc,L"Ativação segura vinculada à máquina",{94,153,560,179},bodyFont,white);
        drawLabel(dc,L"Ativador incluído • sem conta e sem conexão",{94,177,560,199},smallFont,muted);
        drawLabel(dc,L"INCLUÍDO",{672,163,770,192},labelFont,RGB(111,224,180),DT_RIGHT|DT_VCENTER|DT_SINGLELINE);
        drawLabel(dc,L"RECURSOS INCLUÍDOS",{32,226,300,248},labelFont,muted);
        const wchar_t* tools[]={L"✓  84 Looks",L"✓  LUT Avata 2",L"✓  Ajustes básicos",L"✓  Custom LUT",
            L"✓  Film Grain",L"✓  Halation",L"✓  Bloom",L"✓  GPU OpenCL",L"✓  16 slots LUT",L"✓  Anterior / Próximo"};
        int x=32,y=255;
        for(const auto* tool:tools) {
            const int width=28+static_cast<int>(wcslen(tool))*7;if(x+width>788){x=32;y+=39;}
            roundBox(dc,{x,y,x+width,y+31},panel,border,10);
            drawLabel(dc,tool,{x+10,y,x+width-8,y+31},smallFont,RGB(118,221,179));x+=width+9;
        }
        fill(dc,{32,344,788,345},border);
        drawLabel(dc,L"INSTALAR EM",{32,357,300,379},labelFont,muted);
        roundBox(dc,{32,385,788,463},RGB(21,34,40),RGB(49,103,119),12);
        roundBox(dc,{49,405,81,437},RGB(52,137,145),RGB(81,181,190),8);
        drawLabel(dc,L"✓",{49,405,81,437},bodyFont,RGB(8,31,34),DT_CENTER|DT_VCENTER|DT_SINGLELINE);
        drawLabel(dc,L"OpenFX — DaVinci Resolve",{96,394,730,420},bodyFont,white);
        drawLabel(dc,destination,{96,420,754,446},smallFont,muted,DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
        drawLabel(dc,L"Backup automático: "+backup,{32,464,788,486},smallFont,muted,DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
        const COLORREF left=hover?RGB(69,183,215):RGB(76,169,205),right=hover?RGB(142,215,164):RGB(131,202,160);
        const int bands=48,span=installButton.right-installButton.left;
        for(int band=0;band<bands;++band) {
            const double t=static_cast<double>(band)/(bands-1);
            const auto blend=[&](int a,int b){return static_cast<int>(a+(b-a)*t);};
            RECT slice{installButton.left+span*band/bands,installButton.top,
                       installButton.left+span*(band+1)/bands+1,installButton.bottom};
            fill(dc,slice,RGB(blend(GetRValue(left),GetRValue(right)),blend(GetGValue(left),GetGValue(right)),blend(GetBValue(left),GetBValue(right))));
        }
        drawLabel(dc,L"INSTALAR / ATUALIZAR MENDES COLOR",installButton,buttonFont,RGB(7,22,26),DT_CENTER|DT_VCENTER|DT_SINGLELINE);
        fill(dc,{32,565,788,566},border);
        drawLabel(dc,L"Mendes Color " MENDES_WIDE_LITERAL(MENDES_COLOR_VERSION),{32,575,240,601},smallFont,muted);
        drawLabel(dc,L"Copyright © 2026 Carlos Mendes",{250,575,570,601},smallFont,muted,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
        drawLabel(dc,L"Instalador offline",{610,575,788,601},smallFont,muted,DT_RIGHT|DT_VCENTER|DT_SINGLELINE);
    }
    static LRESULT CALLBACK procedure(HWND window,UINT message,WPARAM wParam,LPARAM lParam) {
        InstallerPrompt* self=reinterpret_cast<InstallerPrompt*>(GetWindowLongPtrW(window,GWLP_USERDATA));
        if(message==WM_NCCREATE) {
            self=static_cast<InstallerPrompt*>(reinterpret_cast<CREATESTRUCTW*>(lParam)->lpCreateParams);
            SetWindowLongPtrW(window,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(self));self->window=window;
        }
        if(!self)return DefWindowProcW(window,message,wParam,lParam);
        if(message==WM_PAINT){PAINTSTRUCT paint{};HDC dc=BeginPaint(window,&paint);self->paint(dc);EndPaint(window,&paint);return 0;}
        if(message==WM_MOUSEMOVE){POINT point{GET_X_LPARAM(lParam),GET_Y_LPARAM(lParam)};const bool inside=PtInRect(&self->installButton,point)!=FALSE;if(inside!=self->hover){self->hover=inside;InvalidateRect(window,&self->installButton,FALSE);}return 0;}
        if(message==WM_SETCURSOR){POINT point{};GetCursorPos(&point);ScreenToClient(window,&point);if(PtInRect(&self->installButton,point)){SetCursor(LoadCursorW(nullptr,IDC_HAND));return TRUE;}}
        if(message==WM_LBUTTONUP){POINT point{GET_X_LPARAM(lParam),GET_Y_LPARAM(lParam)};if(PtInRect(&self->installButton,point)){self->approved=true;DestroyWindow(window);}return 0;}
        if(message==WM_KEYDOWN&&wParam==VK_RETURN){self->approved=true;DestroyWindow(window);return 0;}
        if(message==WM_KEYDOWN&&wParam==VK_ESCAPE){DestroyWindow(window);return 0;}
        if(message==WM_DESTROY){PostQuitMessage(0);return 0;}
        return DefWindowProcW(window,message,wParam,lParam);
    }
    bool show() {
        titleFont=interfaceFont(23,true);subtitleFont=interfaceFont(9);labelFont=interfaceFont(8,true);
        bodyFont=interfaceFont(11,true);smallFont=interfaceFont(9);buttonFont=interfaceFont(11,true);
        icon=static_cast<HICON>(LoadImageW(module,MAKEINTRESOURCEW(1),IMAGE_ICON,96,96,LR_DEFAULTCOLOR));
        WNDCLASSEXW type{};type.cbSize=sizeof(type);type.lpfnWndProc=procedure;type.hInstance=module;
        type.hCursor=LoadCursorW(nullptr,IDC_ARROW);type.hIcon=icon;type.hbrBackground=CreateSolidBrush(RGB(17,20,24));
        type.lpszClassName=L"MendesColorInstallerWindow";
        if(!RegisterClassExW(&type)&&GetLastError()!=ERROR_CLASS_ALREADY_EXISTS)throw std::runtime_error("Cannot create installer interface.");
        RECT bounds{0,0,820,610};AdjustWindowRect(&bounds,WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,FALSE);
        window=CreateWindowExW(0,type.lpszClassName,L"Mendes Color Installer",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,
            CW_USEDEFAULT,CW_USEDEFAULT,bounds.right-bounds.left,bounds.bottom-bounds.top,nullptr,nullptr,module,this);
        if(!window)throw std::runtime_error("Cannot open installer interface.");
        RECT actual{};GetWindowRect(window,&actual);SetWindowPos(window,nullptr,
            (GetSystemMetrics(SM_CXSCREEN)-(actual.right-actual.left))/2,(GetSystemMetrics(SM_CYSCREEN)-(actual.bottom-actual.top))/2,
            0,0,SWP_NOSIZE|SWP_NOZORDER);ShowWindow(window,SW_SHOW);UpdateWindow(window);
        MSG message{};while(GetMessageW(&message,nullptr,0,0)>0){TranslateMessage(&message);DispatchMessageW(&message);}
        DeleteObject(type.hbrBackground);UnregisterClassW(type.lpszClassName,module);return approved;
    }
};
bool confirmInstall(HINSTANCE module,const std::wstring& destination,const std::wstring& backup) {
    InstallerPrompt prompt;prompt.module=module;prompt.destination=destination;prompt.backup=backup;return prompt.show();
}
std::wstring wideError(const std::exception& e) {
    const std::string text(e.what());
    const int length = MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), nullptr, 0);
    std::wstring result(length > 0 ? length : 0, L' ');
    if (length > 0) MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), result.data(), length);
    return result;
}
}
int WINAPI wWinMain(HINSTANCE module, HINSTANCE, PWSTR, int) {
    std::filesystem::path backups;
    try {
        ComOwner com;
        if (!IsUserAnAdmin()) {
            MessageBoxW(nullptr, L"Abra este instalador como administrador para instalar o plugin no Resolve.", title, MB_OK | MB_ICONERROR);
            return 1;
        }
        while (resolveRunning()) {
            if (MessageBoxW(nullptr, L"Feche o DaVinci Resolve para atualizar o plugin. Seus projetos não serão encerrados pelo instalador.\n\nDepois clique em Repetir.", title, MB_RETRYCANCEL | MB_ICONINFORMATION) != IDRETRY) return 0;
        }
        const auto common = commonFiles();
        const auto plugins = common / L"OFX" / L"Plugins";
        backups = common / L"MendesColor" / L"Backups";
        if(!confirmInstall(module,(plugins/L"MendesColor.ofx.bundle").wstring(),backups.wstring()))return 0;
        const auto result = mendes_setup::install(plugins, backups, identifier(),
            [&](const std::filesystem::path& stage) { writePayloads(module, stage); });
        const auto activator=plugins/L"MendesColor.ofx.bundle"/L"Contents"/L"Resources"/L"MendesColorActivate.exe";
        shortcut(activator);
        std::wstring done = L"Mendes Color instalado com sucesso.\n\nAbra o Resolve e procure Mendes Color em Effects / Open FX.\n"
            L"Abra Ativar Mendes Color no menu Iniciar para copiar o ID da máquina e inserir sua key.\n";
        if (!result.backup.empty()) done += L"\nBackup anterior:\n" + result.backup.wstring();
        MessageBoxW(nullptr, done.c_str(), title, MB_OK | MB_ICONINFORMATION);
        return 0;
    } catch (const std::exception& e) {
        const std::wstring error = L"A instalação não foi concluída.\n\n" + wideError(e) +
            (backups.empty() ? L"" : L"\n\nPasta de backups:\n" + backups.wstring());
        MessageBoxW(nullptr, error.c_str(), title, MB_OK | MB_ICONERROR);
        return 1;
    }
}
