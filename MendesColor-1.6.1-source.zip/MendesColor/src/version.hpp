#pragma once
#define MENDES_COLOR_VERSION "1.6.1"
#define MENDES_COLOR_COPYRIGHT "Copyright (C) 2026 Carlos Mendes. All rights reserved."
#define MENDES_COLOR_COPYRIGHT_W L"Copyright © 2026 Carlos Mendes. Todos os direitos reservados."
#define MENDES_WIDE_LITERAL_INNER(value) L##value
#define MENDES_WIDE_LITERAL(value) MENDES_WIDE_LITERAL_INNER(value)
namespace mendes {
inline constexpr unsigned kOfxVersionMajor = 1;
inline constexpr unsigned kOfxVersionMinor = 601;
}
