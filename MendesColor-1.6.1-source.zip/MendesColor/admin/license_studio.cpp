#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <commctrl.h>
#include <array>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include "license_format.hpp"
#include "license_secret.hpp"
#include "license_windows.hpp"
#include "version.hpp"
#include "win_ui.hpp"

namespace {
constexpr int ID_PASSWORD = 101, ID_CUSTOMER = 102, ID_MACHINE = 103, ID_EXPIRY = 104,
              ID_GENERATE = 105, ID_OUTPUT = 106, ID_COPY = 107, ID_STATUS = 108;
constexpr wchar_t kClass[] = L"MendesLicenseStudioWindow";

struct CryptoOwner {
    BCRYPT_ALG_HANDLE sha{}, aes{}, ecdsa{};
    BCRYPT_KEY_HANDLE symmetric{}, signer{};
    ~CryptoOwner() {
        if (signer) BCryptDestroyKey(signer);
        if (symmetric) BCryptDestroyKey(symmetric);
        if (ecdsa) BCryptCloseAlgorithmProvider(ecdsa, 0);
        if (aes) BCryptCloseAlgorithmProvider(aes, 0);
        if (sha) BCryptCloseAlgorithmProvider(sha, 0);
    }
};

struct SecretText {
    std::string &value;
    ~SecretText() {
        if (!value.empty())
            SecureZeroMemory(value.data(), value.size());
    }
};

std::array<unsigned char, 64> sign(const std::string &payloadText, const std::string &password) {
    CryptoOwner owner;
    mendes::license::cryptoCheck(
        BCryptOpenAlgorithmProvider(&owner.sha, BCRYPT_SHA256_ALGORITHM, nullptr,
                                    BCRYPT_ALG_HANDLE_HMAC_FLAG),
        "PBKDF2 provider");
    std::array<unsigned char, 32> derived{};
    mendes::license::cryptoCheck(
        BCryptDeriveKeyPBKDF2(owner.sha,
                             reinterpret_cast<PUCHAR>(const_cast<char *>(password.data())),
                             static_cast<ULONG>(password.size()),
                             const_cast<PUCHAR>(mendes::license_admin::kSalt),
                             static_cast<ULONG>(sizeof(mendes::license_admin::kSalt)),
                             mendes::license_admin::kPbkdf2Iterations, derived.data(),
                             static_cast<ULONG>(derived.size()), 0),
        "PBKDF2");
    mendes::license::cryptoCheck(
        BCryptOpenAlgorithmProvider(&owner.aes, BCRYPT_AES_ALGORITHM, nullptr, 0), "AES provider");
    mendes::license::cryptoCheck(
        BCryptSetProperty(owner.aes, BCRYPT_CHAINING_MODE,
                          reinterpret_cast<PUCHAR>(const_cast<wchar_t *>(BCRYPT_CHAIN_MODE_GCM)),
                          sizeof(BCRYPT_CHAIN_MODE_GCM), 0),
        "AES-GCM mode");
    mendes::license::cryptoCheck(
        BCryptGenerateSymmetricKey(owner.aes, &owner.symmetric, nullptr, 0, derived.data(),
                                   static_cast<ULONG>(derived.size()), 0),
        "AES key");
    SecureZeroMemory(derived.data(), derived.size());
    BCRYPT_AUTHENTICATED_CIPHER_MODE_INFO authentication{};
    BCRYPT_INIT_AUTH_MODE_INFO(authentication);
    authentication.pbNonce = const_cast<PUCHAR>(mendes::license_admin::kNonce);
    authentication.cbNonce = static_cast<ULONG>(sizeof(mendes::license_admin::kNonce));
    authentication.pbTag = const_cast<PUCHAR>(mendes::license_admin::kTag);
    authentication.cbTag = static_cast<ULONG>(sizeof(mendes::license_admin::kTag));
    authentication.pbAuthData = const_cast<PUCHAR>(mendes::license_admin::kAad);
    authentication.cbAuthData = static_cast<ULONG>(sizeof(mendes::license_admin::kAad) - 1);
    std::array<unsigned char, 104> privateBlob{};
    ULONG written = 0;
    const NTSTATUS decrypted = BCryptDecrypt(
        owner.symmetric, const_cast<PUCHAR>(mendes::license_admin::kEncryptedPrivateKey),
        static_cast<ULONG>(sizeof(mendes::license_admin::kEncryptedPrivateKey)), &authentication,
        nullptr, 0, privateBlob.data(), static_cast<ULONG>(privateBlob.size()), &written, 0);
    if (decrypted < 0 || written != privateBlob.size()) {
        SecureZeroMemory(privateBlob.data(), privateBlob.size());
        throw std::runtime_error("Senha administrativa incorreta.");
    }
    mendes::license::cryptoCheck(
        BCryptOpenAlgorithmProvider(&owner.ecdsa, BCRYPT_ECDSA_P256_ALGORITHM, nullptr, 0),
        "ECDSA provider");
    const NTSTATUS imported = BCryptImportKeyPair(owner.ecdsa, nullptr, BCRYPT_ECCPRIVATE_BLOB,
                                                  &owner.signer, privateBlob.data(),
                                                  static_cast<ULONG>(privateBlob.size()), 0);
    SecureZeroMemory(privateBlob.data(), privateBlob.size());
    mendes::license::cryptoCheck(imported, "Private key import");
    const auto digest = mendes::license::sha256(
        reinterpret_cast<const unsigned char *>(payloadText.data()), payloadText.size());
    std::array<unsigned char, 64> signature{};
    written = 0;
    mendes::license::cryptoCheck(
        BCryptSignHash(owner.signer, nullptr, const_cast<PUCHAR>(digest.data()),
                       static_cast<ULONG>(digest.size()), signature.data(),
                       static_cast<ULONG>(signature.size()), &written, 0),
        "ECDSA signature");
    if (written != signature.size())
        throw std::runtime_error("Unexpected ECDSA signature size.");
    return signature;
}

std::string trim(std::string value) {
    value.erase(value.begin(), std::find_if(value.begin(), value.end(), [](unsigned char c) {
                    return !std::isspace(c);
                }));
    value.erase(std::find_if(value.rbegin(), value.rend(), [](unsigned char c) {
                    return !std::isspace(c);
                }).base(), value.end());
    return value;
}

void audit(const mendes::license::Fields &fields, const std::string &key) {
    wchar_t local[MAX_PATH]{};
    const DWORD length = GetEnvironmentVariableW(L"LOCALAPPDATA", local, MAX_PATH);
    if (!length || length >= MAX_PATH)
        return;
    const auto folder = std::filesystem::path(local) / L"MendesColor" / L"LicenseStudio";
    std::filesystem::create_directories(folder);
    const auto path = folder / L"issued.csv";
    const bool header = !std::filesystem::exists(path);
    std::ofstream output(path, std::ios::app);
    if (header)
        output << "issued_utc,customer,machine,expiry,key_sha256\n";
    SYSTEMTIME time{};
    GetSystemTime(&time);
    const auto digest = mendes::license::sha256(reinterpret_cast<const unsigned char *>(key.data()),
                                                key.size());
    std::ostringstream fingerprint;
    fingerprint << std::hex << std::setfill('0');
    for (unsigned char value : digest)
        fingerprint << std::setw(2) << static_cast<unsigned>(value);
    auto csv = [](std::string value) {
        std::size_t position = 0;
        while ((position = value.find('"', position)) != std::string::npos) {
            value.insert(position, 1, '"');
            position += 2;
        }
        return '"' + value + '"';
    };
    output << std::setfill('0') << std::setw(4) << time.wYear << '-' << std::setw(2) << time.wMonth
           << '-' << std::setw(2) << time.wDay << 'T' << std::setw(2) << time.wHour << ':'
           << std::setw(2) << time.wMinute << ':' << std::setw(2) << time.wSecond << "Z,"
           << csv(fields.customer) << ',' << fields.machine << ',' << fields.expiry << ','
           << fingerprint.str() << '\n';
}

struct Application {
    HINSTANCE instance{};
    HWND window{}, password{}, customer{}, machine{}, expiry{}, output{}, status{};
    HFONT normal{}, title{}, small{};
    HICON largeIcon{}, smallIcon{};
    ~Application() {
        if (normal) DeleteObject(normal);
        if (title) DeleteObject(title);
        if (small) DeleteObject(small);
        if (largeIcon) DestroyIcon(largeIcon);
        if (smallIcon) DestroyIcon(smallIcon);
    }
    void create(HWND owner) {
        window = owner;
        normal = mendes::winui::font(10);
        title = mendes::winui::font(18, true);
        small = mendes::winui::font(9);
        largeIcon = mendes::winui::icon(instance, 1, 96);
        smallIcon = mendes::winui::icon(instance, 1, 32);
        SendMessageW(owner, WM_SETICON, ICON_BIG, reinterpret_cast<LPARAM>(largeIcon));
        SendMessageW(owner, WM_SETICON, ICON_SMALL, reinterpret_cast<LPARAM>(smallIcon));
        HWND logo = mendes::winui::control(owner, WC_STATICW, L"", SS_ICON, 25, 22, 96, 96, 0,
                                           normal);
        SendMessageW(logo, STM_SETIMAGE, IMAGE_ICON, reinterpret_cast<LPARAM>(largeIcon));
        mendes::winui::control(owner, WC_STATICW, L"Mendes License Studio", SS_LEFT, 142, 28, 500,
                              38, 0, title);
        mendes::winui::control(owner, WC_STATICW,
                              L"Painel administrativo • não entregue este aplicativo ou a senha",
                              SS_LEFT, 142, 73, 530, 22, 0, small);
        mendes::winui::control(owner, WC_STATICW, L"Senha do Studio", SS_LEFT, 25, 135, 160, 20, 0,
                              normal);
        password = mendes::winui::control(owner, WC_EDITW, L"", ES_PASSWORD | ES_AUTOHSCROLL, 25,
                                          158, 310, 29, ID_PASSWORD, normal);
        mendes::winui::control(owner, WC_STATICW, L"Cliente", SS_LEFT, 360, 135, 120, 20, 0,
                              normal);
        customer = mendes::winui::control(owner, WC_EDITW, L"", ES_AUTOHSCROLL, 360, 158, 335, 29,
                                          ID_CUSTOMER, normal);
        mendes::winui::control(owner, WC_STATICW, L"ID da máquina do cliente", SS_LEFT, 25, 207,
                              240, 20, 0, normal);
        machine = mendes::winui::control(owner, WC_EDITW, L"", ES_AUTOHSCROLL | ES_UPPERCASE, 25,
                                         230, 430, 29, ID_MACHINE, normal);
        mendes::winui::control(owner, WC_STATICW, L"Validade (AAAA-MM-DD)", SS_LEFT, 480, 207, 210,
                              20, 0, normal);
        expiry = mendes::winui::control(owner, WC_EDITW, L"", ES_AUTOHSCROLL, 480, 230, 215, 29,
                                        ID_EXPIRY, normal);
        mendes::winui::control(owner, WC_STATICW, L"Deixe a validade vazia para licença perpétua.",
                              SS_LEFT, 480, 264, 215, 38, 0, small);
        mendes::winui::control(owner, WC_BUTTONW, L"GERAR KEY", BS_DEFPUSHBUTTON, 25, 280, 180, 40,
                              ID_GENERATE, normal);
        output = mendes::winui::control(owner, WC_EDITW, L"",
                                        ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY | WS_VSCROLL,
                                        25, 340, 670, 145, ID_OUTPUT, normal);
        mendes::winui::control(owner, WC_BUTTONW, L"Copiar key", BS_PUSHBUTTON, 25, 505, 150, 34,
                              ID_COPY, normal);
        status = mendes::winui::control(owner, WC_STATICW, L"Pronto para emitir uma licença.",
                                        SS_LEFT, 200, 510, 495, 46, ID_STATUS, normal);
        mendes::winui::control(owner, WC_STATICW, MENDES_COLOR_COPYRIGHT_W, SS_LEFT, 25, 557,
                              670, 20, 0, small);
    }
    void command(int id) {
        if (id == ID_GENERATE) {
            auto passwordText = mendes::license::utf8(mendes::winui::text(password));
            const SecretText erasePassword{passwordText};
            mendes::license::Fields fields{
                trim(mendes::license::utf8(mendes::winui::text(machine))),
                trim(mendes::license::utf8(mendes::winui::text(expiry))),
                trim(mendes::license::utf8(mendes::winui::text(customer)))};
            if (fields.expiry.empty())
                fields.expiry = "PERPETUAL";
            if (fields.expiry != "PERPETUAL" && fields.expiry < mendes::license::todayUtc())
                throw std::invalid_argument("A validade precisa ser hoje ou uma data futura.");
            const auto payloadText = mendes::license::payload(fields);
            const auto key = mendes::license::token(payloadText, sign(payloadText, passwordText));
            SetWindowTextW(output, mendes::license::wide(key).c_str());
            audit(fields, key);
            const std::wstring message =
                fields.expiry == "PERPETUAL"
                    ? L"✓ Key perpétua gerada e registrada no histórico local."
                    : L"✓ Key válida até " + mendes::license::wide(fields.expiry) +
                          L" gerada e registrada.";
            SetWindowTextW(status, message.c_str());
        } else if (id == ID_COPY) {
            const auto value = mendes::winui::text(output);
            if (value.empty())
                throw std::runtime_error("Gere uma key antes de copiar.");
            mendes::winui::clipboard(window, value);
            SetWindowTextW(status, L"Key copiada. Envie somente ao cliente correspondente.");
        }
    }
};

Application *application = nullptr;
LRESULT CALLBACK procedure(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
    try {
        if (message == WM_CREATE) {
            application = static_cast<Application *>(reinterpret_cast<CREATESTRUCTW *>(lParam)->lpCreateParams);
            application->create(window);
            return 0;
        }
        if (message == WM_COMMAND && application) {
            application->command(LOWORD(wParam));
            return 0;
        }
        if (message == WM_DESTROY) {
            PostQuitMessage(0);
            return 0;
        }
    } catch (const std::exception &error) {
        MessageBoxW(window, mendes::license::wide(error.what()).c_str(), L"Mendes License Studio",
                    MB_OK | MB_ICONERROR);
    }
    return DefWindowProcW(window, message, wParam, lParam);
}
} // namespace

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
    Application app;
    app.instance = instance;
    INITCOMMONCONTROLSEX controls{sizeof(controls), ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&controls);
    WNDCLASSEXW type{};
    type.cbSize = sizeof(type);
    type.lpfnWndProc = procedure;
    type.hInstance = instance;
    type.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    type.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
    type.lpszClassName = kClass;
    type.hIcon = mendes::winui::icon(instance, 1, 32);
    if (!RegisterClassExW(&type))
        return 1;
    HWND window = CreateWindowExW(0, kClass,
                                  L"Mendes License Studio " MENDES_WIDE_LITERAL(MENDES_COLOR_VERSION),
                                  WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                                  CW_USEDEFAULT, CW_USEDEFAULT, 750, 630, nullptr, nullptr, instance,
                                  &app);
    if (!window)
        return 1;
    mendes::winui::center(window);
    ShowWindow(window, show);
    UpdateWindow(window);
    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
    return static_cast<int>(message.wParam);
}
