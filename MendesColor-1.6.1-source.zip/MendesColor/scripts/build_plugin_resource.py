"""Build the icon and legal VERSIONINFO resource for the OpenFX DLL."""

import argparse
import re
import subprocess
from pathlib import Path

from windows_version_resource import version_info

parser = argparse.ArgumentParser()
parser.add_argument("--compiler", default="x86_64-w64-mingw32-g++")
parser.add_argument("--windres", default="x86_64-w64-mingw32-windres")
parser.add_argument("--rc-only", action="store_true")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
build = root / "build/windows"
build.mkdir(parents=True, exist_ok=True)
version = re.search(
    r'^#define MENDES_COLOR_VERSION "([0-9]+\.[0-9]+\.[0-9]+)"$',
    (root / "src/version.hpp").read_text(),
    re.MULTILINE,
).group(1)
rc = build / "MendesColor.rc"
rc.write_text(
    '#include <windows.h>\n'
    + f'1 ICON "{(root / "assets/branding/MendesColor.ico").as_posix()}"\n'
    + version_info(
        version,
        "Mendes Color OpenFX Plugin",
        "MendesColor.ofx",
        "MendesColor",
        "VFT_DLL",
    ),
    encoding="utf-8",
)
output = build / "MendesColor-res.o"
if args.rc_only:
    print(rc)
    raise SystemExit(0)
subprocess.run(
    [
        args.windres,
        "--preprocessor",
        args.compiler,
        "--preprocessor-arg=-E",
        "--preprocessor-arg=-xc",
        "--preprocessor-arg=-DRC_INVOKED",
        "-i",
        str(rc),
        "-O",
        "coff",
        "-o",
        str(output),
    ],
    check=True,
)
print(output)
