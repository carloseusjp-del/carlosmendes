# Execute in an x64 Native Tools Command Prompt / Developer PowerShell for VS 2022.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) {
    throw 'Use Developer PowerShell for Visual Studio with the x64 C++ build tools.'
}
$out = Join-Path $root 'dist\MendesColor.ofx.bundle\Contents\Win64'
$build = Join-Path $root 'build\msvc'
New-Item -ItemType Directory -Path $out, $build -Force | Out-Null
& python "$root\scripts\embed_lut.py"
if ($LASTEXITCODE -ne 0) { throw 'Embedded LUT generation failed (Python 3 is required).' }
& python "$root\scripts\generate_controls.py"
if ($LASTEXITCODE -ne 0) { throw 'Advanced registry generation failed.' }
& python "$root\scripts\embed_gpu.py"
if ($LASTEXITCODE -ne 0) { throw 'GPU kernel embedding failed.' }
& python "$root\scripts\build_plugin_resource.py" --rc-only
if ($LASTEXITCODE -ne 0) { throw 'Windows version resource generation failed.' }
Push-Location $build
try {
    & rc.exe /nologo "/fo$build\MendesColor.res" "$root\build\windows\MendesColor.rc"
    if ($LASTEXITCODE -ne 0) { throw 'Windows version resource compilation failed.' }
    & cl.exe /nologo /utf-8 /std:c++17 /EHsc /O2 /W4 /MT /LD "/I$root\src" "/I$root\vendor\openfx\include" "/I$root\vendor\opencl\include" "/I$root\build\generated" "$root\src\plugin.cpp" "$build\MendesColor.res" /link comdlg32.lib bcrypt.lib advapi32.lib shell32.lib "/OUT:$out\MendesColor.ofx"
    if ($LASTEXITCODE -ne 0) { throw 'Plugin compilation failed.' }
    & cl.exe /nologo /utf-8 /std:c++17 /EHsc /O2 /W4 /MT "/I$root\src" "$root\tests\color_test.cpp" /Fe:color_test.exe
    if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed.' }
    & .\color_test.exe
    if ($LASTEXITCODE -ne 0) { throw 'Color tests failed.' }
    & cl.exe /nologo /utf-8 /std:c++17 /EHsc /O2 /W4 /MT "/I$root\src" "/I$root\vendor\openfx\include" "/I$root\build\generated" "$root\tests\lut_test.cpp" /Fe:lut_test.exe
    if ($LASTEXITCODE -ne 0) { throw 'LUT test compilation failed.' }
    & cl.exe /nologo /utf-8 /std:c++17 /EHsc /O2 /W4 /MT "/I$root\src" "/I$root\vendor\openfx\include" "/I$root\build\generated" "$root\tests\halation_test.cpp" /Fe:halation_test.exe
    if ($LASTEXITCODE -ne 0) { throw 'Halation test compilation failed.' }
    & .\halation_test.exe
    if ($LASTEXITCODE -ne 0) { throw 'Halation tests failed.' }
    & cl.exe /nologo /utf-8 /std:c++17 /EHsc /O2 /W4 /MT "/I$root\src" "/I$root\vendor\openfx\include" "/I$root\build\generated" "$root\tests\advanced_test.cpp" /Fe:advanced_test.exe
    if ($LASTEXITCODE -ne 0) { throw 'Advanced test compilation failed.' }
    & .\advanced_test.exe
    if ($LASTEXITCODE -ne 0) { throw 'Advanced tool checks failed.' }
    Push-Location $root
    try {
        & "$build\lut_test.exe"
        if ($LASTEXITCODE -ne 0) { throw 'LUT tests failed.' }
    } finally { Pop-Location }
} finally { Pop-Location }
Write-Host ('Windows bundle generated in ' + $out)
Write-Host 'Build the licensing apps with MinGW (make license-apps) before running python scripts/package.py.'
