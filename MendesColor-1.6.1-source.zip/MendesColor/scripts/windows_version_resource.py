"""Generate consistent Windows VERSIONINFO metadata for Mendes Color binaries."""

COPYRIGHT = "Copyright (C) 2026 Carlos Mendes. All rights reserved."
COMPANY = "Carlos Mendes"
PRODUCT = "Mendes Color"


def version_info(
    version: str,
    description: str,
    original_filename: str,
    internal_name: str,
    file_type: str = "VFT_APP",
) -> str:
    numbers = ",".join(version.split(".")) + ",0"
    return f'''1 VERSIONINFO
FILEVERSION {numbers}
PRODUCTVERSION {numbers}
FILEFLAGSMASK 0x3fL
FILEFLAGS 0x0L
FILEOS VOS_NT_WINDOWS32
FILETYPE {file_type}
FILESUBTYPE VFT2_UNKNOWN
BEGIN
  BLOCK "StringFileInfo"
  BEGIN
    BLOCK "041604B0"
    BEGIN
      VALUE "CompanyName", "{COMPANY}\\0"
      VALUE "FileDescription", "{description}\\0"
      VALUE "FileVersion", "{version}\\0"
      VALUE "InternalName", "{internal_name}\\0"
      VALUE "LegalCopyright", "{COPYRIGHT}\\0"
      VALUE "OriginalFilename", "{original_filename}\\0"
      VALUE "ProductName", "{PRODUCT}\\0"
      VALUE "ProductVersion", "{version}\\0"
    END
  END
  BLOCK "VarFileInfo"
  BEGIN
    VALUE "Translation", 0x0416, 1200
  END
END
'''
