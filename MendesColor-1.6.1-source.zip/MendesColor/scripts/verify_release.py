"""Verify final PE structure and every installer payload against REA evidence."""

from __future__ import annotations

import hashlib
import json
import re
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
BUILD = ROOT / "build"
VERSION = re.search(
    r'^#define MENDES_COLOR_VERSION "([0-9]+\.[0-9]+\.[0-9]+)"$',
    (ROOT / "src/version.hpp").read_text(),
    re.MULTILINE,
).group(1)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pe(path: Path, dll: bool) -> dict[str, object]:
    data = path.read_bytes()
    assert data[:2] == b"MZ", f"{path.name}: DOS signature"
    offset = struct.unpack_from("<I", data, 60)[0]
    assert data[offset : offset + 4] == b"PE\0\0", f"{path.name}: PE signature"
    machine = struct.unpack_from("<H", data, offset + 4)[0]
    characteristics = struct.unpack_from("<H", data, offset + 22)[0]
    optional = offset + 24
    assert machine == 0x8664 and struct.unpack_from("<H", data, optional)[0] == 0x20B
    assert bool(characteristics & 0x2000) == dll, f"{path.name}: DLL characteristic"
    subsystem = struct.unpack_from("<H", data, optional + 68)[0]
    if not dll:
        assert subsystem == 2, f"{path.name}: Windows GUI subsystem"
    legal = "Copyright (C) 2026 Carlos Mendes. All rights reserved.".encode("utf-16le")
    assert legal in data, f"{path.name}: legal copyright metadata"
    return {
        "file": path.name,
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "architecture": "amd64",
        "kind": "DLL" if dll else "Windows GUI",
    }


setup = DIST / f"MendesColor-{VERSION}-Setup.exe"
plugin = DIST / "MendesColor.ofx.bundle/Contents/Win64/MendesColor.ofx"
activator = DIST / "MendesColorActivate.exe"
studio = DIST / f"MendesColor-License-Studio-{VERSION}.exe"
resources_path = BUILD / "installer" / f"rea-resources-{VERSION}.json"
resources = json.loads(resources_path.read_text())
assert resources["subject"]["digest"]["sha256"] == digest(setup)
normalized = resources["normalized_result"]
assert normalized["format"] == "pe32-plus" and normalized["machine"] == 0x8664
assert normalized["coverage"]["status"] == "complete"

actual_payloads = {
    row["name"]["id"]: row["payload"]
    for row in normalized["resources"]
    if row["type"] == {"kind": "id", "id": 10}
}
expected_payloads = json.loads((BUILD / "installer/payloads.json").read_text())
assert len(actual_payloads) == len(expected_payloads)
for row in expected_payloads:
    actual = actual_payloads[row["resource_id"]]
    assert actual["sha256"] == row["sha256"]
    assert actual["location"]["bytes"] == row["bytes"]

types = [row["type"].get("id") for row in normalized["resources"]]
assert 3 in types and 14 in types and 24 in types, "icon group and manifest resources"
setup_bytes = setup.read_bytes()
assert b'requestedExecutionLevel level="requireAdministrator"' in setup_bytes
setup_imports = json.loads(
    (BUILD / "installer" / f"rea-imports-{VERSION}.json").read_text()
)
assert setup_imports["subject"]["digest"]["sha256"] == digest(setup)
assert setup_imports["normalized_result"]["coverage"]["status"] == "complete"
setup_dlls = [row["name"].lower() for row in setup_imports["normalized_result"]["imports"]]
setup_functions = [
    function.get("name")
    for row in setup_imports["normalized_result"]["imports"]
    for function in row["functions"]
]
assert "comctl32.dll" not in setup_dlls
assert "TaskDialogIndirect" not in setup_functions

exports = json.loads((BUILD / "rea-inspect-native-exports.json").read_text())
imports = json.loads((BUILD / "rea-inspect-pe-imports.json").read_text())
assert exports["subject"]["digest"]["sha256"] == digest(plugin)
assert imports["subject"]["digest"]["sha256"] == digest(plugin)
assert [row["name"] for row in exports["normalized_result"]["exports"]] == [
    "OfxGetNumberOfPlugins",
    "OfxGetPlugin",
]
assert exports["normalized_result"]["coverage"]["status"] == "complete"
assert imports["normalized_result"]["coverage"]["status"] == "complete"

record = {
    "version": VERSION,
    "copyright": "Copyright (C) 2026 Carlos Mendes. All rights reserved.",
    "artifacts": [
        pe(plugin, True),
        pe(activator, False),
        pe(studio, False),
        pe(setup, False),
    ],
    "installer_payloads_verified": len(expected_payloads),
    "installer_entry_point_regression": "TaskDialogIndirect absent",
    "installer_rea_imports_evidence_id": setup_imports["evidence_id"],
    "installer_rea_evidence_id": resources["evidence_id"],
    "plugin_rea_exports_evidence_id": exports["evidence_id"],
    "plugin_rea_imports_evidence_id": imports["evidence_id"],
    "plugin_import_dlls": [row["name"] for row in imports["normalized_result"]["imports"]],
    "local_checks": {
        "portable_suites": 14062,
        "opencl_parity": 426,
        "total": 14488,
        "license_crypto_identity": "passed",
        "release_secret_scan": "passed",
    },
    "runtime_scope": {
        "windows_execution": "not_run",
        "resolve_1_6_0_execution": "not_run",
        "opencl_execution": "PoCL 6.0 CPU test device; production selects GPUs only",
        "previous_version": "1.5.0 confirmed by user in DaVinci Resolve with NVIDIA GPU",
    },
}
output = BUILD / "installer" / f"verification-{VERSION}.json"
output.write_text(json.dumps(record, indent=2) + "\n")
print(f"Release verification passed: {len(expected_payloads)} installer payloads; {output}")
