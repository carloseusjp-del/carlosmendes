#pragma once
#include "cube.hpp"

namespace mendes {
class Pipeline {
    std::shared_ptr<const Cube3D> cube_;
    LutEncoding encoding_;
    Grade grade_;
    double mix_;
    static Controls fullGrade(Controls controls) { controls.mix = 1; return controls; }
public:
    Pipeline(Controls controls, std::shared_ptr<const Cube3D> cube = {}, LutEncoding encoding = LutEncoding::Preserve)
        : cube_(std::move(cube)), encoding_(encoding), grade_(fullGrade(controls)), mix_(controls.mix) {}
    bool isIdentity() const { return mix_ == 0 || (!cube_ && grade_.isIdentity()); }
    RGB apply(RGB input) const {
        if (isIdentity()) return input;
        RGB converted = cube_ ? cube_->sample(input) : input;
        if (cube_ && encoding_ == LutEncoding::Rec709OETFToGamma24)
            for (double& value : converted) value = rec709ToGamma24(value);
        RGB result = grade_.apply(converted);
        if (mix_ != 1) for (int i = 0; i < 3; ++i) result[i] = input[i] + mix_ * (result[i] - input[i]);
        return result;
    }
    void pixel(const float* src, float* dst, bool premultiplied) const { processPixel(*this, src, dst, premultiplied); }
};
} // namespace mendes
