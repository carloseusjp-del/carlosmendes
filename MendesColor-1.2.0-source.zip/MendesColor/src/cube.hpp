#pragma once

#include "color.hpp"
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <limits>
#include <locale>
#include <memory>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace mendes {
class LutError : public std::runtime_error { using std::runtime_error::runtime_error; };

// IRIDAS/Resolve 3D .cube: the red index changes fastest, then green, then blue.
// This reads data only; a LUT is never executed as code.
class Cube3D {
    int size_ = 0;
    RGB min_{0, 0, 0}, max_{1, 1, 1};
    std::vector<RGB> table_;
    Cube3D() = default;
    const RGB& at(int r, int g, int b) const {
        return table_[(static_cast<std::size_t>(b) * size_ + g) * size_ + r];
    }
    static void end(std::istringstream& stream) {
        stream >> std::ws;
        if (!stream.eof() && stream.peek() != '#') throw LutError("Unexpected data at end of .cube line.");
    }
public:
    int size() const { return size_; }
    static Cube3D fromTable(int size, const RGB* entries, std::size_t count) {
        if (size < 2 || size > 65 || !entries || count != static_cast<std::size_t>(size) * size * size)
            throw LutError("Invalid embedded LUT dimensions.");
        Cube3D cube;
        cube.size_ = size;
        cube.table_.assign(entries, entries + count);
        for (const auto& entry : cube.table_) for (double value : entry)
            if (!std::isfinite(value)) throw LutError("Non-finite embedded LUT entry.");
        return cube;
    }
    static Cube3D read(std::istream& input) {
        Cube3D cube;
        bool domainMin = false, domainMax = false, range = false;
        std::string line;
        std::size_t bytes = 0;
        while (std::getline(input, line)) {
            bytes += line.size() + 1;
            if (bytes > 64 * 1024 * 1024) throw LutError("LUT exceeds the 64 MiB text budget.");
            if (bytes == line.size() + 1 && line.compare(0, 3, "\xEF\xBB\xBF") == 0) line.erase(0, 3);
            std::istringstream stream(line); stream.imbue(std::locale::classic());
            std::string key;
            if (!(stream >> key) || key[0] == '#') continue;
            if (key == "TITLE") {
                std::string title;
                if (!(stream >> std::quoted(title))) throw LutError("Invalid LUT TITLE.");
                end(stream); continue;
            }
            if (key == "LUT_1D_SIZE" || key == "LUT_1D_INPUT_RANGE")
                throw LutError("1D/shaper LUTs are not supported; select a pure 3D .cube LUT.");
            if (!cube.table_.empty() && (key == "LUT_3D_SIZE" || key == "DOMAIN_MIN" || key == "DOMAIN_MAX" || key == "LUT_3D_INPUT_RANGE"))
                throw LutError("LUT headers must precede table entries.");
            if (key == "LUT_3D_SIZE") {
                if (cube.size_ || !(stream >> cube.size_) || cube.size_ < 2 || cube.size_ > 65)
                    throw LutError("LUT_3D_SIZE must occur once and be between 2 and 65.");
                end(stream);
                const auto n = static_cast<std::size_t>(cube.size_);
                cube.table_.reserve(n * n * n); continue;
            }
            if (key == "DOMAIN_MIN" || key == "DOMAIN_MAX") {
                bool& seen = key == "DOMAIN_MIN" ? domainMin : domainMax;
                if (seen || range) throw LutError("Duplicate/conflicting LUT domain headers.");
                auto& value = key == "DOMAIN_MIN" ? cube.min_ : cube.max_;
                if (!(stream >> value[0] >> value[1] >> value[2])) throw LutError("Invalid LUT domain.");
                seen = true; end(stream); continue;
            }
            if (key == "LUT_3D_INPUT_RANGE") {
                double low = 0, high = 0;
                if (range || domainMin || domainMax || !(stream >> low >> high)) throw LutError("Invalid LUT input range.");
                cube.min_.fill(low); cube.max_.fill(high); range = true; end(stream); continue;
            }
            if (!cube.size_) throw LutError("LUT_3D_SIZE is required before table entries.");
            stream.clear(); stream.str(line);
            RGB value{};
            if (!(stream >> value[0] >> value[1] >> value[2])) throw LutError("Invalid .cube table entry or unsupported header.");
            end(stream);
            for (double component : value) if (!std::isfinite(component)) throw LutError("Non-finite LUT entry.");
            const auto n = static_cast<std::size_t>(cube.size_);
            if (cube.table_.size() >= n * n * n) throw LutError("Too many LUT entries.");
            cube.table_.push_back(value);
        }
        if (input.bad()) throw LutError("Failed while reading LUT data.");
        const auto n = static_cast<std::size_t>(cube.size_);
        if (!n || cube.table_.size() != n * n * n) throw LutError("Incomplete 3D LUT table.");
        for (int axis = 0; axis < 3; ++axis)
            if (!std::isfinite(cube.min_[axis]) || !std::isfinite(cube.max_[axis]) || cube.max_[axis] <= cube.min_[axis])
                throw LutError("LUT domain maximum must exceed its minimum.");
        return cube;
    }
    RGB sample(RGB input) const {
        for (double v : input) if (!std::isfinite(v)) return input;
        int lower[3]{}; double fraction[3]{};
        for (int axis = 0; axis < 3; ++axis) {
            const double t = std::clamp((input[axis] - min_[axis]) / (max_[axis] - min_[axis]), 0.0, 1.0) * (size_ - 1);
            lower[axis] = std::min(static_cast<int>(t), size_ - 2);
            fraction[axis] = t - lower[axis];
        }
        RGB result{};
        for (int b = 0; b < 2; ++b) for (int g = 0; g < 2; ++g) for (int r = 0; r < 2; ++r) {
            const double weight = (r ? fraction[0] : 1 - fraction[0]) *
                (g ? fraction[1] : 1 - fraction[1]) * (b ? fraction[2] : 1 - fraction[2]);
            const auto& entry = at(lower[0] + r, lower[1] + g, lower[2] + b);
            for (int channel = 0; channel < 3; ++channel) result[channel] += weight * entry[channel];
        }
        return result;
    }
};

// Per-instance immutable snapshots. Editing/replacing the file invalidates the
// cache through its path, write time or size. Loading never runs per pixel.
class CubeCache {
    std::mutex mutex_;
    std::string path_;
    std::filesystem::file_time_type modified_{};
    std::uintmax_t bytes_ = 0;
    std::shared_ptr<const Cube3D> cube_;
public:
    std::shared_ptr<const Cube3D> get(const std::string& name) {
        if (name.empty()) throw LutError("Select a 3D .cube file or choose the embedded DJI Avata 2 preset.");
        std::lock_guard<std::mutex> lock(mutex_);
        const auto path = std::filesystem::u8path(name);
        std::error_code error;
        const auto modified = std::filesystem::last_write_time(path, error);
        if (error) throw LutError("Cannot access the selected .cube LUT. Check the file path.");
        const auto bytes = std::filesystem::file_size(path, error);
        if (error || bytes > 64 * 1024 * 1024) throw LutError("Cannot read LUT or LUT exceeds 64 MiB.");
        if (cube_ && name == path_ && modified == modified_ && bytes == bytes_) return cube_;
        std::ifstream file(path, std::ios::binary);
        if (!file) throw LutError("Cannot open the selected .cube LUT.");
        auto cube = std::make_shared<const Cube3D>(Cube3D::read(file));
        path_ = name; modified_ = modified; bytes_ = bytes; cube_ = cube;
        return cube;
    }
};

enum class LutEncoding { Preserve, Rec709OETFToGamma24 };
inline double rec709ToGamma24(double encoded) {
    // Only for LUTs documented to output the BT.709 camera OETF. This must not
    // be applied again to a LUT that already outputs gamma-2.4 encoded RGB.
    const double magnitude = std::abs(encoded);
    const double linear = magnitude < 0.081 ? magnitude / 4.5 : std::pow((magnitude + 0.099) / 1.099, 1.0 / 0.45);
    return std::copysign(std::pow(linear, 1.0 / 2.4), encoded);
}
} // namespace mendes
