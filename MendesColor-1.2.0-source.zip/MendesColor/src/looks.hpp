#pragma once
#include <array>
#include <cstddef>

namespace mendes {
// The first six indices are persisted by existing Resolve projects.
enum class Look {
    Neutral, CoolCinema, WarmCinema, Vivid, SoftGreen, Earth,
    TealOrange, BleachBypass, SoftPortrait, GoldenHour, Noir,
    MatteVintage, PastelDream, CleanDaylight, MoodyForest,
    NightBlue, SunsetGlow, RichFilm, CommercialTeal
};
struct LookDefinition {
    const char* name;
    double contrast = 1, saturation = 1, temperature = 0, tint = 0, exposure = 0;
    std::array<double, 3> shadows{}, highlights{};
    double lift = 0, shoulder = 0;
};
inline constexpr std::array<LookDefinition, 19> kLooks{{
    {"Neutral"},
    {"Cool Cinema", 1.12, 0.90, -0.22},
    {"Warm Cinema", 1.08, 0.95, 0.22},
    {"Vivid", 1.15, 1.20},
    {"Soft Green", 0.92, 0.85, -0.05, -0.16},
    {"Earth", 1.10, 0.78, 0.18, 0.04},
    {"Teal & Orange", 1.12, 1.05, 0, 0, 0, {-0.10, 0.05, 0.10}, {0.12, 0.015, -0.10}, 0, 0.10},
    {"Bleach Bypass", 1.35, 0.38, -0.025, 0, 0, {}, {}, 0, 0.16},
    {"Soft Portrait", 0.94, 0.92, 0.08, 0.025, 0.08, {}, {0.025, 0.005, -0.015}, 0.006, 0.16},
    {"Golden Hour", 1.04, 1.08, 0.30, 0.015, 0.05, {-0.02, 0, 0.02}, {0.10, 0.03, -0.08}, 0.005, 0.12},
    {"Noir", 1.30, 0, 0, 0, 0, {}, {}, 0, 0.12},
    {"Matte Vintage", 0.94, 0.72, 0.12, 0.02, 0, {0.01, 0.01, 0.04}, {0.04, 0.015, -0.04}, 0.035, 0.24},
    {"Pastel Dream", 0.88, 0.70, 0.04, 0.04, 0.12, {0.02, 0.005, 0.025}, {}, 0.025, 0.20},
    {"Clean Daylight", 1.03, 1.04, -0.035, 0.005, 0.04, {}, {}, 0, 0.06},
    {"Moody Forest", 1.17, 0.82, -0.08, -0.10, -0.12, {-0.03, 0.07, 0.015}, {0.025, 0.02, -0.035}, 0.004, 0.20},
    {"Night Blue", 1.16, 0.80, -0.32, 0.03, -0.15, {-0.04, 0.015, 0.12}, {0.025, 0, 0.04}, 0, 0.10},
    {"Sunset Glow", 1.06, 1.12, 0.24, 0.08, 0.04, {0.02, -0.015, 0.035}, {0.10, 0.02, -0.07}, 0.008, 0.18},
    {"Rich Film", 1.18, 0.93, 0.04, 0.01, 0, {-0.025, 0.015, 0.025}, {0.045, 0.01, -0.025}, 0.010, 0.22},
    {"Commercial Teal", 1.08, 1.08, -0.06, -0.02, 0.04, {-0.03, 0.035, 0.05}, {0.025, 0.01, -0.02}, 0, 0.08}
}};
inline constexpr std::size_t kLookCount = kLooks.size();
static_assert(kLookCount == static_cast<std::size_t>(Look::CommercialTeal) + 1, "Look IDs and catalog must agree");
} // namespace mendes
