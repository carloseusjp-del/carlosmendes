#include "pipeline.hpp"
#include "avata2_lut.hpp"
#include <chrono>
#include <iostream>

namespace {
int checks = 0;
void require(bool ok, const char* message) {
    ++checks;
    if (!ok) throw std::runtime_error(message);
}
bool near(double a, double b, double eps = 1e-9) { return std::abs(a - b) < eps; }
std::string table(bool swap = false, double gain = 1) {
    std::ostringstream s;
    s << "# Synthetic test data, not a DJI transform\nTITLE \"Test # LUT\"\nLUT_3D_SIZE 2\n";
    for (int b = 0; b < 2; ++b) for (int g = 0; g < 2; ++g) for (int r = 0; r < 2; ++r)
        s << (swap ? b : r) * gain << ' ' << g * gain << ' ' << (swap ? r : b) * gain << " # entry\n";
    return s.str();
}
std::shared_ptr<const mendes::Cube3D> read(const std::string& text) {
    std::istringstream input(text);
    return std::make_shared<const mendes::Cube3D>(mendes::Cube3D::read(input));
}
void invalid(const std::string& text) {
    try { (void)read(text); } catch (const mendes::LutError&) { require(true, "malformed cube rejected"); return; }
    require(false, "malformed cube unexpectedly accepted");
}
struct Temp {
    std::filesystem::path path = std::filesystem::temp_directory_path() /
        ("mendes-lut-test-" + std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    Temp() { if (!std::filesystem::create_directory(path)) throw std::runtime_error("Test directory already exists"); }
    ~Temp() { std::error_code e; std::filesystem::remove_all(path, e); }
};
}
int main() {
    try {
        using namespace mendes;
        auto identity = read(table());
        require(identity->size() == 2, "cube size");
        for (int i = 0; i <= 100; ++i) {
            RGB input{i / 100.0, (100 - i) / 100.0, 0.375};
            auto out = identity->sample(input);
            require(near(out[0], input[0]) && near(out[1], input[1]) && near(out[2], input[2]), "identity interpolation preserves ramp");
        }
        auto swap = read(table(true));
        auto out = swap->sample({0.25, 0.5, 0.75});
        require(near(out[0], 0.75) && near(out[1], 0.5) && near(out[2], 0.25), "red-fast ordering and non-grid interpolation");
        out = read(table(false, 2))->sample({0.75, 1, 0.25});
        require(near(out[0], 1.5) && near(out[1], 2) && near(out[2], 0.5), "output HDR values not clipped");
        out = identity->sample({-0.5, 1.5, 0.25});
        require(out[0] == 0 && out[1] == 1 && near(out[2], 0.25), "inputs outside LUT domain clamp to its edge");
        auto domain = table(); domain.insert(domain.find("LUT_3D_SIZE"), "DOMAIN_MIN -1 -1 -1\nDOMAIN_MAX 1 1 1\n");
        out = read(domain)->sample({0, -1, 1});
        require(near(out[0], 0.5) && near(out[1], 0) && near(out[2], 1), "explicit per-axis domain");
        auto range = table(); range.insert(range.find("LUT_3D_SIZE"), "LUT_3D_INPUT_RANGE -1 1\n");
        require(near(read(range)->sample({0, 0, 0})[0], 0.5), "Resolve input range extension");
        require(read("\xEF\xBB\xBF" + table())->size() == 2, "UTF-8 BOM");
        invalid(""); invalid("LUT_1D_SIZE 2\n0 0 0\n1 1 1\n");
        invalid("LUT_3D_SIZE 1\n"); invalid("LUT_3D_SIZE 66\n");
        invalid("LUT_3D_SIZE 2\n0 0 0\n");
        invalid(table() + "0 0 0\n");
        invalid("LUT_3D_SIZE 2\nLUT_3D_SIZE 2\n");
        invalid("DOMAIN_MIN 1 1 1\nDOMAIN_MAX 0 0 0\n" + table());
        invalid("DOMAIN_MIN 0 0 0\nDOMAIN_MIN 0 0 0\n" + table());
        invalid("LUT_3D_INPUT_RANGE 0 1\nDOMAIN_MAX 1 1 1\n" + table());
        invalid(table() + "UNKNOWN_HEADER 1\n");
        invalid("LUT_3D_SIZE 2\nnan 0 0\n");
        invalid("LUT_3D_SIZE 2 garbage\n");
        require(rec709ToGamma24(0) == 0 && near(rec709ToGamma24(1), 1), "gamma conversion endpoints");
        const double encoded18 = 1.099 * std::pow(0.18, 0.45) - 0.099;
        require(near(rec709ToGamma24(encoded18), std::pow(0.18, 1.0 / 2.4)), "BT.709 OETF gray maps to gamma 2.4");
        require(near(rec709ToGamma24(-encoded18), -std::pow(0.18, 1.0 / 2.4)), "transfer conversion preserves sign");
        Controls controls;
        require(!Pipeline(controls, swap).isIdentity(), "active LUT is not bypassed by neutral grading");
        out = Pipeline(controls, swap).apply({0.2, 0.4, 0.8});
        require(near(out[0], 0.8) && near(out[2], 0.2), "LUT applied before neutral controls");
        controls.exposure = 1;
        out = Pipeline(controls, swap).apply({0.2, 0.4, 0.8});
        require(near(out[0], 1.6) && near(out[2], 0.4), "grade follows input transform");
        controls.mix = 0.5;
        out = Pipeline(controls, swap).apply({0.2, 0.4, 0.8});
        require(near(out[0], 0.9) && near(out[1], 0.6) && near(out[2], 0.6), "mix blends complete pipeline against original log input");
        controls.mix = 0;
        require(Pipeline(controls, swap).apply({-0.1, 0.2, 2}) == RGB{-0.1, 0.2, 2}, "zero mix bypasses LUT exactly");
        controls = {};
        float premult[] = {0.1f, 0.2f, 0.4f, 0.5f}, result[4]{};
        Pipeline(controls, swap).pixel(premult, result, true);
        require(near(result[0], 0.4, 1e-6) && near(result[2], 0.1, 1e-6) && result[3] == 0.5f, "LUT operates on unpremultiplied color and preserves alpha");
        out = Pipeline(controls, identity, LutEncoding::Preserve).apply({encoded18, encoded18, encoded18});
        require(near(out[0], encoded18), "default does not re-encode unknown LUT transfer");
        out = Pipeline(controls, identity, LutEncoding::Rec709OETFToGamma24).apply({encoded18, encoded18, encoded18});
        require(near(out[0], std::pow(0.18, 1.0 / 2.4)), "explicit output transfer occurs once");
        Temp temp;
        const auto path = temp.path / std::filesystem::u8path("teste-c\xC3\xB3r.cube");
        { std::ofstream file(path); file << table(); }
        CubeCache cache;
        auto first = cache.get(path.u8string());
        require(cache.get(path.u8string()) == first, "unchanged LUT reuses immutable cached table");
        const auto before = std::filesystem::last_write_time(path);
        { std::ofstream file(path); file << table(true); }
        std::filesystem::last_write_time(path, before + std::chrono::seconds(1));
        auto changed = cache.get(path.u8string());
        require(changed != first && near(changed->sample({0.2, 0.4, 0.8})[0], 0.8), "edited LUT invalidates cache");
        require(near(first->sample({0.2, 0.4, 0.8})[0], 0.2), "in-flight cached snapshot remains valid");
        std::filesystem::remove(path);
        bool failed = false;
        try { (void)cache.get(path.u8string()); } catch (const LutError&) { failed = true; }
        require(failed, "removed LUT is reported instead of silently using stale data");
        const auto& avata = avata2Cube();
        require(avata->size() == 33, "embedded supplied LUT has the original grid size");
        require(std::string(kAvata2LutSha256) == "b18162854ab47702068410c33afa98a8cb6eef159fc5a04ce0e65fad0fd8947e", "embedded LUT provenance");
        require(avata->sample({0, 0, 0}) == RGB{0, 0, 0} && avata->sample({1, 1, 1}) == RGB{1, 1, 1}, "embedded LUT endpoints");
        out = avata->sample({0.5, 0.5, 0.5});
        require(near(out[0], 0.487409) && near(out[1], 0.487448) && near(out[2], 0.487588), "embedded LUT gray matches the original supplied node");
        out = avata->sample({0.25, 0.5, 0.75});
        require(near(out[0], 0.051170) && near(out[1], 0.473806) && near(out[2], 0.907144), "embedded LUT color matches independently inventoried source node");
        out = avata->sample({0.75, 0.25, 0.5});
        require(near(out[0], 0.873104) && near(out[1], 0.110849) && near(out[2], 0.494441), "embedded LUT retains channel ordering at a second independent node");
        std::ifstream original("assets/luts/DJI-Avata-2-DLogM-to-Rec709.cube");
        require(static_cast<bool>(original), "original LUT asset available");
        const auto supplied = Cube3D::read(original);
        for (const RGB point : {RGB{0.25, 0.5, 0.75}, RGB{0.125, 0.625, 0.875}, RGB{0.317, 0.491, 0.683}}) {
            const auto expected = supplied.sample(point), embedded = avata->sample(point);
            require(near(expected[0], embedded[0]) && near(expected[1], embedded[1]) && near(expected[2], embedded[2]), "embedded conversion agrees with original file at grid and interpolated coordinates");
        }
        std::cout << "3D LUT and transfer pipeline: " << checks << " checks passed (synthetic and supplied LUTs)\n";
    } catch (const std::exception& error) { std::cerr << "LUT test failed: " << error.what() << '\n'; return 1; }
}
