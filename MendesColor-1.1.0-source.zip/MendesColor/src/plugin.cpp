#include "pipeline.hpp"
#include "avata2_lut.hpp"
#include "diagnostics.hpp"
#include "ofxImageEffect.h"
#include "ofxProperty.h"
#include <cstddef>
#include <cstring>
#include <memory>
#include <new>

namespace {
OfxHost* host = nullptr;
const OfxImageEffectSuiteV1* effects = nullptr;
const OfxPropertySuiteV1* props = nullptr;
const OfxParameterSuiteV1* params = nullptr;
const OfxMessageSuiteV2* messages = nullptr;

void check(OfxStatus status) { if (status != kOfxStatOK) throw status; }
bool equal(const char* a, const char* b) { return a && b && std::strcmp(a, b) == 0; }
void str(OfxPropertySetHandle p, const char* key, const char* value, int index = 0) {
    const auto status = props->propSetString(p, key, index, value);
    if (status != kOfxStatOK) mendes::diagnostic("propSetString", status, key);
    check(status);
}
void optionalStr(OfxPropertySetHandle p, const char* key, const char* value) {
    const auto status = props->propSetString(p, key, 0, value);
    // Cosmetic metadata must not gate effect discovery on hosts that lack it.
    // Invalid handles, allocation failures and required properties remain fatal.
    if (status == kOfxStatErrUnknown || status == kOfxStatErrUnsupported) {
        mendes::diagnostic("optional property skipped", status, key);
        return;
    }
    if (status != kOfxStatOK) mendes::diagnostic("propSetString", status, key);
    check(status);
}
void integer(OfxPropertySetHandle p, const char* key, int value, int index = 0) {
    const auto status = props->propSetInt(p, key, index, value);
    if (status != kOfxStatOK) mendes::diagnostic("propSetInt", status, key);
    check(status);
}
void number(OfxPropertySetHandle p, const char* key, double value) {
    const auto status = props->propSetDouble(p, key, 0, value);
    if (status != kOfxStatOK) mendes::diagnostic("propSetDouble", status, key);
    check(status);
}
struct Spec { const char* name; const char* label; double value, min, max, displayMin, displayMax; const char* hint; };
constexpr Spec specs[] = {
    {"exposure", "Exposure (stops)", 0, -10, 10, -4, 4, "RGB gain of 2^stops. Best on linear-light input."},
    {"contrast", "Contrast", 1, 0, 4, 0, 2, "Linear contrast around Pivot."},
    {"pivot", "Pivot", 0.18, 0.001, 1, 0.01, 1, "Fixed point of the contrast operation."},
    {"gamma", "Creative Gamma", 1, 0.1, 4, 0.2, 3, "Artistic signed RGB power, not the output color-space gamma. Leave at 1 for LUT normalization; configure Rec.709 Gamma 2.4 in Resolve."},
    {"temperature", "Warm / Cool", 0, -1, 1, -1, 1, "Creative RGB balance. Positive warms. Not calibrated Kelvin."},
    {"tint", "Magenta / Green", 0, -1, 1, -1, 1, "Creative RGB balance. Positive adds magenta."},
    {"saturation", "Saturation", 1, 0, 3, 0, 2, "Mix around a Rec.709-weighted RGB luma. No gamut conversion."},
    {"black", "Black Point", 0, -1, 0.99, -0.1, 0.5, "Input level mapped to zero, before other controls. Must be below White Point."},
    {"white", "White Point", 1, 0.01, 16, 0.5, 2, "Input level mapped to one. Must exceed Black Point by at least 0.0001."},
    {"mix", "Effect Mix", 1, 0, 1, 0, 1, "Blend the complete grade with the original image. Zero bypasses processing."}
};
constexpr std::size_t count = sizeof(specs) / sizeof(specs[0]);
struct Instance {
    OfxImageClipHandle source = nullptr, output = nullptr;
    OfxParamHandle look = nullptr;
    OfxParamHandle controls[count]{};
    OfxParamHandle inputTransform = nullptr, lutFile = nullptr, lutEncoding = nullptr;
    mendes::CubeCache lutCache;
};

OfxPropertySetHandle effectProps(OfxImageEffectHandle e) {
    OfxPropertySetHandle p = nullptr; check(effects->getPropertySet(e, &p)); return p;
}
Instance* instance(OfxImageEffectHandle e) {
    void* data = nullptr; check(props->propGetPointer(effectProps(e), kOfxPropInstanceData, 0, &data));
    if (!data) throw OfxStatus(kOfxStatErrBadHandle);
    return static_cast<Instance*>(data);
}
mendes::Controls controls(Instance* i, double time) {
    double values[count]{};
    for (std::size_t n = 0; n < count; ++n) check(params->paramGetValueAtTime(i->controls[n], time, &values[n]));
    int look = 0; check(params->paramGetValueAtTime(i->look, time, &look));
    mendes::Controls c;
    c.exposure = values[0]; c.contrast = values[1]; c.pivot = values[2]; c.gamma = values[3];
    c.temperature = values[4]; c.tint = values[5]; c.saturation = values[6];
    c.black = values[7]; c.white = values[8]; c.mix = values[9]; c.look = static_cast<mendes::Look>(look);
    if (!mendes::valid(c)) throw OfxStatus(kOfxStatErrValue);
    return c;
}
mendes::Pipeline pipeline(Instance* i, double time) {
    const auto c = controls(i, time);
    int transform = 0, encoding = 0;
    check(params->paramGetValueAtTime(i->inputTransform, time, &transform));
    check(params->paramGetValueAtTime(i->lutEncoding, time, &encoding));
    if (transform < 0 || transform > 2 || encoding < 0 || encoding > 1) throw OfxStatus(kOfxStatErrValue);
    if (!transform || c.mix == 0) return mendes::Pipeline(c);
    if (transform == 1) return mendes::Pipeline(c, mendes::avata2Cube(), static_cast<mendes::LutEncoding>(encoding));
    char* path = nullptr;
    check(params->paramGetValueAtTime(i->lutFile, time, &path));
    return mendes::Pipeline(c, i->lutCache.get(path ? path : ""), static_cast<mendes::LutEncoding>(encoding));
}
OfxStatus load() {
    if (!host || !host->fetchSuite) return kOfxStatErrMissingHostFeature;
    effects = static_cast<const OfxImageEffectSuiteV1*>(host->fetchSuite(host->host, kOfxImageEffectSuite, 1));
    props = static_cast<const OfxPropertySuiteV1*>(host->fetchSuite(host->host, kOfxPropertySuite, 1));
    params = static_cast<const OfxParameterSuiteV1*>(host->fetchSuite(host->host, kOfxParameterSuite, 1));
    messages = static_cast<const OfxMessageSuiteV2*>(host->fetchSuite(host->host, kOfxMessageSuite, 2));
    const auto status = effects && props && params ? kOfxStatOK : kOfxStatErrMissingHostFeature;
    mendes::diagnostic(kOfxActionLoad, status);
    return status;
}
OfxStatus describe(OfxImageEffectHandle e) {
    auto p = effectProps(e);
    str(p, kOfxPropLabel, "Mendes Color");
    str(p, kOfxImageEffectPluginPropGrouping, "Mendes");
    optionalStr(p, kOfxPropPluginDescription, "CPU color grading with an embedded DJI Avata 2 input LUT and creative looks.");
    str(p, kOfxImageEffectPropSupportedContexts, kOfxImageEffectContextFilter);
    str(p, kOfxImageEffectPropSupportedContexts, kOfxImageEffectContextGeneral, 1);
    str(p, kOfxImageEffectPropSupportedPixelDepths, kOfxBitDepthFloat);
    str(p, kOfxImageEffectPluginRenderThreadSafety, kOfxImageEffectRenderFullySafe);
    integer(p, kOfxImageEffectPropSupportsTiles, 1);
    integer(p, kOfxImageEffectPropSupportsMultiResolution, 1);
    integer(p, kOfxImageEffectPropSupportsMultipleClipDepths, 0);
    integer(p, kOfxImageEffectPropTemporalClipAccess, 0);
    mendes::diagnostic(kOfxActionDescribe, kOfxStatOK);
    return kOfxStatOK;
}
OfxStatus describeContext(OfxImageEffectHandle e, OfxPropertySetHandle in) {
    char* context = nullptr; check(props->propGetString(in, kOfxImageEffectPropContext, 0, &context));
    if (!equal(context, kOfxImageEffectContextFilter) && !equal(context, kOfxImageEffectContextGeneral)) {
        mendes::diagnostic(kOfxImageEffectActionDescribeInContext, kOfxStatErrUnsupported, context);
        return kOfxStatErrUnsupported;
    }
    for (const char* clip : {kOfxImageEffectSimpleSourceClipName, kOfxImageEffectOutputClipName}) {
        OfxPropertySetHandle p = nullptr; check(effects->clipDefine(e, clip, &p));
        str(p, kOfxImageEffectPropSupportedComponents, kOfxImageComponentRGBA);
        integer(p, kOfxImageEffectPropSupportsTiles, 1);
    }
    OfxParamSetHandle set = nullptr; check(effects->getParamSet(e, &set));
    OfxPropertySetHandle page = nullptr, look = nullptr;
    check(params->paramDefine(set, kOfxParamTypePage, "Controls", &page));
    OfxPropertySetHandle transform = nullptr, file = nullptr, encoding = nullptr;
    check(params->paramDefine(set, kOfxParamTypeChoice, "inputTransform", &transform));
    str(transform, kOfxPropLabel, "Input LUT");
    str(transform, kOfxParamPropChoiceOption, "None / Already converted", 0);
    str(transform, kOfxParamPropChoiceOption, "DJI Avata 2 D-Log M to Rec.709 (embedded)", 1);
    str(transform, kOfxParamPropChoiceOption, "Custom 3D .cube file", 2);
    integer(transform, kOfxParamPropDefault, 0);
    integer(transform, kOfxParamPropAnimates, 0);
    str(transform, kOfxParamPropHint, "Embedded preset uses the exact user-supplied LUT. Apply to original D-Log M RGB before any other normalization; set Resolve output/monitoring to Rec.709 Gamma 2.4.");
    check(params->paramDefine(set, kOfxParamTypeString, "lutFile", &file));
    str(file, kOfxPropLabel, "LUT File (.cube)");
    str(file, kOfxParamPropStringMode, kOfxParamStringIsFilePath);
    str(file, kOfxParamPropDefault, "");
    integer(file, kOfxParamPropAnimates, 0);
    str(file, kOfxParamPropHint, "Only used for Custom 3D .cube file. The embedded Avata 2 preset requires no external file. Supports pure 3D cubes of size 2-65.");
    check(params->paramDefine(set, kOfxParamTypeChoice, "lutEncoding", &encoding));
    str(encoding, kOfxPropLabel, "LUT Output Transfer");
    str(encoding, kOfxParamPropChoiceOption, "Keep LUT output", 0);
    str(encoding, kOfxParamPropChoiceOption, "BT.709 OETF to Gamma 2.4", 1);
    integer(encoding, kOfxParamPropDefault, 0);
    integer(encoding, kOfxParamPropAnimates, 0);
    str(encoding, kOfxParamPropHint, "Only choose the conversion if the LUT is documented to output the BT.709 camera OETF. Do not convert a LUT already encoded for gamma 2.4.");
    str(page, kOfxParamPropPageChild, "inputTransform", 0);
    str(page, kOfxParamPropPageChild, "lutFile", 1);
    str(page, kOfxParamPropPageChild, "lutEncoding", 2);
    check(params->paramDefine(set, kOfxParamTypeChoice, "look", &look));
    str(look, kOfxPropLabel, "Creative Look");
    str(look, kOfxParamPropHint, "Creative looks applied after input conversion. Neutral leaves the converted colors unchanged.");
    const char* looks[] = {"Neutral", "Cool Cinema", "Warm Cinema", "Vivid", "Soft Green", "Earth"};
    for (int n = 0; n < 6; ++n) str(look, kOfxParamPropChoiceOption, looks[n], n);
    integer(look, kOfxParamPropDefault, 0);
    integer(look, kOfxParamPropAnimates, 1);
    str(page, kOfxParamPropPageChild, "look", 3);
    for (std::size_t n = 0; n < count; ++n) {
        const auto& s = specs[n]; OfxPropertySetHandle p = nullptr;
        check(params->paramDefine(set, kOfxParamTypeDouble, s.name, &p));
        str(p, kOfxPropLabel, s.label); str(p, kOfxParamPropHint, s.hint);
        str(p, kOfxParamPropDoubleType, kOfxParamDoubleTypePlain);
        number(p, kOfxParamPropDefault, s.value); number(p, kOfxParamPropMin, s.min);
        number(p, kOfxParamPropMax, s.max); number(p, kOfxParamPropDisplayMin, s.displayMin);
        number(p, kOfxParamPropDisplayMax, s.displayMax); number(p, kOfxParamPropIncrement, 0.01);
        integer(p, kOfxParamPropDigits, 3); integer(p, kOfxParamPropAnimates, 1);
        str(page, kOfxParamPropPageChild, s.name, static_cast<int>(n + 4));
    }
    mendes::diagnostic(kOfxImageEffectActionDescribeInContext, kOfxStatOK, context);
    return kOfxStatOK;
}
OfxStatus create(OfxImageEffectHandle e) {
    auto i = std::make_unique<Instance>();
    check(effects->clipGetHandle(e, kOfxImageEffectSimpleSourceClipName, &i->source, nullptr));
    check(effects->clipGetHandle(e, kOfxImageEffectOutputClipName, &i->output, nullptr));
    OfxParamSetHandle set = nullptr; check(effects->getParamSet(e, &set));
    check(params->paramGetHandle(set, "look", &i->look, nullptr));
    check(params->paramGetHandle(set, "inputTransform", &i->inputTransform, nullptr));
    check(params->paramGetHandle(set, "lutFile", &i->lutFile, nullptr));
    check(params->paramGetHandle(set, "lutEncoding", &i->lutEncoding, nullptr));
    for (std::size_t n = 0; n < count; ++n) check(params->paramGetHandle(set, specs[n].name, &i->controls[n], nullptr));
    check(props->propSetPointer(effectProps(e), kOfxPropInstanceData, 0, i.get()));
    i.release();
    mendes::diagnostic(kOfxActionCreateInstance, kOfxStatOK);
    return kOfxStatOK;
}
struct Image {
    OfxPropertySetHandle handle = nullptr;
    void* data = nullptr;
    int bounds[4]{}, rowBytes = 0;
    bool premultiplied = false;
    Image(OfxImageClipHandle clip, double time) {
        check(effects->clipGetImage(clip, time, nullptr, &handle));
        try {
            char *depth = nullptr, *components = nullptr, *premult = nullptr;
            check(props->propGetString(handle, kOfxImageEffectPropPixelDepth, 0, &depth));
            check(props->propGetString(handle, kOfxImageEffectPropComponents, 0, &components));
            if (!equal(depth, kOfxBitDepthFloat) || !equal(components, kOfxImageComponentRGBA))
                throw OfxStatus(kOfxStatErrImageFormat);
            check(props->propGetPointer(handle, kOfxImagePropData, 0, &data));
            check(props->propGetIntN(handle, kOfxImagePropBounds, 4, bounds));
            check(props->propGetInt(handle, kOfxImagePropRowBytes, 0, &rowBytes));
            check(props->propGetString(handle, kOfxImageEffectPropPreMultiplication, 0, &premult));
            premultiplied = equal(premult, kOfxImagePreMultiplied);
            if (!data || bounds[2] < bounds[0] || bounds[3] < bounds[1]) throw OfxStatus(kOfxStatErrImageFormat);
        } catch (...) { effects->clipReleaseImage(handle); handle = nullptr; throw; }
    }
    ~Image() { if (handle) effects->clipReleaseImage(handle); }
    Image(const Image&) = delete;
    Image& operator=(const Image&) = delete;
    float* pixel(int x, int y) const {
        if (x < bounds[0] || y < bounds[1] || x >= bounds[2] || y >= bounds[3]) return nullptr;
        auto offset = (static_cast<std::ptrdiff_t>(y) - bounds[1]) * rowBytes +
            (static_cast<std::ptrdiff_t>(x) - bounds[0]) * 4 * sizeof(float);
        return reinterpret_cast<float*>(static_cast<char*>(data) + offset);
    }
};
OfxStatus render(OfxImageEffectHandle e, OfxPropertySetHandle in) {
    double time = 0; int window[4]{};
    check(props->propGetDouble(in, kOfxPropTime, 0, &time));
    check(props->propGetIntN(in, kOfxImageEffectPropRenderWindow, 4, window));
    auto i = instance(e); const auto grade = pipeline(i, time);
    if (messages && messages->clearPersistentMessage) messages->clearPersistentMessage(e);
    Image src(i->source, time), dst(i->output, time);
    // Clip preferences request source premultiplication for output; fail on mismatch.
    if (src.premultiplied != dst.premultiplied) return kOfxStatErrImageFormat;
    const int x1 = std::max(window[0], dst.bounds[0]), y1 = std::max(window[1], dst.bounds[1]);
    const int x2 = std::min(window[2], dst.bounds[2]), y2 = std::min(window[3], dst.bounds[3]);
    for (int y = y1; y < y2; ++y) {
        if (effects->abort(e)) return kOfxStatFailed;
        for (int x = x1; x < x2; ++x) {
            auto out = dst.pixel(x, y); const auto input = src.pixel(x, y);
            if (input) grade.pixel(input, out, src.premultiplied);
            else std::fill_n(out, 4, 0.0f);
        }
    }
    return kOfxStatOK;
}
OfxStatus mainEntry(const char* action, const void* handle, OfxPropertySetHandle in, OfxPropertySetHandle out) {
    try {
        if (equal(action, kOfxActionLoad)) return load();
        if (equal(action, kOfxActionUnload)) return kOfxStatOK;
        if (!effects || !props || !params) return kOfxStatErrMissingHostFeature;
        auto e = reinterpret_cast<OfxImageEffectHandle>(const_cast<void*>(handle));
        if (equal(action, kOfxActionDescribe)) return describe(e);
        if (equal(action, kOfxImageEffectActionDescribeInContext)) return describeContext(e, in);
        if (equal(action, kOfxActionCreateInstance)) return create(e);
        if (equal(action, kOfxActionInstanceChanged)) {
            if (messages && messages->clearPersistentMessage) messages->clearPersistentMessage(e);
            return kOfxStatReplyDefault;
        }
        if (equal(action, kOfxActionDestroyInstance)) {
            auto i = instance(e); check(props->propSetPointer(effectProps(e), kOfxPropInstanceData, 0, nullptr));
            delete i; return kOfxStatOK;
        }
        if (equal(action, kOfxImageEffectActionRender)) return render(e, in);
        if (equal(action, kOfxImageEffectActionIsIdentity)) {
            double time = 0; check(props->propGetDouble(in, kOfxPropTime, 0, &time));
            if (!pipeline(instance(e), time).isIdentity()) return kOfxStatReplyDefault;
            str(out, kOfxPropName, kOfxImageEffectSimpleSourceClipName); number(out, kOfxPropTime, time);
            return kOfxStatOK;
        }
        if (equal(action, kOfxImageEffectActionGetRegionOfDefinition)) {
            double time = 0; OfxRectD r{}; check(props->propGetDouble(in, kOfxPropTime, 0, &time));
            check(effects->clipGetRegionOfDefinition(instance(e)->source, time, &r));
            const double values[] = {r.x1, r.y1, r.x2, r.y2};
            check(props->propSetDoubleN(out, kOfxImageEffectPropRegionOfDefinition, 4, values)); return kOfxStatOK;
        }
        if (equal(action, kOfxImageEffectActionGetClipPreferences)) {
            OfxPropertySetHandle p = nullptr; char* mode = nullptr;
            check(effects->clipGetPropertySet(instance(e)->source, &p));
            check(props->propGetString(p, kOfxImageEffectPropPreMultiplication, 0, &mode));
            str(out, kOfxImageEffectPropPreMultiplication, mode); return kOfxStatOK;
        }
        return kOfxStatReplyDefault;
    } catch (const mendes::LutError& error) {
        if (messages && messages->setPersistentMessage && handle)
            messages->setPersistentMessage(const_cast<void*>(handle), kOfxMessageError, "MendesColorLUT", "%s", error.what());
        return kOfxStatErrValue;
    } catch (OfxStatus s) {
        if (!equal(action, kOfxImageEffectActionRender)) mendes::diagnostic(action, s);
        return s;
    }
      catch (const std::bad_alloc&) { return kOfxStatErrMemory; }
      catch (...) { return kOfxStatFailed; }
}
void setHost(OfxHost* h) { host = h; }
OfxPlugin plugin{kOfxImageEffectPluginApi, 1, "io.github.carloseusjpdel.MendesColor", mendes::kOfxVersionMajor, mendes::kOfxVersionMinor, setHost, mainEntry};
} // namespace

#ifdef _WIN32
#define EXPORT extern "C" __declspec(dllexport)
#else
#define EXPORT extern "C" __attribute__((visibility("default")))
#endif
EXPORT int OfxGetNumberOfPlugins() { return 1; }
EXPORT OfxPlugin* OfxGetPlugin(int index) { return index == 0 ? &plugin : nullptr; }
