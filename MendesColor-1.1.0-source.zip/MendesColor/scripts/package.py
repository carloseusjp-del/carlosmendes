"""Package an already-built Windows plugin; no network or application execution."""
import hashlib
import json
import re
from pathlib import Path
import shutil
import struct
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = re.search(r'^#define MENDES_COLOR_VERSION "([0-9]+\.[0-9]+\.[0-9]+)"$',
                    (ROOT / 'src/version.hpp').read_text(), re.MULTILINE).group(1)
DIST = ROOT / 'dist'
BINARY = DIST / 'MendesColor.ofx.bundle/Contents/Win64/MendesColor.ofx'
data = BINARY.read_bytes()
assert data[:2] == b'MZ', 'Not a Windows binary'
pe = struct.unpack_from('<I', data, 60)[0]
assert data[pe:pe+4] == b'PE\0\0', 'Missing PE header'
assert struct.unpack_from('<H', data, pe+4)[0] == 0x8664, 'Expected Windows x64'
assert struct.unpack_from('<H', data, pe+22)[0] & 0x2000, 'Expected a DLL'
lut_folder = ROOT / 'assets/luts'
lut = json.loads((lut_folder / 'PROVENANCE.json').read_text(encoding='utf-8'))
if hashlib.sha256((lut_folder / lut['file']).read_bytes()).hexdigest() != lut['sha256']:
    raise ValueError('LUT provenance does not match its bytes.')
resources = DIST / 'MendesColor.ofx.bundle/Contents/Resources/LUTs'
resources.mkdir(parents=True, exist_ok=True)
for name in [lut['file'], 'PROVENANCE.json']:
    shutil.copyfile(lut_folder / name, resources / name)
manifest = {
    'name': 'Mendes Color', 'version': VERSION,
    'plugin_id': 'io.github.carloseusjpdel.MendesColor',
    'platform': 'Windows x86-64', 'format': 'OpenFX',
    'sha256': hashlib.sha256(data).hexdigest(),
    'rendering': 'CPU, RGBA float32',
    'resolve_validation': 'not_run',
    'implementation': 'Original color operations; not ToneLab algorithms or presets',
    'embedded_lut': lut,
}
(DIST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
for source, destination in [('README.md', 'LEIA-ME.md'), ('VALIDACAO.md', 'VALIDACAO.md'), ('LUT-AVATA2.md', 'LUT-AVATA2.md'), ('Install.ps1', 'Install.ps1'),
                            ('LICENSE', 'LICENSE'), ('THIRD_PARTY.md', 'THIRD_PARTY.md'),
                            ('vendor/openfx/LICENSE.md', 'OPENFX-LICENSE.md')]:
    shutil.copyfile(ROOT / source, DIST / destination)
files = [*sorted((DIST / 'MendesColor.ofx.bundle').rglob('*')),
         *[DIST / name for name in ['manifest.json', 'LEIA-ME.md', 'VALIDACAO.md', 'LUT-AVATA2.md', 'Install.ps1',
                                    'LICENSE', 'THIRD_PARTY.md', 'OPENFX-LICENSE.md']]]
for evidence in sorted((ROOT / 'build').glob('rea-*.json')):
    record = json.loads(evidence.read_text())
    if record['subject']['digest']['sha256'] != manifest['sha256']:
        raise ValueError('Stale REA evidence: ' + evidence.name)
    folder = DIST / 'verification'
    folder.mkdir(exist_ok=True)
    target = folder / evidence.name
    shutil.copyfile(evidence, target)
    files.append(target)
release = DIST / f'MendesColor-{VERSION}-Windows-x64.zip'
with zipfile.ZipFile(release, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        if path.is_file():
            archive.write(path, path.relative_to(DIST))
source = DIST / f'MendesColor-{VERSION}-source.zip'
with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if relative.parts[0] in {'.git', 'build', 'dist'} or '__pycache__' in relative.parts:
            continue
        if path.is_file():
            archive.write(path, Path('MendesColor') / relative)
for path in [release, source]:
    print(path.name, path.stat().st_size, hashlib.sha256(path.read_bytes()).hexdigest())
print('Resolve/Windows runtime verification remains pending.')
