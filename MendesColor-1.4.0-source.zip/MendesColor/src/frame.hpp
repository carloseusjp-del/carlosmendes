#pragma once
#include "pipeline.hpp"

namespace mendes {
struct FrameGeometry {
    double left = 0, bottom = 0, width = 1, height = 1080, scaleX = 1, scaleY = 1, pixelAspect = 1, time = 0;
    HalationPlan legacy{}, soft{}, local{}, global{}, bloom{};
    PixelPosition position(int x, int y) const {
        const double cx = (x + .5) * pixelAspect / scaleX - left, cy = (y + .5) / scaleY - bottom;
        return {cx / width, cy / height, cx * 1080 / height, cy * 1080 / height, time};
    }
    int haloX() const { return std::max({legacy.supportX(), local.supportX(), global.supportX()}); }
    int haloY() const { return std::max({legacy.supportY(), local.supportY(), global.supportY()}); }
    int supportX() const { return soft.supportX() + haloX() + bloom.supportX(); }
    int supportY() const { return soft.supportY() + haloY() + bloom.supportY(); }
};
inline HalationPlan spatialPlan(double radius, const FrameGeometry &g) {
    auto size = [](double v) { return static_cast<int>(std::round(std::clamp(v, 1.0, 128.0))); };
    const double r = radius * g.height / 1080;
    return {size(r * g.scaleX / g.pixelAspect), size(r * g.scaleY), 1};
}
inline void configureFrame(FrameGeometry &g, const Pipeline &pipe, HalationPreset preset) {
    const auto a = pipe.advanced();
    g.legacy={};g.soft={};g.local={};g.global={};g.bloom={};
    if (pipe.mix() == 0)
        return;
    if (!a || !a->enabled(AdvId::HalationEnable))
        g.legacy = halationPlan(preset, g.height, g.scaleX, g.scaleY, g.pixelAspect);
    if (!a)
        return;
    if (a->enabled(AdvId::GrainEnable) && a->value(AdvId::GrainBlur) > 0 && a->value(AdvId::GrainIntensity)>0)
        g.soft = spatialPlan(1 + a->value(AdvId::GrainBlur) * .035, g);
    if (a->enabled(AdvId::HalationEnable)) {
        g.local = spatialPlan(1 + a->value(AdvId::HalationLocalDiffusion) * .18, g);
        g.global = spatialPlan(1 + a->value(AdvId::HalationGlobalDiffusion) * .50, g);
    }
    if (a->enabled(AdvId::BloomEnable))
        g.bloom = spatialPlan(1 + a->value(AdvId::BloomDiffusion) * .35, g);
}

template <class Reader> class FrameEngine {
    const Pipeline &pipe_;
    const Advanced *adv_;
    FrameGeometry g_;
    Reader read_;
    bool premult_;
    std::array<HaloBuffer, 3> soft_, bloom_;
    HaloBuffer coverage_, local_, global_;
    double alpha(int x, int y) const {
        const auto p = read_(x, y);
        return p && std::isfinite(p[3]) ? std::clamp<double>(p[3], 0, 1) : 0;
    }
    RGB base(int x, int y) const {
        const auto p = read_(x, y);
        if (!p || p[3] == 0)
            return {};
        RGB v{p[0], p[1], p[2]};
        if (premult_)
            for (double &c : v)
                c /= p[3];
        v = pipe_.postGrade(v);
        return adv_ ? adv_->position(v, g_.position(x, y)) : v;
    }
    RGB grained(int x, int y) const {
        auto v = base(x, y);
        if (g_.soft.enabled()) {
            const double coverage = coverage_.at(x, y);
            if (coverage > 1e-9) {
                RGB soft{};
                for (int c = 0; c < 3; ++c)
                    soft[c] = soft_[c].at(x, y) / coverage;
                v = blend(v, soft, adv_->value(AdvId::GrainBlur) / 100 * adv_->value(AdvId::GrainIntensity)/100);
            }
        }
        return adv_ ? adv_->grain(v, g_.position(x, y)) : v;
    }
    double emission(int x, int y) const {
        const auto rgb = grained(x, y);
        return g_.local.enabled() ? adv_->haloEmission(rgb, alpha(x, y)) : halationEmission(rgb, alpha(x, y));
    }
    RGB halated(int x, int y) const {
        auto v = grained(x, y);
        if (g_.local.enabled()) {
            const auto add = adv_->halo(v, local_.at(x, y), global_.at(x, y), emission(x, y));
            if (adv_->enabled(AdvId::HalationMaskMode))
                return add;
            for (int c = 0; c < 3; ++c)
                v[c] += add[c];
        } else if (g_.legacy.enabled()) {
            const auto add = halationColor(local_.at(x, y), emission(x, y), g_.legacy);
            for (int c = 0; c < 3; ++c)
                v[c] += add[c];
        }
        return v;
    }

  public:
    FrameEngine(const Pipeline &pipeline, FrameGeometry geometry, Reader reader, bool premultiplied)
        : pipe_(pipeline), adv_(pipeline.advanced()), g_(geometry), read_(reader), premult_(premultiplied) {}
    template <class Abort> bool build(RectI output, RectI source, Abort abort) {
        if (pipe_.mix() == 0)
            return true;
        const RectI haloOutput = expand(output, g_.bloom.supportX(), g_.bloom.supportY());
        const RectI softOutput = expand(haloOutput, g_.haloX(), g_.haloY());
        if (g_.soft.enabled()) {
            if (!coverage_.build(
                    softOutput, source, g_.soft, [&](int x, int y) { return alpha(x, y); }, abort))
                return false;
            for (int c = 0; c < 3; ++c) {
                if (!soft_[c].build(
                        softOutput, source, g_.soft,
                        [&](int x, int y) {
                            const auto v = base(x, y);
                            return std::isfinite(v[c]) ? v[c] * alpha(x, y) : 0;
                        },
                        abort, false))
                    return false;
            }
        }
        if (g_.legacy.enabled() || g_.local.enabled()) {
            const auto plan = g_.local.enabled() ? g_.local : g_.legacy;
            if (!local_.build(haloOutput, source, plan, [&](int x, int y) { return emission(x, y); }, abort))
                return false;
        }
        if (g_.global.enabled() &&
            !global_.build(
                haloOutput, source, g_.global, [&](int x, int y) { return emission(x, y); }, abort))
            return false;
        if (g_.bloom.enabled())
            for (int c = 0; c < 3; ++c) {
                if (!bloom_[c].build(
                        output, source, g_.bloom,
                        [&](int x, int y) { return adv_->bloomEmission(halated(x, y), alpha(x, y))[c]; },
                        abort))
                    return false;
            }
        return true;
    }
    void pixel(const float *src, float *dst, int x, int y) const {
        if (pipe_.mix() == 0) {
            std::copy_n(src, 4, dst);
            return;
        }
        if (pipe_.isIdentity() && !g_.legacy.enabled()) {
            std::copy_n(src, 4, dst);
            return;
        }
        const float alphaValue = src[3];
        if (premult_ && alphaValue == 0) {
            dst[0] = dst[1] = dst[2] = 0;
            dst[3] = alphaValue;
            return;
        }
        RGB input{src[0], src[1], src[2]};
        if (premult_)
            for (double &c : input)
                c /= alphaValue;
        auto result = halated(x, y);
        if (g_.bloom.enabled()) {
            RGB blurred{};
            for (int c = 0; c < 3; ++c)
                blurred[c] = bloom_[c].at(x, y);
            const auto addition = adv_->bloom(result, blurred, adv_->bloomEmission(result, alpha(x, y)));
            if (adv_->enabled(AdvId::BloomMaskMode))
                result = addition;
            else
                for (int c = 0; c < 3; ++c)
                    result[c] += addition[c];
        }
        result = pipe_.finish(input, result);
        for (int c = 0; c < 3; ++c)
            dst[c] = static_cast<float>(result[c] * (premult_ ? alphaValue : 1));
        dst[3] = alphaValue;
    }
};
} // namespace mendes
