#include "pipeline.hpp"
#include "frame.hpp"
#include "lut_dialog.hpp"
#include "halation.hpp"
#include "avata2_lut.hpp"
#include "diagnostics.hpp"
#include "ofxImageEffect.h"
#include "ofxProperty.h"
#include <cstddef>
#include <cstring>
#include <memory>
#include <new>

namespace {
OfxHost* host = nullptr;
const OfxImageEffectSuiteV1* effects = nullptr;
const OfxPropertySuiteV1* props = nullptr;
const OfxParameterSuiteV1* params = nullptr;
const OfxMessageSuiteV2* messages = nullptr;

void check(OfxStatus status) { if (status != kOfxStatOK) throw status; }
bool equal(const char* a, const char* b) { return a && b && std::strcmp(a, b) == 0; }
void str(OfxPropertySetHandle p, const char* key, const char* value, int index = 0) {
    const auto status = props->propSetString(p, key, index, value);
    if (status != kOfxStatOK) mendes::diagnostic("propSetString", status, key);
    check(status);
}
void optionalStr(OfxPropertySetHandle p, const char* key, const char* value) {
    const auto status = props->propSetString(p, key, 0, value);
    // Cosmetic metadata must not gate effect discovery on hosts that lack it.
    // Invalid handles, allocation failures and required properties remain fatal.
    if (status == kOfxStatErrUnknown || status == kOfxStatErrUnsupported) {
        mendes::diagnostic("optional property skipped", status, key);
        return;
    }
    if (status != kOfxStatOK) mendes::diagnostic("propSetString", status, key);
    check(status);
}
void integer(OfxPropertySetHandle p, const char* key, int value, int index = 0) {
    const auto status = props->propSetInt(p, key, index, value);
    if (status != kOfxStatOK) mendes::diagnostic("propSetInt", status, key);
    check(status);
}
void number(OfxPropertySetHandle p, const char* key, double value) {
    const auto status = props->propSetDouble(p, key, 0, value);
    if (status != kOfxStatOK) mendes::diagnostic("propSetDouble", status, key);
    check(status);
}
struct Navigation {
    const char* choice; const char* previous; const char* next; const char* label;
    int options; bool animated;
};
const std::vector<Navigation> navigation=[] {
    std::vector<Navigation> result{
    {"inputTransform", "inputLutPrevious", "inputLutNext", "Input LUT", 3, false},
    {"lutEncoding", "lutTransferPrevious", "lutTransferNext", "LUT Output Transfer", 2, false},
    {"look", "lookPrevious", "lookNext", "Creative Look", static_cast<int>(mendes::kLookCount), true},
    {"halationPreset", "halationPrevious", "halationNext", "Halation", 4, true}
    };
    for(const auto& s:mendes::kAdvSpecs)if(s.type==mendes::AdvType::Choice)
        result.push_back({s.name,s.previous,s.next,s.label,static_cast<int>(s.options.size()),true});
    return result;
}();
void navigationButtons(OfxParamSetHandle set, OfxPropertySetHandle page, int first,
                       const Navigation& nav, const char* parent = nullptr) {
    for (int direction = 0; direction < 2; ++direction) {
        const char* name = direction == 0 ? nav.previous : nav.next;
        OfxPropertySetHandle button = nullptr;
        check(params->paramDefine(set, kOfxParamTypePushButton, name, &button));
        str(button, kOfxPropLabel, direction == 0 ? "ANTERIOR" : "PR\xc3\x93XIMO");
        const std::string hint = std::string(direction == 0 ? "Previous option in " : "Next option in ") + nav.label +
            ". Wraps around the menu. If this choice already has keyframes, updates only the current time.";
        str(button, kOfxParamPropHint, hint.c_str());
        if (parent) str(button, kOfxParamPropParent, parent);
        str(page, kOfxParamPropPageChild, name, first + direction);
    }
}
struct Spec { const char* name; const char* label; double value, min, max, displayMin, displayMax; const char* hint; };
constexpr Spec specs[] = {
    {"exposure", "Exposure (stops)", 0, -10, 10, -4, 4, "RGB gain of 2^stops. Best on linear-light input."},
    {"contrast", "Contrast", 1, 0, 4, 0, 2, "Linear contrast around Pivot."},
    {"pivot", "Pivot", 0.18, 0.001, 1, 0.01, 1, "Fixed point of the contrast operation."},
    {"gamma", "Creative Gamma", 1, 0.1, 4, 0.2, 3, "Artistic signed RGB power, not the output color-space gamma. Leave at 1 for LUT normalization; configure Rec.709 Gamma 2.4 in Resolve."},
    {"temperature", "Warm / Cool", 0, -1, 1, -1, 1, "Creative RGB balance. Positive warms. Not calibrated Kelvin."},
    {"tint", "Magenta / Green", 0, -1, 1, -1, 1, "Creative RGB balance. Positive adds magenta."},
    {"saturation", "Saturation", 1, 0, 3, 0, 2, "Mix around a Rec.709-weighted RGB luma. No gamut conversion."},
    {"black", "Black Point", 0, -1, 0.99, -0.1, 0.5, "Input level mapped to zero, before other controls. Must be below White Point."},
    {"white", "White Point", 1, 0.01, 16, 0.5, 2, "Input level mapped to one. Must exceed Black Point by at least 0.0001."},
    {"mix", "Effect Mix", 1, 0, 1, 0, 1, "Blend the complete grade with the original image. Zero bypasses processing."}
};
constexpr std::size_t count = sizeof(specs) / sizeof(specs[0]);
struct Instance {
    OfxImageClipHandle source = nullptr, output = nullptr;
    OfxParamHandle look = nullptr, lookStrength = nullptr;
    OfxParamHandle controls[count]{};
    OfxParamHandle inputTransform = nullptr, lutFile = nullptr, lutEncoding = nullptr;
    OfxParamHandle halation = nullptr;
    std::array<OfxParamHandle,mendes::kAdvCount> advanced{};
    std::array<OfxParamHandle,16> slotPaths{};
    OfxParamHandle slotFile=nullptr;
    mendes::CubeCache lutCache;
    std::array<mendes::CubeCache,16> slotCache;
};

OfxPropertySetHandle effectProps(OfxImageEffectHandle e) {
    OfxPropertySetHandle p = nullptr; check(effects->getPropertySet(e, &p)); return p;
}
Instance* instance(OfxImageEffectHandle e) {
    void* data = nullptr; check(props->propGetPointer(effectProps(e), kOfxPropInstanceData, 0, &data));
    if (!data) throw OfxStatus(kOfxStatErrBadHandle);
    return static_cast<Instance*>(data);
}
mendes::Controls controls(Instance* i, double time) {
    double values[count]{};
    for (std::size_t n = 0; n < count; ++n) check(params->paramGetValueAtTime(i->controls[n], time, &values[n]));
    int look = 0; check(params->paramGetValueAtTime(i->look, time, &look));
    mendes::Controls c;
    c.exposure = values[0]; c.contrast = values[1]; c.pivot = values[2]; c.gamma = values[3];
    c.temperature = values[4]; c.tint = values[5]; c.saturation = values[6];
    c.black = values[7]; c.white = values[8]; c.mix = values[9]; c.look = static_cast<mendes::Look>(look);
    check(params->paramGetValueAtTime(i->lookStrength, time, &c.lookStrength));
    if (!mendes::valid(c)) throw OfxStatus(kOfxStatErrValue);
    return c;
}
mendes::Pipeline pipeline(Instance* i, double time) {
    const auto c = controls(i, time);
    int transform = 0, encoding = 0;
    check(params->paramGetValueAtTime(i->inputTransform, time, &transform));
    check(params->paramGetValueAtTime(i->lutEncoding, time, &encoding));
    if (transform < 0 || transform > 2 || encoding < 0 || encoding > 1) throw OfxStatus(kOfxStatErrValue);
    if(c.mix==0)return mendes::Pipeline(c);
    mendes::AdvSettings settings;
    for(const auto& spec:mendes::kAdvSpecs) {
        if(spec.type==mendes::AdvType::Button)continue;
        const auto n=static_cast<std::size_t>(spec.id);
        if(spec.type==mendes::AdvType::Number)check(params->paramGetValueAtTime(i->advanced[n],time,&settings.values[n]));
        else {int v=0;check(params->paramGetValueAtTime(i->advanced[n],time,&v));settings.values[n]=v;}
    }
    if(!mendes::validAdvanced(settings))throw OfxStatus(kOfxStatErrValue);
    std::shared_ptr<const mendes::Cube3D> custom;
    const int slot=static_cast<int>(settings.get(mendes::AdvId::CustomLut));
    if(slot>0) {
        char* file=nullptr;check(params->paramGetValueAtTime(i->slotPaths[slot-1],time,&file));
        if(file && *file)custom=i->slotCache[slot-1].get(file);
    }
    auto advanced=std::make_shared<const mendes::Advanced>(settings,custom);
    if (!transform)return mendes::Pipeline(c,{},mendes::LutEncoding::Preserve,advanced);
    if (transform == 1) return mendes::Pipeline(c, mendes::avata2Cube(), static_cast<mendes::LutEncoding>(encoding),advanced);
    char* path = nullptr;
    check(params->paramGetValueAtTime(i->lutFile, time, &path));
    return mendes::Pipeline(c, i->lutCache.get(path ? path : ""), static_cast<mendes::LutEncoding>(encoding),advanced);
}
mendes::HalationPreset halationPreset(Instance* i, double time) {
    int value = 0; check(params->paramGetValueAtTime(i->halation, time, &value));
    if (value < 0 || value > 3) throw OfxStatus(kOfxStatErrValue);
    return static_cast<mendes::HalationPreset>(value);
}
struct Geometry {
    mendes::HalationPlan halo;
    mendes::FrameGeometry frame;
    double scaleX = 1, scaleY = 1, pixelAspect = 1;
    OfxRectD canonical(mendes::RectI r) const {
        return {r.x1 * pixelAspect / scaleX, r.y1 / scaleY, r.x2 * pixelAspect / scaleX, r.y2 / scaleY};
    }
};
Geometry geometry(Instance* i, double time, OfxPropertySetHandle in, mendes::HalationPreset preset,const mendes::Pipeline& pipeline) {
    Geometry g;
    const auto adv=pipeline.advanced();
    if(pipeline.mix()==0 || (preset==mendes::HalationPreset::Off && (!adv || !adv->geometryNeeded())))return g;
    check(props->propGetDouble(in, kOfxImageEffectPropRenderScale, 0, &g.scaleX));
    check(props->propGetDouble(in, kOfxImageEffectPropRenderScale, 1, &g.scaleY));
    OfxPropertySetHandle p = nullptr; check(effects->clipGetPropertySet(i->source, &p));
    check(props->propGetDouble(p, kOfxImagePropPixelAspectRatio, 0, &g.pixelAspect));
    OfxRectD rod{}; check(effects->clipGetRegionOfDefinition(i->source, time, &rod));
    try {
        if(!std::isfinite(rod.x1)||!std::isfinite(rod.x2)||rod.x2<=rod.x1)throw std::invalid_argument("Invalid frame bounds");
        (void)mendes::halationPlan(mendes::HalationPreset::Off,rod.y2-rod.y1,g.scaleX,g.scaleY,g.pixelAspect);
        g.frame.left=rod.x1;g.frame.bottom=rod.y1;g.frame.width=rod.x2-rod.x1;g.frame.height=rod.y2-rod.y1;
        g.frame.scaleX=g.scaleX;g.frame.scaleY=g.scaleY;g.frame.pixelAspect=g.pixelAspect;g.frame.time=time;
        mendes::configureFrame(g.frame,pipeline,preset);g.halo=g.frame.legacy;
    }
    catch (const std::invalid_argument&) { throw OfxStatus(kOfxStatErrValue); }
    return g;
}
OfxStatus load() {
    if (!host || !host->fetchSuite) return kOfxStatErrMissingHostFeature;
    effects = static_cast<const OfxImageEffectSuiteV1*>(host->fetchSuite(host->host, kOfxImageEffectSuite, 1));
    props = static_cast<const OfxPropertySuiteV1*>(host->fetchSuite(host->host, kOfxPropertySuite, 1));
    params = static_cast<const OfxParameterSuiteV1*>(host->fetchSuite(host->host, kOfxParameterSuite, 1));
    messages = static_cast<const OfxMessageSuiteV2*>(host->fetchSuite(host->host, kOfxMessageSuite, 2));
    const auto status = effects && props && params ? kOfxStatOK : kOfxStatErrMissingHostFeature;
    mendes::diagnostic(kOfxActionLoad, status);
    return status;
}
OfxStatus describe(OfxImageEffectHandle e) {
    auto p = effectProps(e);
    str(p, kOfxPropLabel, "Mendes Color");
    str(p, kOfxImageEffectPluginPropGrouping, "Mendes");
    optionalStr(p, kOfxPropPluginDescription, "CPU color grading with an embedded DJI Avata 2 input LUT, creative looks and highlight halation.");
    str(p, kOfxImageEffectPropSupportedContexts, kOfxImageEffectContextFilter);
    str(p, kOfxImageEffectPropSupportedContexts, kOfxImageEffectContextGeneral, 1);
    str(p, kOfxImageEffectPropSupportedPixelDepths, kOfxBitDepthFloat);
    str(p, kOfxImageEffectPluginRenderThreadSafety, kOfxImageEffectRenderFullySafe);
    integer(p, kOfxImageEffectPropSupportsTiles, 1);
    integer(p, kOfxImageEffectPropSupportsMultiResolution, 1);
    integer(p, kOfxImageEffectPropSupportsMultipleClipDepths, 0);
    integer(p, kOfxImageEffectPropTemporalClipAccess, 0);
    mendes::diagnostic(kOfxActionDescribe, kOfxStatOK);
    return kOfxStatOK;
}
OfxStatus describeContext(OfxImageEffectHandle e, OfxPropertySetHandle in) {
    char* context = nullptr; check(props->propGetString(in, kOfxImageEffectPropContext, 0, &context));
    if (!equal(context, kOfxImageEffectContextFilter) && !equal(context, kOfxImageEffectContextGeneral)) {
        mendes::diagnostic(kOfxImageEffectActionDescribeInContext, kOfxStatErrUnsupported, context);
        return kOfxStatErrUnsupported;
    }
    for (const char* clip : {kOfxImageEffectSimpleSourceClipName, kOfxImageEffectOutputClipName}) {
        OfxPropertySetHandle p = nullptr; check(effects->clipDefine(e, clip, &p));
        str(p, kOfxImageEffectPropSupportedComponents, kOfxImageComponentRGBA);
        integer(p, kOfxImageEffectPropSupportsTiles, 1);
    }
    OfxParamSetHandle set = nullptr; check(effects->getParamSet(e, &set));
    OfxPropertySetHandle page = nullptr, look = nullptr;
    check(params->paramDefine(set, kOfxParamTypePage, "Controls", &page));
    str(page,kOfxPropLabel,"Camera, Looks & Base");
    OfxPropertySetHandle transform = nullptr, file = nullptr, encoding = nullptr;
    check(params->paramDefine(set, kOfxParamTypeChoice, "inputTransform", &transform));
    str(transform, kOfxPropLabel, "Input LUT");
    str(transform, kOfxParamPropChoiceOption, "None / Already converted", 0);
    str(transform, kOfxParamPropChoiceOption, "DJI Avata 2 D-Log M to Rec.709 (embedded)", 1);
    str(transform, kOfxParamPropChoiceOption, "Custom 3D .cube file", 2);
    integer(transform, kOfxParamPropDefault, 0);
    integer(transform, kOfxParamPropAnimates, 0);
    str(transform, kOfxParamPropHint, "Embedded preset uses the exact user-supplied LUT. Apply to original D-Log M RGB before any other normalization; set Resolve output/monitoring to Rec.709 Gamma 2.4.");
    navigationButtons(set, page, 1, navigation[0]);
    check(params->paramDefine(set, kOfxParamTypeString, "lutFile", &file));
    str(file, kOfxPropLabel, "LUT File (.cube)");
    str(file, kOfxParamPropStringMode, kOfxParamStringIsFilePath);
    str(file, kOfxParamPropDefault, "");
    integer(file, kOfxParamPropAnimates, 0);
    str(file, kOfxParamPropHint, "Only used for Custom 3D .cube file. The embedded Avata 2 preset requires no external file. Supports pure 3D cubes of size 2-65.");
    check(params->paramDefine(set, kOfxParamTypeChoice, "lutEncoding", &encoding));
    str(encoding, kOfxPropLabel, "LUT Output Transfer");
    str(encoding, kOfxParamPropChoiceOption, "Keep LUT output", 0);
    str(encoding, kOfxParamPropChoiceOption, "BT.709 OETF to Gamma 2.4", 1);
    integer(encoding, kOfxParamPropDefault, 0);
    integer(encoding, kOfxParamPropAnimates, 0);
    str(encoding, kOfxParamPropHint, "Only choose the conversion if the LUT is documented to output the BT.709 camera OETF. Do not convert a LUT already encoded for gamma 2.4.");
    navigationButtons(set, page, 5, navigation[1]);
    str(page, kOfxParamPropPageChild, "inputTransform", 0);
    str(page, kOfxParamPropPageChild, "lutFile", 3);
    str(page, kOfxParamPropPageChild, "lutEncoding", 4);
    check(params->paramDefine(set, kOfxParamTypeChoice, "look", &look));
    str(look, kOfxPropLabel, "Creative Look");
    str(look, kOfxParamPropHint, "For D-Log M choose the embedded Avata 2 Input LUT first. All creative styles operate after that conversion; Neutral preserves its colors.");
    for (std::size_t n = 0; n < mendes::kLookCount; ++n)
        str(look, kOfxParamPropChoiceOption, mendes::kLooks[n].name, static_cast<int>(n));
    integer(look, kOfxParamPropDefault, 0);
    integer(look, kOfxParamPropAnimates, 1);
    str(page, kOfxParamPropPageChild, "look", 7);
    navigationButtons(set, page, 8, navigation[2]);
    OfxPropertySetHandle strength = nullptr;
    check(params->paramDefine(set, kOfxParamTypeDouble, "lookStrength", &strength));
    str(strength, kOfxPropLabel, "Look Strength");
    str(strength, kOfxParamPropDoubleType, kOfxParamDoubleTypePlain);
    str(strength, kOfxParamPropHint, "Creative style intensity from 0 to 1. Zero keeps the input LUT and your manual correction; Effect Mix bypasses the entire plugin instead.");
    number(strength, kOfxParamPropDefault, 1);
    number(strength, kOfxParamPropMin, 0); number(strength, kOfxParamPropMax, 1);
    number(strength, kOfxParamPropDisplayMin, 0); number(strength, kOfxParamPropDisplayMax, 1);
    number(strength, kOfxParamPropIncrement, 0.01);
    integer(strength, kOfxParamPropDigits, 2); integer(strength, kOfxParamPropAnimates, 1);
    str(page, kOfxParamPropPageChild, "lookStrength", 10);
    for (std::size_t n = 0; n < count; ++n) {
        const auto& s = specs[n]; OfxPropertySetHandle p = nullptr;
        check(params->paramDefine(set, kOfxParamTypeDouble, s.name, &p));
        str(p, kOfxPropLabel, s.label); str(p, kOfxParamPropHint, s.hint);
        str(p, kOfxParamPropDoubleType, kOfxParamDoubleTypePlain);
        number(p, kOfxParamPropDefault, s.value); number(p, kOfxParamPropMin, s.min);
        number(p, kOfxParamPropMax, s.max); number(p, kOfxParamPropDisplayMin, s.displayMin);
        number(p, kOfxParamPropDisplayMax, s.displayMax); number(p, kOfxParamPropIncrement, 0.01);
        integer(p, kOfxParamPropDigits, 3); integer(p, kOfxParamPropAnimates, 1);
        str(page, kOfxParamPropPageChild, s.name, static_cast<int>(n + 11));
    }
    OfxPropertySetHandle haloPage = nullptr, haloGroup = nullptr, preset = nullptr;
    check(params->paramDefine(set, kOfxParamTypePage, "Halation", &haloPage));
    str(haloPage, kOfxPropLabel, "Halation");
    check(params->paramDefine(set, kOfxParamTypeGroup, "halationGroup", &haloGroup));
    str(haloGroup, kOfxPropLabel, "Halation"); integer(haloGroup, kOfxParamPropGroupOpen, 1);
    check(params->paramDefine(set, kOfxParamTypeChoice, "halationPreset", &preset));
    str(preset, kOfxPropLabel, "Halation Preset");
    str(preset, kOfxParamPropParent, "halationGroup");
    for (int n = 0; n < 4; ++n) str(preset, kOfxParamPropChoiceOption, mendes::kHalationNames[n], n);
    integer(preset, kOfxParamPropDefault, 0); integer(preset, kOfxParamPropAnimates, 1);
    str(preset, kOfxParamPropHint, "Warm highlight-edge halo after Input LUT and Creative Look, before Effect Mix. Minimum/Medium/High increase spread and amount. Off preserves existing projects. CPU spatial effect; alpha is unchanged.");
    str(haloPage, kOfxParamPropPageChild, "halationPreset", 0);
    navigationButtons(set, haloPage, 1, navigation[3], "halationGroup");
    for(const auto& group:mendes::kAdvGroups) {
        OfxPropertySetHandle section=nullptr,panel=nullptr;
        check(params->paramDefine(set,kOfxParamTypeGroup,group.name,&section));
        str(section,kOfxPropLabel,group.label);integer(section,kOfxParamPropGroupOpen,0);
        check(params->paramDefine(set,kOfxParamTypePage,group.page,&panel));str(panel,kOfxPropLabel,group.label);
        int child=0;
        for(const auto& spec:mendes::kAdvSpecs) {
            if(!equal(spec.group,group.name))continue;
            const char* type=spec.type==mendes::AdvType::Number?kOfxParamTypeDouble:spec.type==mendes::AdvType::Boolean?kOfxParamTypeBoolean:
                spec.type==mendes::AdvType::Choice?kOfxParamTypeChoice:kOfxParamTypePushButton;
            OfxPropertySetHandle prop=nullptr;check(params->paramDefine(set,type,spec.name,&prop));
            str(prop,kOfxPropLabel,spec.label);str(prop,kOfxParamPropParent,group.name);
            str(panel,kOfxParamPropPageChild,spec.name,child++);
            if(spec.type==mendes::AdvType::Number) {
                str(prop,kOfxParamPropDoubleType,kOfxParamDoubleTypePlain);
                number(prop,kOfxParamPropDefault,spec.value);number(prop,kOfxParamPropMin,spec.min);number(prop,kOfxParamPropMax,spec.max);
                number(prop,kOfxParamPropDisplayMin,spec.min);number(prop,kOfxParamPropDisplayMax,spec.max);
                number(prop,kOfxParamPropIncrement,spec.max-spec.min>10?1:.01);integer(prop,kOfxParamPropDigits,3);
                integer(prop,kOfxParamPropAnimates,1);
            } else if(spec.type!=mendes::AdvType::Button) {
                integer(prop,kOfxParamPropDefault,static_cast<int>(spec.value));integer(prop,kOfxParamPropAnimates,1);
            }
            if(spec.type==mendes::AdvType::Choice) {
                for(std::size_t n=0;n<spec.options.size();++n)str(prop,kOfxParamPropChoiceOption,spec.options[n],static_cast<int>(n));
                const Navigation nav{spec.name,spec.previous,spec.next,spec.label,static_cast<int>(spec.options.size()),true};
                navigationButtons(set,panel,child,nav,group.name);child+=2;
            }
            if(spec.id==mendes::AdvId::CustomLut) {
                OfxPropertySetHandle filePath=nullptr;
                check(params->paramDefine(set,kOfxParamTypeString,"customSlotPath",&filePath));
                str(filePath,kOfxPropLabel,"File (.cube / .3dl)");str(filePath,kOfxParamPropStringMode,kOfxParamStringIsFilePath);
                str(filePath,kOfxParamPropDefault,"");str(filePath,kOfxParamPropParent,group.name);integer(filePath,kOfxParamPropAnimates,0);
                str(panel,kOfxParamPropPageChild,"customSlotPath",child++);
            }
        }
    }
    for(int slot=0;slot<16;++slot) {
        const std::string name="customLutPath"+std::to_string(slot+1);OfxPropertySetHandle path=nullptr;
        check(params->paramDefine(set,kOfxParamTypeString,name.c_str(),&path));str(path,kOfxParamPropDefault,"");
        integer(path,kOfxParamPropSecret,1);integer(path,kOfxParamPropAnimates,0);
    }
    mendes::diagnostic(kOfxImageEffectActionDescribeInContext, kOfxStatOK, context);
    return kOfxStatOK;
}
class EditGuard {
    OfxParamSetHandle set_=nullptr;bool open_=false;
public:
    EditGuard(OfxImageEffectHandle e,const char* label) {
        check(effects->getParamSet(e,&set_));
        if(params->paramEditBegin && params->paramEditEnd){check(params->paramEditBegin(set_,label));open_=true;}
    }
    ~EditGuard(){if(open_)params->paramEditEnd(set_);}
    void finish(){if(open_){open_=false;check(params->paramEditEnd(set_));}}
};
void writeAdvanced(Instance* i,mendes::AdvId id,double time,double value) {
    const auto& s=mendes::advSpec(id);const auto handle=i->advanced[static_cast<std::size_t>(id)];
    if(!std::isfinite(value)||value<s.min||value>s.max)throw OfxStatus(kOfxStatErrValue);
    unsigned keys=0;if(params->paramGetNumKeys)check(params->paramGetNumKeys(handle,&keys));
    if((keys && !params->paramSetValueAtTime)||(!keys && !params->paramSetValue))throw OfxStatus(kOfxStatErrMissingHostFeature);
    if(s.type==mendes::AdvType::Number)check(keys?params->paramSetValueAtTime(handle,time,value):params->paramSetValue(handle,value));
    else check(keys?params->paramSetValueAtTime(handle,time,static_cast<int>(value)):params->paramSetValue(handle,static_cast<int>(value)));
}
int advancedChoice(Instance* i,mendes::AdvId id,double time) {
    int value=0;check(params->paramGetValueAtTime(i->advanced[static_cast<std::size_t>(id)],time,&value));return value;
}
void writePath(OfxParamHandle handle,const std::string& value) {
    if(!params->paramSetValue)throw OfxStatus(kOfxStatErrMissingHostFeature);
    check(params->paramSetValue(handle,value.c_str()));
}
void refreshSlot(Instance* i,double time) {
    const int slot=advancedChoice(i,mendes::AdvId::CustomLut,time);
    if(slot<0||slot>16)throw OfxStatus(kOfxStatErrValue);
    char* path=nullptr;
    if(slot)check(params->paramGetValueAtTime(i->slotPaths[slot-1],time,&path));
    writePath(i->slotFile,path?path:"");
}
void advancedChanged(Instance* i,const mendes::AdvSpec& spec,double time) {
    using I=mendes::AdvId;using T=mendes::AdvType;
    if(spec.id==I::CustomLut){refreshSlot(i,time);return;}
    if(spec.type==T::Choice && spec.id==mendes::groupPreset(spec.group)) {
        const int index=advancedChoice(i,spec.id,time);
        if(index<0 || index>=static_cast<int>(spec.options.size()))throw OfxStatus(kOfxStatErrValue);
        for(const auto& [id,value]:mendes::designedPreset(spec.id,index))writeAdvanced(i,id,time,value);
        return;
    }
    if(spec.type==T::Button) {
        for(const auto& item:mendes::kAdvSpecs)if(equal(item.group,spec.group) && item.type!=T::Button)writeAdvanced(i,item.id,time,item.value);
        return;
    }
    if(spec.type==T::Choice && equal(spec.group,"ColorSpaceGroup"))writeAdvanced(i,I::ColorSpaceEnable,time,1);
    constexpr I masks[]={I::ShowSkinSelection,I::VignetteMaskMode,I::HalationMaskMode,I::BloomMaskMode};
    constexpr I enables[]={I::SkinEnable,I::VignetteEnable,I::HalationEnable,I::BloomEnable};
    for(int n=0;n<4;++n)if(spec.id==masks[n] && advancedChoice(i,spec.id,time)) {
        writeAdvanced(i,enables[n],time,1);
        for(auto mask:masks)if(mask!=spec.id)writeAdvanced(i,mask,time,0);
    }
    const std::string name(spec.name);
    const bool intensity=name.size()>=9 && name.compare(name.size()-9,9,"Intensity")==0;
    const auto preset=mendes::groupPreset(spec.group);
    if(spec.type==T::Number && !intensity && preset!=I::Count)writeAdvanced(i,preset,time,0);
}
OfxStatus instanceChanged(OfxImageEffectHandle e, OfxPropertySetHandle in) {
    if (messages && messages->clearPersistentMessage) messages->clearPersistentMessage(e);
    char* name = nullptr;
    if (!in || props->propGetString(in, kOfxPropName, 0, &name) != kOfxStatOK) return kOfxStatReplyDefault;
    for (const auto& nav : navigation) {
        const int direction = equal(name, nav.previous) ? -1 : (equal(name, nav.next) ? 1 : 0);
        if (!direction) continue;
        char *reason = nullptr, *type = nullptr;
        check(props->propGetString(in, kOfxPropChangeReason, 0, &reason));
        check(props->propGetString(in, kOfxPropType, 0, &type));
        // Time changes and plugin-generated notifications must never advance a menu.
        if (!equal(reason, kOfxChangeUserEdited) || !equal(type, kOfxTypeParameter)) return kOfxStatReplyDefault;
        double time = 0; check(props->propGetDouble(in, kOfxPropTime, 0, &time));
        OfxParamSetHandle set = nullptr; check(effects->getParamSet(e, &set));
        OfxParamHandle target = nullptr; check(params->paramGetHandle(set, nav.choice, &target, nullptr));
        int value = 0; check(params->paramGetValueAtTime(target, time, &value));
        if (value < 0 || value >= nav.options) return kOfxStatErrValue;
        const int next = (value + direction + nav.options) % nav.options;
        unsigned keys = 0;
        if (nav.animated && params->paramGetNumKeys) check(params->paramGetNumKeys(target, &keys));
        if ((keys && !params->paramSetValueAtTime) || (!keys && !params->paramSetValue)) return kOfxStatErrMissingHostFeature;
        EditGuard edit(e,nav.label);
        const auto status = keys ? params->paramSetValueAtTime(target, time, next) : params->paramSetValue(target, next);
        check(status);
        for(const auto& spec:mendes::kAdvSpecs)if(equal(spec.name,nav.choice))advancedChanged(instance(e),spec,time);
        edit.finish();
        return kOfxStatOK;
    }
    char *reason=nullptr,*type=nullptr;
    if(props->propGetString(in,kOfxPropChangeReason,0,&reason)!=kOfxStatOK ||
       props->propGetString(in,kOfxPropType,0,&type)!=kOfxStatOK ||
       !equal(reason,kOfxChangeUserEdited)||!equal(type,kOfxTypeParameter))return kOfxStatReplyDefault;
    double time=0;check(props->propGetDouble(in,kOfxPropTime,0,&time));auto i=instance(e);
    if(equal(name,"customSlotPath")) {
        EditGuard edit(e,"Custom LUT file");
        char* path=nullptr;check(params->paramGetValueAtTime(i->slotFile,time,&path));
        int slot=advancedChoice(i,mendes::AdvId::CustomLut,time);
        if(slot<0||slot>16)throw OfxStatus(kOfxStatErrValue);
        if(!slot){slot=1;writeAdvanced(i,mendes::AdvId::CustomLut,time,slot);}
        writePath(i->slotPaths[slot-1],path?path:"");edit.finish();return kOfxStatOK;
    }
    for(const auto& spec:mendes::kAdvSpecs)if(equal(name,spec.name)) {
        if(spec.id==mendes::AdvId::LoadCustomLut) {
            const auto paths=mendes::chooseLuts();if(paths.empty())return kOfxStatOK;
            int slot=advancedChoice(i,mendes::AdvId::CustomLut,time);if(slot==0)slot=1;
            if(slot<1||slot>16)throw OfxStatus(kOfxStatErrValue);
            for(std::size_t n=0;n<paths.size();++n)i->slotCache[(slot-1+n)%16].get(paths[n]);
            EditGuard edit(e,"Load custom LUTs");
            for(std::size_t n=0;n<paths.size();++n)writePath(i->slotPaths[(slot-1+n)%16],paths[n]);
            writeAdvanced(i,mendes::AdvId::CustomLut,time,slot);refreshSlot(i,time);edit.finish();return kOfxStatOK;
        }
        EditGuard edit(e,spec.label);advancedChanged(i,spec,time);edit.finish();return kOfxStatOK;
    }
    return kOfxStatReplyDefault;
}
OfxStatus create(OfxImageEffectHandle e) {
    auto i = std::make_unique<Instance>();
    check(effects->clipGetHandle(e, kOfxImageEffectSimpleSourceClipName, &i->source, nullptr));
    check(effects->clipGetHandle(e, kOfxImageEffectOutputClipName, &i->output, nullptr));
    OfxParamSetHandle set = nullptr; check(effects->getParamSet(e, &set));
    check(params->paramGetHandle(set, "look", &i->look, nullptr));
    check(params->paramGetHandle(set, "lookStrength", &i->lookStrength, nullptr));
    check(params->paramGetHandle(set, "inputTransform", &i->inputTransform, nullptr));
    check(params->paramGetHandle(set, "lutFile", &i->lutFile, nullptr));
    check(params->paramGetHandle(set, "lutEncoding", &i->lutEncoding, nullptr));
    check(params->paramGetHandle(set, "halationPreset", &i->halation, nullptr));
    for(const auto& spec:mendes::kAdvSpecs)if(spec.type!=mendes::AdvType::Button)
        check(params->paramGetHandle(set,spec.name,&i->advanced[static_cast<std::size_t>(spec.id)],nullptr));
    check(params->paramGetHandle(set,"customSlotPath",&i->slotFile,nullptr));
    for(int slot=0;slot<16;++slot){const auto name="customLutPath"+std::to_string(slot+1);check(params->paramGetHandle(set,name.c_str(),&i->slotPaths[slot],nullptr));}
    for (std::size_t n = 0; n < count; ++n) check(params->paramGetHandle(set, specs[n].name, &i->controls[n], nullptr));
    check(props->propSetPointer(effectProps(e), kOfxPropInstanceData, 0, i.get()));
    i.release();
    mendes::diagnostic(kOfxActionCreateInstance, kOfxStatOK);
    return kOfxStatOK;
}
struct Image {
    OfxPropertySetHandle handle = nullptr;
    void* data = nullptr;
    int bounds[4]{}, rowBytes = 0;
    bool premultiplied = false;
    Image(OfxImageClipHandle clip, double time, const OfxRectD* region = nullptr) {
        check(effects->clipGetImage(clip, time, region, &handle));
        try {
            char *depth = nullptr, *components = nullptr, *premult = nullptr;
            check(props->propGetString(handle, kOfxImageEffectPropPixelDepth, 0, &depth));
            check(props->propGetString(handle, kOfxImageEffectPropComponents, 0, &components));
            if (!equal(depth, kOfxBitDepthFloat) || !equal(components, kOfxImageComponentRGBA))
                throw OfxStatus(kOfxStatErrImageFormat);
            check(props->propGetPointer(handle, kOfxImagePropData, 0, &data));
            check(props->propGetIntN(handle, kOfxImagePropBounds, 4, bounds));
            check(props->propGetInt(handle, kOfxImagePropRowBytes, 0, &rowBytes));
            check(props->propGetString(handle, kOfxImageEffectPropPreMultiplication, 0, &premult));
            premultiplied = equal(premult, kOfxImagePreMultiplied);
            if (!data || bounds[2] < bounds[0] || bounds[3] < bounds[1]) throw OfxStatus(kOfxStatErrImageFormat);
        } catch (...) { effects->clipReleaseImage(handle); handle = nullptr; throw; }
    }
    ~Image() { if (handle) effects->clipReleaseImage(handle); }
    Image(const Image&) = delete;
    Image& operator=(const Image&) = delete;
    float* pixel(int x, int y) const {
        if (x < bounds[0] || y < bounds[1] || x >= bounds[2] || y >= bounds[3]) return nullptr;
        auto offset = (static_cast<std::ptrdiff_t>(y) - bounds[1]) * rowBytes +
            (static_cast<std::ptrdiff_t>(x) - bounds[0]) * 4 * sizeof(float);
        return reinterpret_cast<float*>(static_cast<char*>(data) + offset);
    }
};
OfxStatus render(OfxImageEffectHandle e, OfxPropertySetHandle in) {
    double time = 0; int window[4]{};
    check(props->propGetDouble(in, kOfxPropTime, 0, &time));
    check(props->propGetIntN(in, kOfxImageEffectPropRenderWindow, 4, window));
    auto i = instance(e); const auto grade = pipeline(i, time);
    const auto preset = halationPreset(i, time);
    const auto g = geometry(i, time, in, preset,grade);
    const auto requested = g.canonical(mendes::expand({window[0], window[1], window[2], window[3]}, g.frame.supportX(), g.frame.supportY()));
    if (messages && messages->clearPersistentMessage) messages->clearPersistentMessage(e);
    Image src(i->source, time, g.frame.supportX()||g.frame.supportY() ? &requested : nullptr), dst(i->output, time);
    // Clip preferences request source premultiplication for output; fail on mismatch.
    if (src.premultiplied != dst.premultiplied) return kOfxStatErrImageFormat;
    const int x1 = std::max(window[0], dst.bounds[0]), y1 = std::max(window[1], dst.bounds[1]);
    const int x2 = std::min(window[2], dst.bounds[2]), y2 = std::min(window[3], dst.bounds[3]);
    mendes::FrameEngine engine(grade,g.frame,[&](int x,int y){return src.pixel(x,y);},src.premultiplied);
    if(!engine.build({x1,y1,x2,y2},{src.bounds[0],src.bounds[1],src.bounds[2],src.bounds[3]},[&]{return effects->abort(e)!=0;}))return kOfxStatFailed;
    for (int y = y1; y < y2; ++y) {
        if (effects->abort(e)) return kOfxStatFailed;
        for (int x = x1; x < x2; ++x) {
            auto out = dst.pixel(x, y); const auto input = src.pixel(x, y);
            if(input)engine.pixel(input,out,x,y);
            else std::fill_n(out, 4, 0.0f);
        }
    }
    return kOfxStatOK;
}
OfxStatus mainEntry(const char* action, const void* handle, OfxPropertySetHandle in, OfxPropertySetHandle out) {
    try {
        if (equal(action, kOfxActionLoad)) return load();
        if (equal(action, kOfxActionUnload)) return kOfxStatOK;
        if (!effects || !props || !params) return kOfxStatErrMissingHostFeature;
        auto e = reinterpret_cast<OfxImageEffectHandle>(const_cast<void*>(handle));
        if (equal(action, kOfxActionDescribe)) return describe(e);
        if (equal(action, kOfxImageEffectActionDescribeInContext)) return describeContext(e, in);
        if (equal(action, kOfxActionCreateInstance)) return create(e);
        if (equal(action, kOfxActionInstanceChanged)) return instanceChanged(e, in);
        if (equal(action, kOfxActionDestroyInstance)) {
            auto i = instance(e); check(props->propSetPointer(effectProps(e), kOfxPropInstanceData, 0, nullptr));
            delete i; return kOfxStatOK;
        }
        if (equal(action, kOfxImageEffectActionRender)) return render(e, in);
        if (equal(action, kOfxImageEffectActionIsIdentity)) {
            double time = 0; check(props->propGetDouble(in, kOfxPropTime, 0, &time));
            auto i = instance(e); const auto grade = pipeline(i, time);
            const auto preset = halationPreset(i, time);
            if (!grade.isIdentity() || (grade.mix() != 0 && preset != mendes::HalationPreset::Off)) return kOfxStatReplyDefault;
            str(out, kOfxPropName, kOfxImageEffectSimpleSourceClipName); number(out, kOfxPropTime, time);
            return kOfxStatOK;
        }
        if (equal(action, kOfxImageEffectActionGetRegionsOfInterest)) {
            double time = 0; check(props->propGetDouble(in, kOfxPropTime, 0, &time));
            auto i = instance(e); const auto preset = halationPreset(i, time);
            double mix = 1; check(params->paramGetValueAtTime(i->controls[9], time, &mix));
            if(mix==0)return kOfxStatReplyDefault;
            const auto grade=pipeline(i,time);
            const auto g = geometry(i, time, in, preset,grade);
            if(g.frame.supportX()==0 && g.frame.supportY()==0)return kOfxStatReplyDefault;
            double roi[4]{};
            for (int n = 0; n < 4; ++n) check(props->propGetDouble(in, kOfxImageEffectPropRegionOfInterest, n, &roi[n]));
            const double padX = g.frame.supportX() * g.pixelAspect / g.scaleX, padY = g.frame.supportY() / g.scaleY;
            const double values[] = {roi[0] - padX, roi[1] - padY, roi[2] + padX, roi[3] + padY};
            check(props->propSetDoubleN(out, "OfxImageClipPropRoI_Source", 4, values)); return kOfxStatOK;
        }
        if (equal(action, kOfxImageEffectActionGetRegionOfDefinition)) {
            double time = 0; OfxRectD r{}; check(props->propGetDouble(in, kOfxPropTime, 0, &time));
            check(effects->clipGetRegionOfDefinition(instance(e)->source, time, &r));
            const double values[] = {r.x1, r.y1, r.x2, r.y2};
            check(props->propSetDoubleN(out, kOfxImageEffectPropRegionOfDefinition, 4, values)); return kOfxStatOK;
        }
        if (equal(action, kOfxImageEffectActionGetClipPreferences)) {
            OfxPropertySetHandle p = nullptr; char* mode = nullptr;
            check(effects->clipGetPropertySet(instance(e)->source, &p));
            check(props->propGetString(p, kOfxImageEffectPropPreMultiplication, 0, &mode));
            str(out, kOfxImageEffectPropPreMultiplication, mode); return kOfxStatOK;
        }
        return kOfxStatReplyDefault;
    } catch (const mendes::LutError& error) {
        if (messages && messages->setPersistentMessage && handle)
            messages->setPersistentMessage(const_cast<void*>(handle), kOfxMessageError, "MendesColorLUT", "%s", error.what());
        return kOfxStatErrValue;
    } catch (OfxStatus s) {
        if (!equal(action, kOfxImageEffectActionRender)) mendes::diagnostic(action, s);
        return s;
    }
      catch (const std::bad_alloc&) { return kOfxStatErrMemory; }
      catch (...) { return kOfxStatFailed; }
}
void setHost(OfxHost* h) { host = h; }
OfxPlugin plugin{kOfxImageEffectPluginApi, 1, "io.github.carloseusjpdel.MendesColor", mendes::kOfxVersionMajor, mendes::kOfxVersionMinor, setHost, mainEntry};
} // namespace

#ifdef _WIN32
#define EXPORT extern "C" __declspec(dllexport)
#else
#define EXPORT extern "C" __attribute__((visibility("default")))
#endif
EXPORT int OfxGetNumberOfPlugins() { return 1; }
EXPORT OfxPlugin* OfxGetPlugin(int index) { return index == 0 ? &plugin : nullptr; }
