#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include "looks.hpp"

namespace mendes {
// Independent creative RGB operations. No ToneLab code or LUTs are used.
struct Controls {
    double exposure = 0, contrast = 1, pivot = 0.18, gamma = 1;
    double temperature = 0, tint = 0, saturation = 1;
    double black = 0, white = 1, mix = 1;
    Look look = Look::Neutral;
    double lookStrength = 1;
};
using RGB = std::array<double, 3>;

template<class Processor>
inline void processPixel(const Processor& processor, const float* src, float* dst, bool premultiplied) {
    const float alpha = src[3];
    if (processor.isIdentity()) { std::copy_n(src, 4, dst); return; }
    RGB rgb{src[0], src[1], src[2]};
    if (premultiplied) {
        if (alpha == 0) { dst[0] = dst[1] = dst[2] = 0; dst[3] = alpha; return; }
        for (double& v : rgb) v /= alpha;
    }
    rgb = processor.apply(rgb);
    for (int i = 0; i < 3; ++i) dst[i] = static_cast<float>(rgb[i] * (premultiplied ? alpha : 1.0));
    dst[3] = alpha;
}

inline bool valid(const Controls& c) {
    return std::isfinite(c.exposure) && std::abs(c.exposure) <= 10 &&
        std::isfinite(c.contrast) && c.contrast >= 0 && c.contrast <= 4 &&
        std::isfinite(c.pivot) && c.pivot >= 0.001 && c.pivot <= 1 &&
        std::isfinite(c.gamma) && c.gamma >= 0.1 && c.gamma <= 4 &&
        std::isfinite(c.temperature) && std::abs(c.temperature) <= 1 &&
        std::isfinite(c.tint) && std::abs(c.tint) <= 1 &&
        std::isfinite(c.saturation) && c.saturation >= 0 && c.saturation <= 3 &&
        std::isfinite(c.black) && c.black >= -1 && c.black <= 0.99 &&
        std::isfinite(c.white) && c.white >= 0.01 && c.white <= 16 &&
        c.white - c.black >= 0.0001 &&
        std::isfinite(c.mix) && c.mix >= 0 && c.mix <= 1 &&
        std::isfinite(c.lookStrength) && c.lookStrength >= 0 && c.lookStrength <= 1 &&
        static_cast<int>(c.look) >= 0 && static_cast<std::size_t>(c.look) < kLookCount;
}
inline bool identity(const Controls& c) {
    return c.mix == 0 || ((c.look == Look::Neutral || c.lookStrength == 0) && c.exposure == 0 &&
        c.contrast == 1 && c.gamma == 1 && c.temperature == 0 &&
        c.tint == 0 && c.saturation == 1 && c.black == 0 && c.white == 1);
}

class Grade {
    Controls c_;
    struct Recipe {
        RGB gains{}, shadows{}, highlights{};
        double exposure = 1, contrast = 1, saturation = 1, lift = 0, shoulder = 0;
        bool advanced = false;
    };
    Recipe base_, styled_;
    Recipe recipe(const LookDefinition& look) const {
        Recipe result;
        const double temp = c_.temperature + look.temperature, tint = c_.tint + look.tint;
        result.exposure = std::exp2(c_.exposure + look.exposure);
        result.contrast = c_.contrast * look.contrast;
        result.saturation = c_.saturation * look.saturation;
        // Artistic channel gains, not a calibrated Kelvin or chromatic-adaptation model.
        result.gains = {std::exp2(temp * 0.35 + tint * 0.12),
                  std::exp2(-tint * 0.24), std::exp2(-temp * 0.35 + tint * 0.12)};
        result.shadows = look.shadows; result.highlights = look.highlights;
        result.lift = look.lift; result.shoulder = look.shoulder;
        result.advanced = look.lift != 0 || look.shoulder != 0 ||
            std::any_of(look.shadows.begin(), look.shadows.end(), [](double v) { return v != 0; }) ||
            std::any_of(look.highlights.begin(), look.highlights.end(), [](double v) { return v != 0; });
        return result;
    }
    static double smooth(double low, double high, double value) {
        const double t = std::clamp((value - low) / (high - low), 0.0, 1.0);
        return t * t * (3 - 2 * t);
    }
    RGB process(RGB input, const Recipe& recipe) const {
        RGB v{};
        for (int i = 0; i < 3; ++i) {
            double x = (input[i] - c_.black) / (c_.white - c_.black);
            x = x * recipe.exposure * recipe.gains[i];
            x = (x - c_.pivot) * recipe.contrast + c_.pivot;
            // Signed power retains negative/out-of-gamut values and does not clip HDR.
            if (c_.gamma != 1) x = std::copysign(std::pow(std::abs(x), 1.0 / c_.gamma), x);
            v[i] = x;
        }
        if (recipe.advanced) {
            const double zoneLuma = 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
            const double shadow = (1 - smooth(0.05, 0.70, zoneLuma)) * std::max(0.0, zoneLuma);
            const double highlight = smooth(0.25, 1.10, zoneLuma) * std::max(0.0, zoneLuma);
            for (int i = 0; i < 3; ++i) {
                v[i] += recipe.shadows[i] * shadow + recipe.highlights[i] * highlight;
                if (recipe.shoulder > 0 && v[i] > c_.pivot) {
                    const double delta = v[i] - c_.pivot;
                    v[i] = c_.pivot + delta / (1 + recipe.shoulder * delta);
                }
                if (recipe.lift > 0) v[i] = v[i] * (1 - recipe.lift) + recipe.lift;
            }
        }
        const double luma = 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
        for (int i = 0; i < 3; ++i) v[i] = luma + recipe.saturation * (v[i] - luma);
        return v;
    }
public:
    explicit Grade(Controls c) : c_(c), base_(recipe(kLooks[0])), styled_(recipe(kLooks.at(static_cast<std::size_t>(c.look)))) {}
    bool isIdentity() const { return identity(c_); }
    RGB apply(RGB input) const {
        if (isIdentity()) return input;
        RGB v = process(input, c_.lookStrength == 0 ? base_ : styled_);
        if (c_.look != Look::Neutral && c_.lookStrength > 0 && c_.lookStrength < 1) {
            const RGB manual = process(input, base_);
            for (int i = 0; i < 3; ++i) v[i] = manual[i] + c_.lookStrength * (v[i] - manual[i]);
        }
        for (int i = 0; i < 3; ++i) {
            v[i] = input[i] + c_.mix * (v[i] - input[i]);
        }
        return v;
    }
    void pixel(const float* src, float* dst, bool premultiplied) const {
        processPixel(*this, src, dst, premultiplied);
    }
};
} // namespace mendes
