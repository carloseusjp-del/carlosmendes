#pragma once
#include "cube.hpp"
#include "advanced.hpp"

namespace mendes {
class Pipeline {
    std::shared_ptr<const Cube3D> cube_;
    LutEncoding encoding_;
    Grade grade_;
    double mix_;
    std::shared_ptr<const Advanced> advanced_;
    static Controls fullGrade(Controls controls) { controls.mix = 1; return controls; }
public:
    Pipeline(Controls controls, std::shared_ptr<const Cube3D> cube = {}, LutEncoding encoding = LutEncoding::Preserve,
             std::shared_ptr<const Advanced> advanced={})
        : cube_(std::move(cube)), encoding_(encoding), grade_(fullGrade(controls)), mix_(controls.mix),advanced_(std::move(advanced)) {}
    bool isIdentity() const { return mix_ == 0 || (!cube_ && grade_.isIdentity() && (!advanced_||advanced_->identity())); }
    double mix() const { return mix_; }
    const Advanced* advanced() const {return advanced_.get();}
    RGB postGrade(RGB input) const {
        RGB converted = cube_ ? cube_->sample(input) : advanced_?advanced_->input(input):input;
        if (cube_ && encoding_ == LutEncoding::Rec709OETFToGamma24)
            for (double& value : converted) value = rec709ToGamma24(value);
        converted=grade_.apply(converted);
        return advanced_?advanced_->color(converted):converted;
    }
    RGB finish(RGB input,RGB processed) const {
        if(mix_==0)return input;
        if(advanced_)processed=advanced_->output(processed);
        if(mix_!=1)for(int c=0;c<3;++c)processed[c]=input[c]+mix_*(processed[c]-input[c]);
        return processed;
    }
    RGB apply(RGB input, RGB addition) const {
        if (mix_ == 0) return input;
        RGB result = postGrade(input);
        for (int i = 0; i < 3; ++i) result[i] += addition[i];
        return finish(input,result);
    }
    RGB apply(RGB input) const {
        if (isIdentity()) return input;
        return apply(input, {});
    }
    void pixel(const float* src, float* dst, bool premultiplied) const { processPixel(*this, src, dst, premultiplied); }
};
} // namespace mendes
