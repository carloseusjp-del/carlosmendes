#pragma once
#include "version.hpp"

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <cstdio>
#include <string>
#endif

namespace mendes {
// Only registration/lifecycle and descriptor failures are logged, never image
// pixels, paths from the project, parameter values or the ambient environment.
inline void diagnostic(const char* stage, int status, const char* detail = "") noexcept {
#ifdef _WIN32
    try {
        wchar_t base[MAX_PATH]{};
        const DWORD size = GetEnvironmentVariableW(L"LOCALAPPDATA", base, MAX_PATH);
        if (!size || size >= MAX_PATH) return;
        const std::wstring directory = std::wstring(base) + L"\\MendesColor";
        CreateDirectoryW(directory.c_str(), nullptr);
        const std::wstring path = directory + L"\\OpenFX.log";
        char line[1024]{};
        std::snprintf(line, sizeof(line), "Mendes Color " MENDES_COLOR_VERSION " | %.200s | status=%d | %.500s\r\n", stage, status, detail);
        HANDLE file = CreateFileW(path.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                  nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (file == INVALID_HANDLE_VALUE) return;
        DWORD written = 0;
        WriteFile(file, line, static_cast<DWORD>(std::char_traits<char>::length(line)), &written, nullptr);
        CloseHandle(file);
    } catch (...) { /* Diagnostics must never change the host action result. */ }
#else
    (void)stage; (void)status; (void)detail;
#endif
}
} // namespace mendes
