#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <shlobj.h>
#include <tlhelp32.h>
#include <array>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <sstream>
#include <vector>
#include "version.hpp"
#include "transaction.hpp"
#include "setup_payloads.hpp"

namespace {
constexpr const wchar_t* title = L"Mendes Color — Instalador";
void checkHashStatus(NTSTATUS status) {
    if (status < 0) throw std::runtime_error("Windows SHA-256 verification failed.");
}
std::string sha256(const unsigned char* data, std::size_t size) {
    if (size > std::numeric_limits<ULONG>::max()) throw std::runtime_error("Payload too large.");
    struct Hash {
        BCRYPT_ALG_HANDLE algorithm = nullptr;
        BCRYPT_HASH_HANDLE hash = nullptr;
        ~Hash() { if (hash) BCryptDestroyHash(hash); if (algorithm) BCryptCloseAlgorithmProvider(algorithm, 0); }
    } owner;
    checkHashStatus(BCryptOpenAlgorithmProvider(&owner.algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0));
    checkHashStatus(BCryptCreateHash(owner.algorithm, &owner.hash, nullptr, 0, nullptr, 0, 0));
    checkHashStatus(BCryptHashData(owner.hash, const_cast<PUCHAR>(data), static_cast<ULONG>(size), 0));
    std::array<unsigned char, 32> digest{};
    checkHashStatus(BCryptFinishHash(owner.hash, digest.data(), static_cast<ULONG>(digest.size()), 0));
    std::ostringstream text; text << std::hex << std::setfill('0');
    for (auto value : digest) text << std::setw(2) << static_cast<unsigned>(value);
    return text.str();
}
std::filesystem::path commonFiles() {
    PWSTR value = nullptr;
    const HRESULT status = SHGetKnownFolderPath(FOLDERID_ProgramFilesCommon, 0, nullptr, &value);
    if (FAILED(status) || !value) throw std::runtime_error("Cannot locate the Windows Common Files directory.");
    const std::filesystem::path result(value);
    CoTaskMemFree(value);
    return result;
}
bool resolveRunning() {
    const HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) throw std::runtime_error("Cannot inspect running processes. Close Resolve and try again.");
    PROCESSENTRY32W entry{}; entry.dwSize = sizeof(entry);
    BOOL found = Process32FirstW(snapshot, &entry);
    if (!found) { CloseHandle(snapshot); throw std::runtime_error("Cannot inspect running processes."); }
    bool running = false;
    do {
        if (_wcsicmp(entry.szExeFile, L"Resolve.exe") == 0) { running = true; break; }
    } while (Process32NextW(snapshot, &entry));
    CloseHandle(snapshot);
    return running;
}
std::string identifier() {
    GUID id{};
    if (FAILED(CoCreateGuid(&id))) throw std::runtime_error("Cannot create installer staging identifier.");
    wchar_t wide[40]{};
    if (!StringFromGUID2(id, wide, 40)) throw std::runtime_error("Cannot format installer staging identifier.");
    std::string value;
    for (wchar_t c : wide) if ((c >= L'0' && c <= L'9') || (c >= L'A' && c <= L'F') || (c >= L'a' && c <= L'f') || c == L'-')
        value.push_back(static_cast<char>(c));
    return value;
}
void writePayloads(HINSTANCE module, const std::filesystem::path& root) {
    for (const auto& file : mendes_setup::payloads) {
        HRSRC resource = FindResourceW(module, MAKEINTRESOURCEW(file.id), MAKEINTRESOURCEW(10));
        if (!resource) throw std::runtime_error("An installer resource is missing.");
        const DWORD bytes = SizeofResource(module, resource);
        HGLOBAL loaded = LoadResource(module, resource);
        if (!loaded) throw std::runtime_error("An installer resource could not be loaded.");
        const auto data = static_cast<const unsigned char*>(LockResource(loaded));
        if (!data || bytes != file.bytes || sha256(data, bytes) != file.sha256)
            throw std::runtime_error("Installer payload checksum mismatch. Download the installer again.");
        const auto target = root / file.path;
        std::filesystem::create_directories(target.parent_path());
        std::ofstream out(target, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(data), bytes); out.close();
        if (!out) throw std::runtime_error("Cannot write plugin files. Check disk space and permissions.");
        std::ifstream in(target, std::ios::binary);
        const std::vector<unsigned char> written{std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
        if (in.bad() || written.size() != bytes || sha256(written.data(), written.size()) != file.sha256)
            throw std::runtime_error("Written plugin checksum mismatch. Previous version was not replaced.");
    }
}
std::wstring wideError(const std::exception& e) {
    const std::string text(e.what());
    const int length = MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), nullptr, 0);
    std::wstring result(length > 0 ? length : 0, L' ');
    if (length > 0) MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), result.data(), length);
    return result;
}
}
int WINAPI wWinMain(HINSTANCE module, HINSTANCE, PWSTR, int) {
    std::filesystem::path backups;
    try {
        if (!IsUserAnAdmin()) {
            MessageBoxW(nullptr, L"Abra este instalador como administrador para instalar o plugin no Resolve.", title, MB_OK | MB_ICONERROR);
            return 1;
        }
        while (resolveRunning()) {
            if (MessageBoxW(nullptr, L"Feche o DaVinci Resolve para atualizar o plugin. Seus projetos não serão encerrados pelo instalador.\n\nDepois clique em Repetir.", title, MB_RETRYCANCEL | MB_ICONINFORMATION) != IDRETRY) return 0;
        }
        const auto common = commonFiles();
        const auto plugins = common / L"OFX" / L"Plugins";
        backups = common / L"MendesColor" / L"Backups";
#define WIDE_LITERAL_INNER(value) L##value
#define WIDE_LITERAL(value) WIDE_LITERAL_INNER(value)
        const std::wstring question = L"Instalar ou atualizar Mendes Color " WIDE_LITERAL(MENDES_COLOR_VERSION) L"?\n\n"
            L"Inclui Halation, botões Anterior/Próximo, 19 looks e a LUT Avata 2.\n\nDestino:\n" +
            (plugins / L"MendesColor.ofx.bundle").wstring() + L"\n\nA versão anterior será preservada em:\n" + backups.wstring();
        if (MessageBoxW(nullptr, question.c_str(), title, MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) != IDYES) return 0;
        const auto result = mendes_setup::install(plugins, backups, identifier(),
            [&](const std::filesystem::path& stage) { writePayloads(module, stage); });
        std::wstring done = L"Mendes Color instalado com sucesso.\n\nAbra o Resolve e procure Mendes Color em Effects / Open FX.\n"
            L"Escolha a LUT Avata 2 em Input LUT e os estilos em Creative Look.\n";
        if (!result.backup.empty()) done += L"\nBackup anterior:\n" + result.backup.wstring();
        MessageBoxW(nullptr, done.c_str(), title, MB_OK | MB_ICONINFORMATION);
        return 0;
    } catch (const std::exception& e) {
        const std::wstring error = L"A instalação não foi concluída.\n\n" + wideError(e) +
            (backups.empty() ? L"" : L"\n\nPasta de backups:\n" + backups.wstring());
        MessageBoxW(nullptr, error.c_str(), title, MB_OK | MB_ICONERROR);
        return 1;
    }
}
