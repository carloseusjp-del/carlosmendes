#pragma once
#define MENDES_COLOR_VERSION "1.3.0"
namespace mendes {
inline constexpr unsigned kOfxVersionMajor = 1;
inline constexpr unsigned kOfxVersionMinor = 300;
}
