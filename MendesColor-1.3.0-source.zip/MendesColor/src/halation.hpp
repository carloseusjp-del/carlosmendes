#pragma once
#include "color.hpp"
#include <limits>
#include <stdexcept>
#include <vector>

namespace mendes {
enum class HalationPreset { Off, Minimum, Medium, High };
inline constexpr const char* kHalationNames[] = {"Desligado", "M\xc3\xadnimo", "M\xc3\xa9" "dio", "Alto"};
struct HalationPlan {
    int radiusX = 0, radiusY = 0;
    double amount = 0;
    bool enabled() const { return amount > 0; }
    int supportX() const { return 3 * radiusX; }
    int supportY() const { return 3 * radiusY; }
};
// Sizes are referenced to a 1080-line frame, in canonical coordinates. Three
// separable box passes approximate a Gaussian with finite, explicit support.
inline HalationPlan halationPlan(HalationPreset preset, double frameHeight, double scaleX = 1,
                                 double scaleY = 1, double pixelAspect = 1) {
    const int index = static_cast<int>(preset);
    if (index < 0 || index > 3 || !std::isfinite(frameHeight) || frameHeight <= 0 ||
        !std::isfinite(scaleX) || scaleX <= 0 || !std::isfinite(scaleY) || scaleY <= 0 ||
        !std::isfinite(pixelAspect) || pixelAspect <= 0) throw std::invalid_argument("Invalid halation geometry/preset");
    if (!index) return {};
    constexpr double radii[] = {0, 3, 5, 8};
    constexpr double amounts[] = {0, 0.16, 0.30, 0.48};
    auto radius = [](double value) { return static_cast<int>(std::round(std::clamp(value, 1.0, 128.0))); };
    const double size = radii[index] * frameHeight / 1080;
    return {radius(size * scaleX / pixelAspect), radius(size * scaleY), amounts[index]};
}
struct RectI {
    int x1, y1, x2, y2;
    bool empty() const { return x2 <= x1 || y2 <= y1; }
};
inline RectI expand(RectI r, int x, int y) {
    auto add = [](int a, int b) {
        return static_cast<int>(std::clamp(static_cast<long long>(a) + b,
            static_cast<long long>(std::numeric_limits<int>::min()), static_cast<long long>(std::numeric_limits<int>::max())));
    };
    return {add(r.x1, -x), add(r.y1, -y), add(r.x2, x), add(r.y2, y)};
}
inline RectI intersect(RectI a, RectI b) {
    return {std::max(a.x1, b.x1), std::max(a.y1, b.y1), std::min(a.x2, b.x2), std::min(a.y2, b.y2)};
}
// Emission comes from the post-LUT, post-look display RGB. This is an artistic
// highlight halo, not a scene-linear or measured film-stock light transport.
inline double halationEmission(RGB graded, double alpha) {
    if (!std::isfinite(alpha) || alpha <= 0 ||
        !std::all_of(graded.begin(), graded.end(), [](double v) { return std::isfinite(v); })) return 0;
    const double luma = 0.2126 * graded[0] + 0.7152 * graded[1] + 0.0722 * graded[2];
    const double t = std::clamp((luma - 0.65) / 0.30, 0.0, 1.0);
    return t * t * (3 - 2 * t) * std::clamp(luma, 0.0, 4.0) * std::min(alpha, 1.0);
}
inline RGB halationColor(double blurredEmission, double localEmission, const HalationPlan& plan) {
    const double halo = std::max(0.0, blurredEmission - localEmission) * plan.amount;
    return {halo, halo * 0.23, halo * 0.04};
}

class HaloBuffer {
    RectI bounds_{};
    std::size_t width_ = 0, height_ = 0;
    std::vector<float> data_;
public:
    // sample returns alpha-weighted emission; unavailable pixels are zero. A
    // false return means the host cancelled. Buffers are local to one render.
    template<class Sample, class Abort>
    bool build(RectI output, RectI source, const HalationPlan& plan, Sample sample, Abort abort) {
        bounds_ = intersect(expand(output, plan.supportX(), plan.supportY()), source);
        data_.clear(); width_ = height_ = 0;
        if (bounds_.empty() || output.empty() || !plan.enabled()) return true;
        width_ = static_cast<std::size_t>(static_cast<long long>(bounds_.x2) - bounds_.x1);
        height_ = static_cast<std::size_t>(static_cast<long long>(bounds_.y2) - bounds_.y1);
        if (height_ > data_.max_size() / width_) throw std::bad_alloc();
        data_.resize(width_ * height_);
        std::vector<float> scratch(data_.size());
        std::vector<double> sums(width_);
        for (std::size_t y = 0; y < height_; ++y) {
            if (abort()) return false;
            for (std::size_t x = 0; x < width_; ++x)
                data_[y * width_ + x] = static_cast<float>(sample(
                    static_cast<int>(static_cast<long long>(bounds_.x1) + static_cast<long long>(x)),
                    static_cast<int>(static_cast<long long>(bounds_.y1) + static_cast<long long>(y))));
        }
        const auto rx = static_cast<std::size_t>(plan.radiusX), ry = static_cast<std::size_t>(plan.radiusY);
        const double normX = 1.0 / (2 * plan.radiusX + 1), normY = 1.0 / (2 * plan.radiusY + 1);
        for (int pass = 0; pass < 3; ++pass) {
            for (std::size_t y = 0; y < height_; ++y) {
                if (abort()) return false;
                const auto row = y * width_;
                double sum = 0;
                for (std::size_t x = 0; x <= rx && x < width_; ++x) sum += data_[row + x];
                for (std::size_t x = 0; x < width_; ++x) {
                    scratch[row + x] = static_cast<float>(sum * normX);
                    if (x >= rx) sum -= data_[row + x - rx];
                    if (x + rx + 1 < width_) sum += data_[row + x + rx + 1];
                }
            }
            std::fill(sums.begin(), sums.end(), 0);
            for (std::size_t y = 0; y <= ry && y < height_; ++y)
                for (std::size_t x = 0; x < width_; ++x) sums[x] += scratch[y * width_ + x];
            for (std::size_t y = 0; y < height_; ++y) {
                if (abort()) return false;
                for (std::size_t x = 0; x < width_; ++x) {
                    data_[y * width_ + x] = static_cast<float>(std::max(0.0, sums[x] * normY));
                    if (y >= ry) sums[x] -= scratch[(y - ry) * width_ + x];
                    if (y + ry + 1 < height_) sums[x] += scratch[(y + ry + 1) * width_ + x];
                }
            }
        }
        return true;
    }
    double at(int x, int y) const {
        if (data_.empty() || x < bounds_.x1 || x >= bounds_.x2 || y < bounds_.y1 || y >= bounds_.y2) return 0;
        return data_[static_cast<std::size_t>(static_cast<long long>(y) - bounds_.y1) * width_ +
            static_cast<std::size_t>(static_cast<long long>(x) - bounds_.x1)];
    }
};
} // namespace mendes
