#include "ofxImageEffect.h"
#include <algorithm>
#include <array>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <iostream>
#include <map>
#include <memory>
#include <string>
#include <vector>

struct OfxPropertySetStruct {
    std::map<std::string, OfxStatus> stringFailures;
    std::map<std::string, std::vector<int>> ints;
    std::map<std::string, std::vector<double>> doubles;
    std::map<std::string, std::vector<std::string>> strings;
    std::map<std::string, std::vector<void*>> pointers;
};
struct OfxParamStruct {
    std::string type; OfxPropertySetStruct props; double value = 0;
    bool animated = false, initialized = false;
    std::string stringValue;
    std::map<double, int> choiceKeys;
    OfxStatus writeStatus = kOfxStatOK;
};
struct OfxParamSetStruct { std::map<std::string, std::unique_ptr<OfxParamStruct>> values; };
struct OfxImageClipStruct {
    OfxPropertySetStruct props, image;
    bool fail = false;
    OfxRectD rod{-2, 3, 2, 6};
    std::vector<double> requestedRegion;
};
struct OfxImageEffectStruct {
    OfxPropertySetStruct props;
    OfxParamSetStruct params;
    std::map<std::string, std::unique_ptr<OfxImageClipStruct>> clips;
    bool abort = false;
    std::string lastError;
};
namespace mock {
int checks = 0, acquired = 0, released = 0;
int editBegins = 0, editEnds = 0;
double sampledTime = -1;
void require(bool ok, const char* text) {
    ++checks; if (!ok) { std::cerr << "FAIL: " << text << '\n'; std::exit(1); }
}
template<class T> OfxStatus set(std::map<std::string, std::vector<T>>& m, const char* k, int n, T v) {
    if (n < 0) return kOfxStatErrBadIndex;
    auto& a = m[k]; if (a.size() <= static_cast<std::size_t>(n)) a.resize(n + 1);
    a[n] = v; return kOfxStatOK;
}
template<class T> OfxStatus get(std::map<std::string, std::vector<T>>& m, const char* k, int n, T* v) {
    auto a = m.find(k);
    if (a == m.end() || n < 0 || static_cast<std::size_t>(n) >= a->second.size()) return kOfxStatErrUnknown;
    *v = a->second[n]; return kOfxStatOK;
}
OfxStatus setInt(OfxPropertySetHandle p, const char* k, int n, int v) { return set(p->ints, k, n, v); }
OfxStatus setDouble(OfxPropertySetHandle p, const char* k, int n, double v) { return set(p->doubles, k, n, v); }
OfxStatus setString(OfxPropertySetHandle p, const char* k, int n, const char* v) {
    const auto failure = p->stringFailures.find(k);
    if (failure != p->stringFailures.end()) return failure->second;
    return set(p->strings, k, n, std::string(v));
}
OfxStatus setPointer(OfxPropertySetHandle p, const char* k, int n, void* v) { return set(p->pointers, k, n, v); }
OfxStatus getInt(OfxPropertySetHandle p, const char* k, int n, int* v) { return get(p->ints, k, n, v); }
OfxStatus getDouble(OfxPropertySetHandle p, const char* k, int n, double* v) { return get(p->doubles, k, n, v); }
OfxStatus getPointer(OfxPropertySetHandle p, const char* k, int n, void** v) { return get(p->pointers, k, n, v); }
OfxStatus getString(OfxPropertySetHandle p, const char* k, int n, char** v) {
    auto a = p->strings.find(k); if (a == p->strings.end() || n < 0 || static_cast<std::size_t>(n) >= a->second.size()) return kOfxStatErrUnknown;
    *v = a->second[n].data(); return kOfxStatOK;
}
OfxStatus getIntN(OfxPropertySetHandle p, const char* k, int n, int* v) {
    for (int i = 0; i < n; ++i) { auto s = getInt(p, k, i, v + i); if (s) return s; } return kOfxStatOK;
}
OfxStatus setDoubleN(OfxPropertySetHandle p, const char* k, int n, const double* v) {
    for (int i = 0; i < n; ++i) setDouble(p, k, i, v[i]);
    return kOfxStatOK;
}
OfxStatus effectProps(OfxImageEffectHandle e, OfxPropertySetHandle* p) { *p = &e->props; return kOfxStatOK; }
OfxStatus paramSet(OfxImageEffectHandle e, OfxParamSetHandle* p) { *p = &e->params; return kOfxStatOK; }
OfxStatus clipDefine(OfxImageEffectHandle e, const char* name, OfxPropertySetHandle* p) {
    auto c = std::make_unique<OfxImageClipStruct>(); *p = &c->props; e->clips[name] = std::move(c); return kOfxStatOK;
}
OfxStatus clipHandle(OfxImageEffectHandle e, const char* name, OfxImageClipHandle* c, OfxPropertySetHandle* p) {
    if (!e->clips.count(name)) return kOfxStatErrUnknown;
    *c = e->clips[name].get(); if (p) *p = &(*c)->props; return kOfxStatOK;
}
OfxStatus clipProps(OfxImageClipHandle c, OfxPropertySetHandle* p) { *p = &c->props; return kOfxStatOK; }
OfxStatus image(OfxImageClipHandle c, OfxTime, const OfxRectD* region, OfxPropertySetHandle* p) {
    if (c->fail) return kOfxStatFailed;
    c->requestedRegion = region ? std::vector<double>{region->x1, region->y1, region->x2, region->y2} : std::vector<double>{};
    *p = &c->image; ++acquired; return kOfxStatOK;
}
OfxStatus release(OfxPropertySetHandle) { ++released; return kOfxStatOK; }
int abort(OfxImageEffectHandle e) { return e->abort ? 1 : 0; }
OfxStatus rod(OfxImageClipHandle c, OfxTime, OfxRectD* r) { *r = c->rod; return kOfxStatOK; }
OfxStatus defineParam(OfxParamSetHandle s, const char* type, const char* name, OfxPropertySetHandle* p) {
    auto a = std::make_unique<OfxParamStruct>(); a->type = type; *p = &a->props; s->values[name] = std::move(a); return kOfxStatOK;
}
OfxStatus paramHandle(OfxParamSetHandle s, const char* name, OfxParamHandle* p, OfxPropertySetHandle* props) {
    if (!s->values.count(name)) return kOfxStatErrUnknown;
    *p = s->values[name].get();
    if (!(*p)->initialized) {
        if ((*p)->type == kOfxParamTypeDouble) (*p)->value = (*p)->props.doubles[kOfxParamPropDefault][0];
        else if ((*p)->type == kOfxParamTypeString) (*p)->stringValue = (*p)->props.strings[kOfxParamPropDefault][0];
        else (*p)->value = (*p)->props.ints[kOfxParamPropDefault][0];
        (*p)->initialized = true;
    }
    if (props) *props = &(*p)->props;
    return kOfxStatOK;
}
OfxStatus valueAt(OfxParamHandle p, OfxTime time, ...) {
    va_list args; va_start(args, time);
    if (p->type == kOfxParamTypeChoice) {
        auto key = p->choiceKeys.upper_bound(time);
        const int value = p->choiceKeys.empty() ? static_cast<int>(p->value) :
            (key == p->choiceKeys.begin() ? key->second : std::prev(key)->second);
        *va_arg(args, int*) = value;
    }
    else if (p->type == kOfxParamTypeString) *va_arg(args, char**) = p->stringValue.data();
    else *va_arg(args, double*) = p->value + (p->animated ? time : 0);
    va_end(args); sampledTime = time; return kOfxStatOK;
}
OfxStatus writeValue(OfxParamHandle p, ...) {
    if (p->writeStatus != kOfxStatOK) return p->writeStatus;
    va_list args; va_start(args, p); p->value = va_arg(args, int); va_end(args);
    return kOfxStatOK;
}
OfxStatus writeAt(OfxParamHandle p, double time, ...) {
    if (p->writeStatus != kOfxStatOK) return p->writeStatus;
    va_list args; va_start(args, time); p->choiceKeys[time] = va_arg(args, int); va_end(args);
    return kOfxStatOK;
}
OfxStatus keyCount(OfxParamHandle p, unsigned* count) { *count = static_cast<unsigned>(p->choiceKeys.size()); return kOfxStatOK; }
OfxStatus editBegin(OfxParamSetHandle, const char*) { ++editBegins; return kOfxStatOK; }
OfxStatus editEnd(OfxParamSetHandle) { ++editEnds; return kOfxStatOK; }
OfxPropertySuiteV1 properties{};
OfxImageEffectSuiteV1 images{};
OfxParameterSuiteV1 parameters{};
OfxMessageSuiteV2 messages{};
OfxStatus persistentMessage(void* handle, const char*, const char*, const char* format, ...) {
    char text[1024]{};
    va_list args; va_start(args, format);
    std::vsnprintf(text, sizeof(text), format, args);
    va_end(args);
    static_cast<OfxImageEffectHandle>(handle)->lastError = text;
    return kOfxStatOK;
}
OfxStatus clearMessage(void* handle) {
    static_cast<OfxImageEffectHandle>(handle)->lastError.clear(); return kOfxStatOK;
}
const void* fetch(OfxPropertySetHandle, const char* name, int version) {
    if (version == 2 && std::strcmp(name, kOfxMessageSuite) == 0) return &messages;
    if (version != 1) return nullptr;
    if (std::strcmp(name, kOfxPropertySuite) == 0) return &properties;
    if (std::strcmp(name, kOfxImageEffectSuite) == 0) return &images;
    if (std::strcmp(name, kOfxParameterSuite) == 0) return &parameters;
    return nullptr;
}
void init() {
    messages.setPersistentMessage = persistentMessage; messages.clearPersistentMessage = clearMessage;
    properties.propSetInt = setInt; properties.propSetDouble = setDouble;
    properties.propSetString = setString; properties.propSetPointer = setPointer;
    properties.propGetInt = getInt; properties.propGetDouble = getDouble;
    properties.propGetString = getString; properties.propGetPointer = getPointer;
    properties.propGetIntN = getIntN; properties.propSetDoubleN = setDoubleN;
    images.getPropertySet = effectProps; images.getParamSet = paramSet; images.clipDefine = clipDefine;
    images.clipGetHandle = clipHandle; images.clipGetPropertySet = clipProps;
    images.clipGetImage = image; images.clipReleaseImage = release; images.abort = abort;
    images.clipGetRegionOfDefinition = rod;
    parameters.paramDefine = defineParam; parameters.paramGetHandle = paramHandle; parameters.paramGetValueAtTime = valueAt;
    parameters.paramSetValue = writeValue; parameters.paramSetValueAtTime = writeAt; parameters.paramGetNumKeys = keyCount;
    parameters.paramEditBegin = editBegin; parameters.paramEditEnd = editEnd;
}
void setupImage(OfxImageClipStruct* c, float* data, bool premult, int stride) {
    auto p = &c->image;
    setPointer(p, kOfxImagePropData, 0, data);
    setString(p, kOfxImageEffectPropPixelDepth, 0, kOfxBitDepthFloat);
    setString(p, kOfxImageEffectPropComponents, 0, kOfxImageComponentRGBA);
    auto mode = premult ? kOfxImagePreMultiplied : kOfxImageUnPreMultiplied;
    setString(p, kOfxImageEffectPropPreMultiplication, 0, mode);
    setString(&c->props, kOfxImageEffectPropPreMultiplication, 0, mode);
    setDouble(&c->props, kOfxImagePropPixelAspectRatio, 0, 1);
    int bounds[] = {-2, 3, 2, 6};
    for (int n = 0; n < 4; ++n) setInt(p, kOfxImagePropBounds, n, bounds[n]);
    setInt(p, kOfxImagePropRowBytes, 0, stride);
}
} // namespace mock

int main(int argc, char** argv) {
    using namespace mock;
    require(argc == 2, "shared plugin path supplied");
    void* library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!library) { std::cerr << dlerror() << '\n'; return 1; }
    auto getCount = reinterpret_cast<int (*)()>(dlsym(library, "OfxGetNumberOfPlugins"));
    auto getPlugin = reinterpret_cast<OfxPlugin* (*)(int)>(dlsym(library, "OfxGetPlugin"));
    require(getCount && getPlugin && getCount() == 1, "exports and plugin count");
    require(!getPlugin(-1) && !getPlugin(1), "out-of-range plugin index");
    auto plugin = getPlugin(0); init();
    require(plugin->pluginVersionMajor == 1 && plugin->pluginVersionMinor == 300, "updated OpenFX version identifies the replacement build");
    OfxHost host{nullptr, fetch}; plugin->setHost(&host);
    auto call = plugin->mainEntry;
    require(call(kOfxActionLoad, nullptr, nullptr, nullptr) == kOfxStatOK, "load obtains host suites");
    for (OfxStatus status : {kOfxStatErrUnknown, kOfxStatErrUnsupported}) {
        OfxImageEffectStruct withoutDescription;
        withoutDescription.props.stringFailures[kOfxPropPluginDescription] = status;
        require(call(kOfxActionDescribe, &withoutDescription, nullptr, nullptr) == kOfxStatOK, "host rejecting optional plugin description still completes discovery");
        require(withoutDescription.props.strings[kOfxImageEffectPropSupportedContexts].size() == 2, "rejected description does not stop context registration");
        OfxPropertySetStruct contextIn;
        setString(&contextIn, kOfxImageEffectPropContext, 0, kOfxImageEffectContextGeneral);
        require(call(kOfxImageEffectActionDescribeInContext, &withoutDescription, &contextIn, nullptr) == kOfxStatOK, "host without description can describe controls");
        require(call(kOfxActionCreateInstance, &withoutDescription, nullptr, nullptr) == kOfxStatOK, "host without description can create an instance");
        require(call(kOfxActionDestroyInstance, &withoutDescription, nullptr, nullptr) == kOfxStatOK, "host without description can destroy its instance");
    }
    OfxImageEffectStruct descriptionMemoryFailure;
    descriptionMemoryFailure.props.stringFailures[kOfxPropPluginDescription] = kOfxStatErrMemory;
    require(call(kOfxActionDescribe, &descriptionMemoryFailure, nullptr, nullptr) == kOfxStatErrMemory, "real descriptor failure remains fatal even for optional metadata");
    OfxImageEffectStruct requiredFailure;
    requiredFailure.props.stringFailures[kOfxImageEffectPropSupportedContexts] = kOfxStatErrUnknown;
    require(call(kOfxActionDescribe, &requiredFailure, nullptr, nullptr) == kOfxStatErrUnknown, "missing required context property is not silently ignored");
    OfxImageEffectStruct effect;
    require(call(kOfxActionDescribe, &effect, nullptr, nullptr) == kOfxStatOK, "describe plugin");
    const auto contexts = effect.props.strings[kOfxImageEffectPropSupportedContexts];
    require(std::find(contexts.begin(), contexts.end(), kOfxImageEffectContextGeneral) != contexts.end(), "advertise General context for hosts that select it");
    require(std::find(contexts.begin(), contexts.end(), kOfxImageEffectContextFilter) != contexts.end(), "retain Filter context");
    OfxImageEffectStruct generalEffect;
    OfxPropertySetStruct generalIn;
    setString(&generalIn, kOfxImageEffectPropContext, 0, kOfxImageEffectContextGeneral);
    require(call(kOfxImageEffectActionDescribeInContext, &generalEffect, &generalIn, nullptr) == kOfxStatOK, "describe in General context");
    require(call(kOfxActionCreateInstance, &generalEffect, nullptr, nullptr) == kOfxStatOK, "create General instance");
    require(call(kOfxActionDestroyInstance, &generalEffect, nullptr, nullptr) == kOfxStatOK, "destroy General instance");
    OfxImageEffectStruct unsupportedEffect;
    OfxPropertySetStruct unsupportedIn;
    setString(&unsupportedIn, kOfxImageEffectPropContext, 0, kOfxImageEffectContextGenerator);
    require(call(kOfxImageEffectActionDescribeInContext, &unsupportedEffect, &unsupportedIn, nullptr) == kOfxStatErrUnsupported, "unsupported contexts remain rejected");
    OfxPropertySetStruct in, out;
    setString(&in, kOfxImageEffectPropContext, 0, kOfxImageEffectContextFilter);
    require(call(kOfxImageEffectActionDescribeInContext, &effect, &in, nullptr) == kOfxStatOK, "describe filter and controls");
    require(effect.params.values.size() == 27, "color controls, halation, pages/group and eight navigation buttons");
    const auto& lookOptions = effect.params.values["look"]->props.strings[kOfxParamPropChoiceOption];
    require(lookOptions.size() == 19 && lookOptions[5] == "Earth" && lookOptions[18] == "Commercial Teal", "expanded look menu preserves original IDs and adds the requested commercial style");
    const auto& haloOptions = effect.params.values["halationPreset"]->props.strings[kOfxParamPropChoiceOption];
    require(haloOptions == std::vector<std::string>({"Desligado", "Mínimo", "Médio", "Alto"}), "halation offers off and three Portuguese presets");
    require(effect.params.values["Halation"]->props.strings[kOfxParamPropPageChild][0] == "halationPreset", "halation has a dedicated page");
    require(effect.params.values["halationPreset"]->props.strings[kOfxParamPropParent][0] == "halationGroup", "hierarchical hosts show a Halation section");
    require(call(kOfxActionCreateInstance, &effect, nullptr, nullptr) == kOfxStatOK, "create instance");
    {
        struct NavigationTest { const char* choice; const char* previous; const char* next; int count; };
        const NavigationTest navigation[] = {
            {"look", "lookPrevious", "lookNext", 19}, {"inputTransform", "inputLutPrevious", "inputLutNext", 3},
            {"lutEncoding", "lutTransferPrevious", "lutTransferNext", 2}, {"halationPreset", "halationPrevious", "halationNext", 4}
        };
        OfxPropertySetStruct change;
        setString(&change, kOfxPropType, 0, kOfxTypeParameter);
        setString(&change, kOfxPropChangeReason, 0, kOfxChangeUserEdited);
        setDouble(&change, kOfxPropTime, 0, 5);
        for (const auto& nav : navigation) {
            auto target = effect.params.values[nav.choice].get();
            require(effect.params.values[nav.previous]->type == kOfxParamTypePushButton &&
                effect.params.values[nav.next]->type == kOfxParamTypePushButton, "navigation uses actual OpenFX push buttons");
            require(effect.params.values[nav.previous]->props.strings[kOfxPropLabel][0] == "ANTERIOR" &&
                effect.params.values[nav.next]->props.strings[kOfxPropLabel][0] == "PRÓXIMO", "navigation labels are Portuguese");
            setString(&change, kOfxPropName, 0, nav.next);
            for (int n = 0; n < nav.count; ++n) {
                require(call(kOfxActionInstanceChanged, &effect, &change, nullptr) == kOfxStatOK, "next button processes user click");
                require(target->value == (n + 1) % nav.count, "next advances exactly one option and wraps");
            }
            setString(&change, kOfxPropName, 0, nav.previous);
            require(call(kOfxActionInstanceChanged, &effect, &change, nullptr) == kOfxStatOK && target->value == nav.count - 1, "previous wraps first to last");
            require(call(kOfxActionInstanceChanged, &effect, &change, nullptr) == kOfxStatOK && target->value == nav.count - 2, "previous decrements");
            require(target->choiceKeys.empty(), "browsing a static choice does not create keyframes");
            target->value = 0;
            setString(&change, kOfxPropChangeReason, 0, kOfxChangePluginEdited);
            require(call(kOfxActionInstanceChanged, &effect, &change, nullptr) == kOfxStatReplyDefault && target->value == 0, "plugin-generated notifications cannot retrigger navigation");
            setString(&change, kOfxPropChangeReason, 0, kOfxChangeTime);
            require(call(kOfxActionInstanceChanged, &effect, &change, nullptr) == kOfxStatReplyDefault && target->value == 0, "timeline changes do not advance choices");
            setString(&change, kOfxPropChangeReason, 0, kOfxChangeUserEdited);
        }
        for (const char* name : {"look", "halationPreset"}) {
            auto target = effect.params.values[name].get();
            target->choiceKeys = {{0, 0}, {10, 3}};
            setString(&change, kOfxPropName, 0, std::strcmp(name, "look") == 0 ? "lookNext" : "halationNext");
            require(call(kOfxActionInstanceChanged, &effect, &change, nullptr) == kOfxStatOK, "navigation supports an already animated choice");
            require(target->choiceKeys == std::map<double, int>({{0, 0}, {5, 1}, {10, 3}}), "navigation changes only the key at current time, preserving other keys");
            target->choiceKeys.clear(); target->value = 0;
        }
        setString(&change, kOfxPropName, 0, "lookNext");
        auto target = effect.params.values["look"].get();
        target->writeStatus = kOfxStatErrValue;
        require(call(kOfxActionInstanceChanged, &effect, &change, nullptr) == kOfxStatErrValue, "host write failure is propagated");
        require(target->value == 0 && editBegins == editEnds, "failed navigation leaves choice unchanged and closes the undo edit");
        target->writeStatus = kOfxStatOK; target->value = 19;
        require(call(kOfxActionInstanceChanged, &effect, &change, nullptr) == kOfxStatErrValue, "invalid menu index is not silently cycled");
        target->value = 0;
        setString(&change, kOfxPropName, 0, "look");
        require(call(kOfxActionInstanceChanged, &effect, &change, nullptr) == kOfxStatReplyDefault && target->value == 0, "a normal dropdown edit is not treated as a button click");
        require(effect.params.values["lookStrength"]->value == 1 && effect.params.values["lutFile"]->stringValue.empty(), "navigation preserves strength and custom file path");
        require(editBegins > 0 && editBegins == editEnds, "navigation edits are paired for host undo");
    }
    setDouble(&in, kOfxPropTime, 0, 0);
    require(call(kOfxImageEffectActionIsIdentity, &effect, &in, &out) == kOfxStatOK, "neutral identity action");
    require(out.strings[kOfxPropName][0] == "Source", "identity source clip");
    require(call(kOfxImageEffectActionGetRegionOfDefinition, &effect, &in, &out) == kOfxStatOK, "source region of definition");
    require(out.doubles[kOfxImageEffectPropRegionOfDefinition] == std::vector<double>({-2, 3, 2, 6}), "region propagated");
    constexpr int row = 20;
    std::vector<float> source(row * 3, -99), dest(row * 3, -77);
    for (int y = 0; y < 3; ++y) for (int x = 0; x < 4; ++x) {
        auto s = source.data() + y * row + x * 4;
        for (int c = 0; c < 3; ++c) s[c] = (c + 1) * 0.1f + y * 0.01f + x * 0.005f;
        s[3] = 0.5f;
    }
    auto src = effect.clips["Source"].get(), dst = effect.clips["Output"].get();
    setupImage(src, source.data() + 2 * row, true, -row * static_cast<int>(sizeof(float)));
    setupImage(dst, dest.data(), true, row * sizeof(float));
    require(call(kOfxImageEffectActionGetClipPreferences, &effect, nullptr, &out) == kOfxStatOK, "clip preferences");
    require(out.strings[kOfxImageEffectPropPreMultiplication][0] == kOfxImagePreMultiplied, "premultiplication negotiated");
    int tile[] = {-1, 4, 1, 6};
    for (int n = 0; n < 4; ++n) setInt(&in, kOfxImageEffectPropRenderWindow, n, tile[n]);
    effect.params.values["exposure"]->animated = true;
    setDouble(&in, kOfxPropTime, 0, 1);
    require(call(kOfxImageEffectActionIsIdentity, &effect, &in, &out) == kOfxStatReplyDefault, "animated grade is not identity");
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "render animated tile, nonzero origin, negative input stride");
    require(sampledTime == 1, "parameters sampled at requested time");
    for (int y = 0; y < 3; ++y) for (int x = 0; x < row; ++x) {
        bool inside = y >= 1 && x >= 4 && x < 12;
        const float value = 2 * ((x % 4 + 1) * 0.1f + (2 - y) * 0.01f + (x / 4) * 0.005f);
        float expected = !inside ? -77.0f : (x % 4 == 3 ? 0.5f : value);
        require(std::abs(dest[y * row + x] - expected) < 1e-6f, "tile pixels, alpha and padding preserved");
    }
    require(acquired == released, "all normal images released");
    effect.params.values["exposure"]->animated = false;
    effect.params.values["inputTransform"]->value = 2;
    effect.params.values["lutFile"]->stringValue = "tests/fixtures/swap.cube";
    require(call(kOfxImageEffectActionIsIdentity, &effect, &in, &out) == kOfxStatReplyDefault, "active input LUT disables identity fast path");
    std::fill(dest.begin(), dest.end(), -77);
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "render uses selected .cube file");
    for (int y = 0; y < 3; ++y) for (int x = 0; x < row; ++x) {
        const bool inside = y >= 1 && x >= 4 && x < 12;
        const int channel = 2 - x % 4;
        const float value = (channel + 1) * 0.1f + (2 - y) * 0.01f + (x / 4) * 0.005f;
        const float expected = !inside ? -77.0f : (x % 4 == 3 ? 0.5f : value);
        require(std::abs(dest[y * row + x] - expected) < 1e-6f, "LUT render preserves alpha, tile bounds, padding and premultiplication");
    }
    effect.params.values["lutFile"]->stringValue = "";
    effect.params.values["inputTransform"]->value = 1;
    for (int y = 0; y < 3; ++y) for (int x = 0; x < 4; ++x)
        for (int c = 0; c < 3; ++c) source[y * row + x * 4 + c] = 0.25f;
    require(call(kOfxImageEffectActionIsIdentity, &effect, &in, &out) == kOfxStatReplyDefault, "embedded Avata LUT is active without an external file");
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "embedded Avata preset renders with an empty custom LUT path");
    const float* avataPixel = dest.data() + row + 4;
    require(std::abs(avataPixel[0] - 0.487409f * 0.5f) < 1e-6f &&
            std::abs(avataPixel[1] - 0.487448f * 0.5f) < 1e-6f &&
            std::abs(avataPixel[2] - 0.487588f * 0.5f) < 1e-6f && avataPixel[3] == 0.5f,
            "embedded user-supplied LUT matches a known original gray node and preserves alpha");
    const std::array<float, 3> converted{avataPixel[0], avataPixel[1], avataPixel[2]};
    effect.params.values["look"]->value = 18;
    effect.params.values["lookStrength"]->value = 0;
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "commercial look at zero intensity renders normalized footage");
    require(std::abs(avataPixel[0] - converted[0]) < 1e-6f && std::abs(avataPixel[1] - converted[1]) < 1e-6f && std::abs(avataPixel[2] - converted[2]) < 1e-6f, "zero style intensity does not bypass the Avata LUT");
    effect.params.values["lookStrength"]->value = 1;
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "commercial cinematic style renders on top of conversion");
    const std::array<float, 3> styled{avataPixel[0], avataPixel[1], avataPixel[2]};
    require(std::abs(styled[0] - converted[0]) > 1e-4f || std::abs(styled[2] - converted[2]) > 1e-4f, "full style changes normalized color");
    effect.params.values["lookStrength"]->value = 0.5;
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "intermediate style intensity renders");
    require(std::abs(avataPixel[0] - (converted[0] + styled[0]) * 0.5f) < 1e-6f && std::abs(avataPixel[2] - (converted[2] + styled[2]) * 0.5f) < 1e-6f && avataPixel[3] == 0.5f, "style strength blends the post-LUT image and preserves alpha");
    effect.params.values["look"]->value = 0;
    effect.params.values["lookStrength"]->value = 1;
    {
        const auto oldSource = src->image, oldOutput = dst->image;
        const auto oldRod = src->rod;
        effect.params.values["inputTransform"]->value = 0;
        require(effect.params.values["halationPreset"]->value == 0, "halation defaults off in existing workflows");
        constexpr int w = 64, h = 1080, stride = w * 4 + 4;
        constexpr int x0 = -17, y0 = -5;
        std::vector<float> spatialSource(stride * h, -99), spatialOutput(stride * h, -77);
        auto at = [](std::vector<float>& buffer, int x, int y) {
            return buffer.data() + (h - 1 - (y - y0)) * stride + (x - x0) * 4;
        };
        for (int y = y0; y < y0 + h; ++y) for (int x = x0; x < x0 + w; ++x) {
            auto p = at(spatialSource, x, y);
            const float v = x >= 12 && x < 25 && y >= 510 && y < 530 ? 0.5f : 0.04f;
            p[0] = p[1] = p[2] = v; p[3] = 0.5f;
        }
        auto hidden = at(spatialSource, -15, 515);
        hidden[0] = hidden[1] = hidden[2] = 100; hidden[3] = 0;
        setupImage(src, spatialSource.data() + (h - 1) * stride, true, -stride * static_cast<int>(sizeof(float)));
        setupImage(dst, spatialOutput.data() + (h - 1) * stride, true, -stride * static_cast<int>(sizeof(float)));
        const int bounds[] = {x0, y0, x0 + w, y0 + h};
        for (int n = 0; n < 4; ++n) { setInt(&src->image, kOfxImagePropBounds, n, bounds[n]); setInt(&dst->image, kOfxImagePropBounds, n, bounds[n]); }
        src->rod = {x0, y0, x0 + w, y0 + h};
        setDouble(&in, kOfxImageEffectPropRenderScale, 0, 1); setDouble(&in, kOfxImageEffectPropRenderScale, 1, 1);
        const int region[] = {5, 500, 35, 540};
        for (int n = 0; n < 4; ++n) setDouble(&in, kOfxImageEffectPropRegionOfInterest, n, region[n]);
        require(call(kOfxImageEffectActionGetRegionsOfInterest, &effect, &in, &out) == kOfxStatReplyDefault, "off keeps the default input ROI");
        const int radii[] = {0, 3, 5, 8};
        double previousEnergy = 0;
        for (int preset = 1; preset <= 3; ++preset) {
            effect.params.values["halationPreset"]->value = preset;
            require(call(kOfxImageEffectActionIsIdentity, &effect, &in, &out) == kOfxStatReplyDefault, "halation disables neutral identity bypass");
            require(call(kOfxImageEffectActionGetRegionsOfInterest, &effect, &in, &out) == kOfxStatOK, "spatial effect supplies source ROI");
            const int pad = 3 * radii[preset];
            require(out.doubles["OfxImageClipPropRoI_Source"] == std::vector<double>({double(region[0] - pad), double(region[1] - pad), double(region[2] + pad), double(region[3] + pad)}), "ROI covers all three blur passes in canonical coordinates");
            for (int n = 0; n < 4; ++n) setInt(&in, kOfxImageEffectPropRenderWindow, n, bounds[n]);
            require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "full-frame halation renders with negative source and destination strides");
            const auto reference = spatialOutput;
            auto neighbor = at(spatialOutput, 11, 520);
            require(neighbor[0] > neighbor[1] && neighbor[1] > neighbor[2] && neighbor[2] > 0.04f && neighbor[3] == 0.5f, "halo affects a dark neighbor in warm RGB and preserves premultiplied alpha");
            require(at(spatialOutput, -14, 515)[0] == 0.04f, "hidden transparent highlights do not create halo");
            double energy = 0;
            bool alphaOK = true, paddingOK = true;
            for (int y = y0; y < y0 + h; ++y) {
                for (int x = x0; x < x0 + w; ++x) {
                    auto a = at(spatialOutput, x, y), b = at(spatialSource, x, y);
                    alphaOK = alphaOK && a[3] == b[3];
                    if (b[3] > 0) energy += std::max(0.0f, a[0] - b[0]);
                }
                paddingOK = paddingOK && spatialOutput[(h - 1 - (y - y0)) * stride + w * 4] == -77;
            }
            require(alphaOK && paddingOK, "halation preserves frame alpha and row padding");
            require(energy > previousEnergy, "rendered integrated halo increases across presets"); previousEnergy = energy;
            std::fill(spatialOutput.begin(), spatialOutput.end(), -77);
            for (int n = 0; n < 4; ++n) setInt(&in, kOfxImageEffectPropRenderWindow, n, region[n]);
            require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "halation tile renders");
            require(src->requestedRegion == out.doubles["OfxImageClipPropRoI_Source"], "render explicitly requests the same expanded source ROI");
            bool tilesOK = true;
            for (int y = y0; y < y0 + h; ++y) for (int x = x0; x < x0 + w; ++x) {
                const bool inside = x >= region[0] && y >= region[1] && x < region[2] && y < region[3];
                auto actual = at(spatialOutput, x, y);
                const auto expected = reference.data() + (h - 1 - (y - y0)) * stride + (x - x0) * 4;
                for (int c = 0; c < 4; ++c) tilesOK = tilesOK && std::abs(actual[c] - (inside ? expected[c] : -77)) < 1e-6f;
            }
            require(tilesOK, "spatial tile equals full frame with no writes outside render window");
            const int cropped[] = {std::max(region[0] - pad, bounds[0]), std::max(region[1] - pad, bounds[1]),
                std::min(region[2] + pad, bounds[2]), std::min(region[3] + pad, bounds[3])};
            for (int n = 0; n < 4; ++n) setInt(&src->image, kOfxImagePropBounds, n, cropped[n]);
            setPointer(&src->image, kOfxImagePropData, 0, at(spatialSource, cropped[0], cropped[1]));
            require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "halation renders when the host supplies only the requested neighbor region");
            bool cropOK = true;
            for (int y = region[1]; y < region[3]; ++y) for (int x = region[0]; x < region[2]; ++x) {
                const auto actual = at(spatialOutput, x, y);
                const auto expected = reference.data() + (h - 1 - (y - y0)) * stride + (x - x0) * 4;
                for (int c = 0; c < 4; ++c) cropOK = cropOK && std::abs(actual[c] - expected[c]) < 1e-6f;
            }
            require(cropOK, "cropped source ROI produces the same halo as the full source frame");
            for (int n = 0; n < 4; ++n) setInt(&src->image, kOfxImagePropBounds, n, bounds[n]);
            setPointer(&src->image, kOfxImagePropData, 0, spatialSource.data() + (h - 1) * stride);
            effect.params.values["mix"]->value = 0.5;
            require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "halation supports half global mix");
            const auto mixed = at(spatialOutput, 11, 520), original = at(spatialSource, 11, 520);
            const auto full = reference.data() + (h - 1 - (520 - y0)) * stride + (11 - x0) * 4;
            require(std::abs(mixed[0] - (original[0] + full[0]) * 0.5f) < 1e-6f, "Effect Mix blends after halation");
            effect.params.values["mix"]->value = 1;
            std::fill(spatialOutput.begin(), spatialOutput.end(), -77);
        }
        setDouble(&src->props, kOfxImagePropPixelAspectRatio, 0, 2);
        setDouble(&in, kOfxImageEffectPropRenderScale, 0, 0.5);
        setDouble(&in, kOfxImageEffectPropRenderScale, 1, 0.5);
        require(call(kOfxImageEffectActionGetRegionsOfInterest, &effect, &in, &out) == kOfxStatOK, "ROI supports proxy scale and non-square pixels");
        require(out.doubles["OfxImageClipPropRoI_Source"] == std::vector<double>({-19, 476, 59, 564}), "proxy and PAR ROI correctly converts support to canonical coordinates");
        effect.params.values["halationPreset"]->value = 4;
        require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatErrValue, "invalid halo preset rejected");
        effect.params.values["halationPreset"]->value = 3;
        effect.params.values["mix"]->value = 0;
        effect.params.values["inputTransform"]->value = 2;
        require(call(kOfxImageEffectActionIsIdentity, &effect, &in, &out) == kOfxStatOK, "mix zero bypasses active halation");
        require(call(kOfxImageEffectActionGetRegionsOfInterest, &effect, &in, &out) == kOfxStatReplyDefault, "mix zero requires no extra spatial input");
        require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatOK, "mix zero renders with active halo and an unavailable custom LUT");
        require(at(spatialOutput, 11, 520)[0] == at(spatialSource, 11, 520)[0], "mix zero is an exact render bypass");
        effect.params.values["inputTransform"]->value = 0;
        effect.params.values["mix"]->value = 1;
        setDouble(&in, kOfxImageEffectPropRenderScale, 0, 0);
        require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatErrValue, "invalid spatial render scale is rejected");
        setDouble(&in, kOfxImageEffectPropRenderScale, 0, 0.5);
        effect.abort = true;
        require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatFailed, "halation respects host cancellation");
        require(acquired == released, "spatial render images released on success and cancellation");
        effect.abort = false;
        effect.params.values["halationPreset"]->value = 0;
        src->image = oldSource; dst->image = oldOutput; src->rod = oldRod;
        setDouble(&src->props, kOfxImagePropPixelAspectRatio, 0, 1);
        for (int n = 0; n < 4; ++n) setInt(&in, kOfxImageEffectPropRenderWindow, n, tile[n]);
    }
    effect.params.values["inputTransform"]->value = 2;
    const int beforeMissing = acquired;
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatErrValue, "missing enabled LUT is not silently ignored");
    require(acquired == beforeMissing, "LUT failure precedes image acquisition");
    require(effect.lastError.find("Select") != std::string::npos, "missing LUT produces an actionable host message");
    require(call(kOfxActionInstanceChanged, &effect, &in, nullptr) == kOfxStatReplyDefault && effect.lastError.empty(), "editing controls clears the previous LUT error state");
    effect.params.values["mix"]->value = 0;
    require(call(kOfxImageEffectActionIsIdentity, &effect, &in, &out) == kOfxStatOK, "zero mix bypasses the entire LUT pipeline");
    effect.params.values["mix"]->value = 1;
    effect.params.values["inputTransform"]->value = 0;
    effect.params.values["exposure"]->animated = true;
    effect.params.values["white"]->value = 0.01;
    effect.params.values["black"]->value = 0.2;
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatErrValue, "invalid levels fail before render");
    effect.params.values["white"]->value = 1; effect.params.values["black"]->value = 0;
    dst->fail = true;
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatFailed, "output acquisition failure preserved");
    require(acquired == released, "source released when output acquisition fails"); dst->fail = false;
    setString(&dst->image, kOfxImageEffectPropPixelDepth, 0, kOfxBitDepthByte);
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatErrImageFormat, "unsupported depth rejected");
    require(acquired == released, "images released after format failure");
    setString(&dst->image, kOfxImageEffectPropPixelDepth, 0, kOfxBitDepthFloat);
    effect.abort = true;
    require(call(kOfxImageEffectActionRender, &effect, &in, nullptr) == kOfxStatFailed, "host abort observed");
    require(acquired == released, "images released after abort");
    require(call(kOfxActionDestroyInstance, &effect, nullptr, nullptr) == kOfxStatOK, "instance destroyed");
    require(effect.props.pointers[kOfxPropInstanceData][0] == nullptr, "instance data cleared");
    require(call(kOfxActionUnload, nullptr, nullptr, nullptr) == kOfxStatOK, "unload");
    dlclose(library);
    std::cout << "Mock OpenFX host: " << checks << " checks passed (not a Resolve validation)\n";
}
