"""Decode the 88-byte parameter enum from the recorded metadata constructor.

The labels/options/defaults are observed under the EMPTY user-state model.
Creative LUT availability under this model is not the complete asset catalogue.
"""
from pathlib import Path
import json,struct,pefile,collections
root=Path(__file__).resolve().parent
meta=json.loads((root/'metadata-emulation.json').read_text())
heap=(root/'metadata-heap.bin').read_bytes();base=meta['heap_base']
target=root/'extracted/ToneLab.ofx.bundle/Contents/Win64/ToneLab.ofx'
pe=pefile.PE(str(target),fast_load=True)
def memory(address,size):
    if base<=address and address+size<=base+len(heap):return heap[address-base:address-base+size]
    if pe.OPTIONAL_HEADER.ImageBase<=address<pe.OPTIONAL_HEADER.ImageBase+pe.OPTIONAL_HEADER.SizeOfImage:
        offset=pe.get_offset_from_rva(address-pe.OPTIONAL_HEADER.ImageBase)
        return pe.__data__[offset:offset+size]
    if not size:return b''
    raise ValueError(f'Pointer outside recorded metadata memory: {address:x}, {size}')
def text(pointer,length):
    assert 0<=length<=4096
    return memory(pointer,length).decode('utf-8')
groups=[];kinds=collections.Counter()
for group in range(13):
    address=meta['output']+88*group
    words=struct.unpack('<11Q',memory(address,88))
    assert words[0]==0x8000000000000006 and words[1]==words[3]
    row={'id':text(words[4],words[5]),'label':text(words[6],words[7]),'open_by_default':bool(words[8]&255),'metadata_address':hex(address),'controls':[]}
    for index in range(words[3]):
        pointer=words[2]+index*88;raw=memory(pointer,88);w=struct.unpack('<11Q',raw)
        if w[0]<0x8000000000000000:
            kind='choice';options=[]
            for option in range(w[2]):
                a,n=struct.unpack('<QQ',memory(w[1]+16*option,16));options.append(text(a,n))
            default=text(w[9],w[10]);assert default in options
            node={'id':text(w[3],w[4]),'label':text(w[5],w[6]),'hint':text(w[7],w[8]),'type':kind,'options':options,'default':default,'default_index':options.index(default)}
        else:
            kind={0:'hidden_string',2:'label',3:'double',4:'boolean',5:'button'}[w[0]-0x8000000000000000]
            node={'id':text(w[1],w[2]),'type':kind}
            if kind!='hidden_string':node.update(label=text(w[3],w[4]),hint=text(w[5],w[6]))
            if kind=='double':
                minimum,maximum,default,reserved=struct.unpack_from('<4d',raw,56)
                assert minimum<=default<=maximum and reserved==0
                node.update(display_min=minimum,display_max=maximum,default=default)
            elif kind=='boolean':node.update(default=bool(w[7]&255))
        node['metadata_address']=hex(pointer)
        row['controls'].append(node);kinds[kind]+=1
    groups.append(row)
report={'target_sha256':meta['target_sha256'],'method':'decoded metadata-constructor CPU emulation with empty local user state',
    'group_count':len(groups),'control_count':sum(len(g['controls']) for g in groups),'control_types':dict(kinds),'groups':groups,
    'limitations':meta['limitations']+['CreativeLut options reflect no local entitlements; full asset names are catalogued separately','Numeric ranges are descriptor/display ranges; hard input constraints have not been established','Descriptions are metadata, not proof of DSP equivalence or Windows UI behavior']}
(root/'parameter-catalog.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
for group in groups:
    print(group['label'],len(group['controls']))
    for node in group['controls']:
        if node['type']=='choice':print(' ',node['id'],node['options'],'default',node['default'])
print('Counts',dict(kinds),'total',report['control_count'])
