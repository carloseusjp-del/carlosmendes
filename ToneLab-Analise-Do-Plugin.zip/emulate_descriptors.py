"""Bounded CPU emulation of one metadata constructor, never a Windows loader.

All imported APIs are intercepted. No target file/network access is implemented.
The existing local key/pack lookup is represented as an EMPTY list, not a key,
trial, or entitlement. This is not a render, activation, or host validation.
The original PE remains unchanged. Addresses are tied to its SHA-256 manifest.
"""
from pathlib import Path
import json, struct, collections
import pefile
from unicorn import Uc, UC_ARCH_X86, UC_MODE_64, UC_HOOK_CODE, UC_HOOK_MEM_INVALID, UcError
from unicorn.x86_const import *

ROOT = Path(__file__).resolve().parent
TARGET = ROOT / 'extracted/ToneLab.ofx.bundle/Contents/Win64/ToneLab.ofx'
pe = pefile.PE(str(TARGET), fast_load=True)
pe.parse_data_directories(directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_IMPORT']])
uc = Uc(UC_ARCH_X86, UC_MODE_64)
BASE = pe.OPTIONAL_HEADER.ImageBase
uc.mem_map(BASE, (pe.OPTIONAL_HEADER.SizeOfImage + 4095) & ~4095)
with TARGET.open('rb') as stream:
    for section in pe.sections:
        stream.seek(section.PointerToRawData)
        remaining = section.SizeOfRawData
        address = BASE + section.VirtualAddress
        while remaining:
            block = stream.read(min(1048576, remaining))
            uc.mem_write(address, block)
            address += len(block)
            remaining -= len(block)

HEAP, STACK, STUBS = 0x4000000000, 0x5000000000, 0x6000000000
uc.mem_map(HEAP, 64 * 1024 * 1024)
uc.mem_map(STACK, 8 * 1024 * 1024)
uc.mem_map(STUBS, 0x20000)
TEB=0x7000000000
uc.mem_map(TEB,0x100000)
uc.reg_write(UC_X86_REG_GS_BASE,TEB)
uc.mem_write(TEB+0x30,struct.pack('<Q',TEB))
uc.mem_write(TEB+0x58,struct.pack('<Q',TEB+0x1000))
uc.mem_write(TEB+0x1000,struct.pack('<Q',TEB+0x2000))
pe.parse_data_directories(directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_TLS']])
if hasattr(pe,'DIRECTORY_ENTRY_TLS'):
    tls=pe.DIRECTORY_ENTRY_TLS.struct
    start=tls.StartAddressOfRawData;end=tls.EndAddressOfRawData
    if end>start:uc.mem_write(TEB+0x2000,bytes(uc.mem_read(start,end-start)))
    uc.mem_write(tls.AddressOfIndex,struct.pack('<I',0))
cursor = HEAP + 0x10000
allocations = {}
events = collections.Counter()
def allocate(size):
    global cursor
    if not 0 <= size <= 32 * 1024 * 1024: raise RuntimeError(f'Allocation outside metadata budget: {size}')
    address = cursor
    cursor += (max(1, size) + 31) & ~31
    if cursor >= HEAP + 64 * 1024 * 1024: raise RuntimeError('Metadata heap exhausted')
    allocations[address] = size
    return address

def u64(address): return struct.unpack('<Q', uc.mem_read(address, 8))[0]
def ret(value=0):
    stack = uc.reg_read(UC_X86_REG_RSP)
    address = u64(stack)
    uc.reg_write(UC_X86_REG_RAX, value & 0xffffffffffffffff)
    uc.reg_write(UC_X86_REG_RSP, stack + 8)
    uc.reg_write(UC_X86_REG_RIP, address)

def args(): return [uc.reg_read(r) for r in (UC_X86_REG_RCX, UC_X86_REG_RDX, UC_X86_REG_R8, UC_X86_REG_R9)]

api = {}
last_error=0
for dll in pe.DIRECTORY_ENTRY_IMPORT:
    for item in dll.imports:
        address = STUBS + 0x100 + len(api) * 16
        api[address] = (dll.dll.decode(), item.name.decode() if item.name else '#'+str(item.ordinal))
        uc.mem_write(item.address, struct.pack('<Q', address))

def api_hook(_uc, address, size, user):
    global last_error
    dll, name = api[address]
    a,b,c,d = args()
    events[name] += 1
    if name in ('GetSystemTimeAsFileTime','GetSystemTimePreciseAsFileTime'):
        uc.mem_write(a, struct.pack('<Q', 116444736000000000)); ret()
    elif name == 'GetProcessHeap': ret(0x1234)
    elif name == 'SHGetKnownFolderPath':
        # Synthetic empty directory only; no actual host path is disclosed.
        value='Z:\\REA-NoUserFiles'.encode('utf-16-le')+b'\0\0'
        pointer=allocate(len(value));uc.mem_write(pointer,value)
        uc.mem_write(d,struct.pack('<Q',pointer));ret(0)
    elif name == 'GetErrorInfo':
        if b: uc.mem_write(b,struct.pack('<Q',0))
        ret(1) # S_FALSE, no COM error information.
    elif name == 'FormatMessageW': ret(0)
    elif name == 'GetLastError': ret(last_error)
    elif name == 'SetLastError': last_error=a;ret(0)
    elif name == 'LocalFree': ret(0)
    elif name == 'GetEnvironmentVariableW': last_error=203;ret(0)
    elif name in ('GetCurrentThreadId','GetCurrentProcessId'): ret(1)
    elif name == 'CoTaskMemFree': ret(0)
    elif name in ('CreateFileW','FindFirstFileW','FindFirstFileExW','GetFileAttributesW'):
        last_error=2;ret(0xffffffffffffffff)
    elif name == 'GetStdHandle': ret(0)
    elif name == 'CreateDirectoryW': ret(1) # Virtual empty filesystem only.
    elif name == 'HeapFree': ret(1)
    elif name in ('HeapAlloc', 'malloc'):
        ret(allocate(c if name == 'HeapAlloc' else a))
    elif name == 'HeapReAlloc':
        target = allocate(d)
        if c: uc.mem_write(target, bytes(uc.mem_read(c, min(allocations.get(c,0),d))))
        ret(target)
    elif name in ('memcpy','memmove'):
        uc.mem_write(a, bytes(uc.mem_read(b,c))); ret(a)
    elif name == 'memset': uc.mem_write(a, bytes([b & 255]) * c); ret(a)
    elif name == 'memcmp':
        left,right=bytes(uc.mem_read(a,c)),bytes(uc.mem_read(b,c));ret((left>right)-(left<right))
    else:
        raise RuntimeError(f'Unimplemented imported API (no host call performed): {dll}!{name} {args()}')
for address in api: uc.hook_add(UC_HOOK_CODE, api_hook, begin=address, end=address)

def allocator(_uc,address,size,user):
    events['Rust allocation shim'] += 1
    ret(allocate(uc.reg_read(UC_X86_REG_RDX)))
uc.hook_add(UC_HOOK_CODE,allocator,begin=0x18040fee0,end=0x18040fee0)

def missing_local_packs(_uc,address,size,user):
    events['Empty existing local key/pack list'] += 1
    result=uc.reg_read(UC_X86_REG_RCX)
    uc.mem_write(result,struct.pack('<QQQ',0,8,0))
    ret(result)
uc.hook_add(UC_HOOK_CODE,missing_local_packs,begin=0x1804535b0,end=0x1804535b0)

def primitive(_uc,address,size,user):
    a,b,c,d=args()
    if address == 0x180885477:
        left,right=bytes(uc.mem_read(a,c)),bytes(uc.mem_read(b,c));ret((left>right)-(left<right))
    elif address == 0x18088546b:
        uc.mem_write(a,bytes(uc.mem_read(b,c)));ret(a)
for address in (0x180885477,0x18088546b): uc.hook_add(UC_HOOK_CODE,primitive,begin=address,end=address)

def invalid(_uc,access,address,size,value,user):
    print('UNMAPPED',access,hex(address),size,'PC',hex(uc.reg_read(UC_X86_REG_RIP)), 'ARGS',args(),flush=True)
    return False
uc.hook_add(UC_HOOK_MEM_INVALID,invalid)
output=HEAP+0x1000
stack=STACK+8*1024*1024-0x108
uc.mem_write(stack,struct.pack('<Q',STUBS))
uc.reg_write(UC_X86_REG_RSP,stack)
uc.reg_write(UC_X86_REG_RCX,output)
try:
    uc.emu_start(0x1804bf4b0,STUBS,timeout=20000000,count=3000000)
except Exception:
    print('PC',hex(uc.reg_read(UC_X86_REG_RIP)),'events',dict(events),flush=True)
    raise
if uc.reg_read(UC_X86_REG_RIP)!=STUBS:
    raise RuntimeError('Constructor did not reach the selected return boundary within the budget')
print('RETURN',uc.mem_read(output,64).hex(),'events',dict(events))
ROOT.joinpath('metadata-heap.bin').write_bytes(bytes(uc.mem_read(HEAP,cursor-HEAP)))
ROOT.joinpath('metadata-emulation.json').write_text(json.dumps({'target_sha256':'f74ecc8a51d1f75918304e214c6b40844ead89767895f3d65a80d4736d1cd27e',
    'entry':'0x1804bf4b0','return':'0x'+format(STUBS,'x'),'output':output,'heap_base':HEAP,'heap_bytes':cursor-HEAP,
    'events':dict(events),'limitations':['CPU metadata-constructor emulation, not native execution or host validation',
        'All imports intercepted; filesystem modeled as an empty virtual directory, no host file/network API calls', 'Existing local key/pack lookup modeled as an empty list; no entitlement supplied']},indent=2)+'\n')
