"""Build the offline Windows installer using MinGW-w64 and its resource compiler."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--compiler', default='x86_64-w64-mingw32-g++')
parser.add_argument('--windres', default='x86_64-w64-mingw32-windres')
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
dist = root / 'dist'
build = root / 'build/installer'
build.mkdir(parents=True, exist_ok=True)
version = re.search(r'^#define MENDES_COLOR_VERSION "([0-9]+\.[0-9]+\.[0-9]+)"$',
                    (root / 'src/version.hpp').read_text(), re.MULTILINE).group(1)
manifest = json.loads((dist / 'manifest.json').read_text())
plugin = dist / 'MendesColor.ofx.bundle/Contents/Win64/MendesColor.ofx'
if manifest['version'] != version or hashlib.sha256(plugin.read_bytes()).hexdigest() != manifest['sha256']:
    raise ValueError('Build/package the current plugin before generating its installer.')
payload = [('Contents/Win64/MendesColor.ofx', plugin)]
for path in sorted((root / 'assets/luts').iterdir()):
    if path.is_file():
        payload.append(('Contents/Resources/LUTs/' + path.name, path))
for name in ['README.md', 'FERRAMENTAS.md', 'GPU.md', 'LOOKS.md', 'HALATION.md', 'LUT-AVATA2.md', 'LICENSE', 'THIRD_PARTY.md']:
    payload.append(('Contents/Resources/' + name, root / name))
payload += [('Contents/Resources/OPENCL-LICENSE.txt', root / 'vendor/opencl/LICENSE.txt'),
            ('Contents/Resources/OPENFX-LICENSE.md', root / 'vendor/openfx/LICENSE.md'),
            ('Contents/Resources/manifest.json', dist / 'manifest.json'),
            ('Contents/Resources/docs/LOOKS-preview.svg', root / 'docs/LOOKS-preview.svg'),
            ('Contents/Resources/docs/HALATION-preview.png', root / 'docs/HALATION-preview.png')]
app_manifest = build / 'setup.manifest'
app_manifest.write_text(f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity version="{version}.0" processorArchitecture="amd64" name="MendesColor.Setup" type="win32"/>
  <description>Mendes Color OpenFX Installer</description>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3"><security><requestedPrivileges>
    <requestedExecutionLevel level="requireAdministrator" uiAccess="false"/>
  </requestedPrivileges></security></trustInfo>
</assembly>
''', encoding='utf-8')
rc = ['#include <windows.h>', '1 RT_MANIFEST "' + app_manifest.as_posix() + '"']
header = ['#pragma once', '#include <cstddef>', 'namespace mendes_setup {',
          'struct Payload { int id; const wchar_t* path; std::size_t bytes; const char* sha256; };',
          'inline constexpr Payload payloads[] = {']
records = []
for index, (destination, source) in enumerate(payload, 100):
    data = source.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    rc.append(f'{index} RCDATA "{source.as_posix()}"')
    header.append('    {' + str(index) + ', L"' + destination + '", ' + str(len(data)) + ', "' + digest + '"},')
    records.append({'resource_id': index, 'path': destination, 'bytes': len(data), 'sha256': digest})
header += ['};', '} // namespace mendes_setup', '']
(build / 'setup.rc').write_text('\n'.join(rc) + '\n', encoding='utf-8')
(build / 'setup_payloads.hpp').write_text('\n'.join(header), encoding='utf-8')
(build / 'payloads.json').write_text(json.dumps(records, indent=2) + '\n')
resource = build / 'setup-res.o'
subprocess.run([args.windres, '--preprocessor', args.compiler,
                '--preprocessor-arg=-E', '--preprocessor-arg=-xc', '--preprocessor-arg=-DRC_INVOKED',
                '-i', str(build / 'setup.rc'), '-O', 'coff', '-o', str(resource)], check=True)
output = dist / f'MendesColor-{version}-Setup.exe'
subprocess.run([args.compiler, '-std=c++17', '-O2', '-Wall', '-Wextra', '-Wpedantic', '-Werror',
                '-pthread', '-static', '-static-libgcc', '-static-libstdc++', '-municode', '-mwindows',
                '-I' + str(root / 'src'), '-I' + str(root / 'installer'), '-I' + str(build),
                str(root / 'installer/setup.cpp'), str(resource), '-o', str(output),
                '-Wl,--no-insert-timestamp', '-lbcrypt', '-lshell32', '-lole32', '-luuid'], check=True)
print('Installer:', output, output.stat().st_size, 'bytes')
print('SHA-256:', hashlib.sha256(output.read_bytes()).hexdigest())
print('Offline payloads:', len(records), '; Windows execution remains unverified.')
