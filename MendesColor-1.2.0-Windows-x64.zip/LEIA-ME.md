# Mendes Color 1.2.0

Plugin OpenFX de correção de cor para **DaVinci Resolve no Windows x64**, com
preset **DJI Avata 2 D-Log M → Rec.709** embutido a partir da LUT fornecida pelo
usuário, importação de LUTs `.cube`, controles de cor e 19 opções de look (Neutral + 18 estilos).

## Instalar e atualizar com o executável

Baixe **`MendesColor-1.2.0-Setup.exe`**, feche o Resolve e abra o instalador.
Autorize a solicitação de administrador do Windows e confirme o destino exibido.
Ele instala o plugin, a LUT e os guias automaticamente; depois basta reabrir
o Resolve. Nas próximas atualizações, execute o novo Setup da mesma forma.
Não é necessário extrair ZIP nem copiar a pasta do plugin nesse fluxo.

A versão anterior é movida integralmente para
`C:\Program Files\Common Files\MendesColor\Backups\`, fora da busca de plugins.
Arquivos extras já existentes no bundle anterior também ficam no backup.
O instalador prepara e verifica os arquivos por SHA-256 antes de substituir o
bundle; falhas na troca acionam a restauração da versão anterior. Ele detecta
Resolve aberto e pede que você o feche, sem encerrar o processo por conta própria.
O Setup funciona offline e não instala Node, Python ou outras dependências.

O executável não tem assinatura digital de editor; o Windows pode pedir
confirmação adicional. Confira a origem e o SHA-256 publicado no GitHub.
A interface Windows e a elevação UAC foram compiladas e inspecionadas, mas ainda
precisam ser exercitadas no seu computador. Os testes locais cobrem as operações
de instalação, backup, erros e restauração em filesystem temporário.

## Alternativa: pacote portátil

1. Extraia **todo** o ZIP `MendesColor-1.2.0-Windows-x64.zip` e feche o Resolve.
2. Copie a pasta **`MendesColor.ofx.bundle` inteira**, substituindo a versão
   anterior, para `C:\Program Files\Common Files\OFX\Plugins\`.
3. Reabra o Resolve. Na página **Color**, procure **Mendes Color** no painel
   **Effects / Open FX**, grupo **Mendes**, e aplique a um node.

Alternativa: execute `Install.ps1` do ZIP extraído num PowerShell como
administrador. Ele verifica o SHA-256 e preserva a versão anterior em
`C:\ProgramData\MendesColor\backups`. A instalação manual dispensa esse script.
Não deixe cópias antigas duplicadas dentro do diretório de plugins.

## Usar a LUT da Avata 2 no fluxo Rec.709 Gamma 2.4

1. Use os arquivos originais gravados em **D-Log M**. Para um fluxo manual
   simples, configure **Color Science: DaVinci YRGB** e **Timeline/Output Color
   Space: Rec.709 Gamma 2.4**, conforme as opções da sua versão do Resolve.
2. No Mendes Color, selecione **Input LUT → DJI Avata 2 D-Log M to Rec.709
   (embedded)**. O campo LUT File pode permanecer vazio.
3. Mantenha **LUT Output Transfer → Keep LUT output**, **Creative Gamma → 1**,
   **Creative Look → Neutral** e **Effect Mix → 1** para começar.
4. Faça seus ajustes de exposição, balanço, contraste e saturação; os looks
   criativos são aplicados **depois** da conversão de entrada.

A LUT embutida preserva exatamente os valores do arquivo enviado. O arquivo
**não declara gamma de saída**; Rec.709 no nome não prova uma potência 2.4 exata.
Por isso, o preset não adiciona outra curva automaticamente. A saída/monitoramento
Rec.709 Gamma 2.4 é configurada no Resolve. O controle **Creative Gamma** é um
ajuste artístico, não essa configuração: **não o coloque em 2.4 para selecionar
o espaço de saída**.

Evite normalizar o mesmo sinal duas vezes: não some outra LUT técnica, CST ou
conversão automática RCM/ACES antes/depois sem definir seus espaços. Em projetos
DaVinci YRGB Color Managed, DWG ou ACES, a LUT precisa receber D-Log M original,
não os pixels já transformados para o espaço de trabalho. O plugin não configura
nem detecta automaticamente a gestão de cor do projeto.

A opção avançada **BT.709 OETF to Gamma 2.4** inverte a OETF de câmera BT.709 e
recodifica para potência 1/2.4. Use-a apenas com uma LUT cuja saída BT.709 OETF
esteja documentada; ela **não é necessária para seguir o fluxo padrão acima**.

## Looks cinematográficos da versão 1.2.0

Depois de selecionar **Input LUT → DJI Avata 2 D-Log M to Rec.709 (embedded)**,
escolha um estilo em **Creative Look**. A conversão acontece uma única vez,
antes do look. Para começar, experimente:

- **Golden Hour**: calor de fim de tarde, com separação suave de sombras/luzes.
- **Sunset Glow**: pôr do sol quente, com magenta sutil e altas luzes suavizadas.
- **Moody Forest**: verde mais fechado e saturação contida.
- **Commercial Teal**: aparência comercial com sombras verde-azuladas.
- **Teal & Orange**: sombras frias e luzes quentes mais evidentes.

**Look Strength** controla apenas a intensidade do estilo. Em **0**, mantém a
LUT e suas correções manuais; em **1**, aplica o look completo. Valores como
**0,4–0,8** são pontos de partida para estilos mais discretos. **Effect Mix**
continua sendo a mistura do plugin inteiro: em zero também desativa a LUT.

O mesmo menu passou de 6 para 19 opções. Os seis nomes/índices antigos foram
preservados, e 42 referências numéricas da versão 1.1.0 confirmam seus resultados
com correções manuais. O novo Look Strength tem padrão 1 para manter esse fluxo.

Consulte **LOOKS.md** para todos os estilos e **docs/LOOKS-preview.svg** para uma
comparação com rampas e cores sintéticas. Essa prévia não é filmagem e não
substitui a avaliação da sua cena; não há emulação calibrada de película nem
máscara automática de pele nesses looks.

## Origem da LUT

A LUT enviada tem **33³ = 35.937 pontos RGB**, domínio padrão 0–1 e SHA-256
`b18162854ab47702068410c33afa98a8cb6eef159fc5a04ce0e65fad0fd8947e`.
O nome do anexo identifica Avata 2, enquanto um comentário interno menciona
**Mavic 3 Pro, D-Log M, 2023-03-24**. Essa diferença foi preservada e registrada,
sem presumir que identifica um erro ou uma equivalência entre câmeras.
A identidade do arquivo não foi autenticada por download direto da DJI.

O original está no pacote em `Contents/Resources/LUTs`, junto de
`PROVENANCE.json`; uma tabela numérica derivada é embutida no binário. O preset
não depende de arquivos externos. A edição do `.cube` de referência dentro do
bundle não muda a tabela embutida; para experimentar outro arquivo use Custom.
Veja `LUT-AVATA2.md` para os detalhes e limites da verificação.

## Usar outras LUTs

Selecione **Input LUT → Custom 3D .cube file** e escolha o arquivo em **LUT File**.
São suportadas LUTs puramente 3D de tamanho 2–65, com interpolação trilinear,
`DOMAIN_MIN/MAX` e `LUT_3D_INPUT_RANGE`. Shapers 1D e tabelas inválidas são
rejeitados. O arquivo customizado precisa continuar disponível; mudanças de
caminho, tamanho ou data de modificação invalidam seu cache. O preset embutido
não usa o campo de arquivo customizado.

As entradas fora do domínio da LUT são limitadas às suas bordas. A saída da
tabela não recebe clipping adicional. Isso não garante recuperação de cores ou
altas luzes já limitadas na gravação ou na própria tabela.

## Controles de cor

| Controle | Função |
|---|---|
| Creative Look | 19 opções; catálogo completo em LOOKS.md |
| Look Strength | Intensidade do look de 0 a 1, preservando LUT e correções manuais |
| Exposure | Ganho RGB `2^stops`; no RGB de saída da LUT é um ajuste criativo, não exposição de cena calibrada |
| Contrast / Pivot | Contraste linear em torno do ponto fixo |
| Creative Gamma | Potência RGB com preservação do sinal; 1 é neutro |
| Warm / Cool | Ganhos criativos por canal; não representa Kelvin calibrado |
| Magenta / Green | Balanço criativo por canal |
| Saturation | Mistura com luma ponderada RGB, usando pesos Rec.709 |
| Black / White Point | Níveis antes dos demais ajustes de cor, após a LUT |
| Effect Mix | Mistura a cadeia inteira com a entrada; 0 é bypass exato, inclusive da LUT |

White Point precisa superar Black Point em pelo menos 0,0001. O canal alfa é
preservado e pixels premultiplicados são tratados em RGB não premultiplicado.
O preset de entrada fica **desativado por padrão**, preservando o fluxo dos
projetos anteriores. Os nomes internos e o identificador do plugin foram mantidos.

## Validação e diagnóstico

A versão 1.0.2 foi confirmada pelo usuário no Resolve 21.1.1 build 10. A nova
1.2.0 foi compilada para Windows e testada em Linux com host OpenFX simulado,
LUTs sintéticas e a tabela enviada. **O preset novo ainda precisa ser verificado
com sua filmagem e no Resolve real**. Isso não certifica a colorimetria da câmera.

O processamento é CPU, RGBA float32; não há implementação CUDA/OpenCL nem
promessa de desempenho em tempo real. O binário não tem assinatura de editor.
A implementação do motor e os looks são próprios; não reproduzem ToneLab.

Se houver erro de descoberta, envie as entradas **Mendes Color 1.2.0** de
`%LOCALAPPDATA%\MendesColor\OpenFX.log`. A tolerância à descrição opcional que
corrigiu o carregamento na 1.0.2 foi preservada. Arquivos customizados ausentes
ou inválidos geram erro no host, em vez de ignorar silenciosamente a LUT.

## Compilar

Headers oficiais OpenFX e o arquivo LUT fornecido estão incluídos com sua
proveniência. GCC/G++ C++17, GNU Make e Python 3 são os requisitos em Linux:

```sh
make test
make windows WIN_CXX=x86_64-w64-mingw32-g++
python3 scripts/package.py
```

No Windows, use Developer PowerShell x64 do Visual Studio 2022 com C++ e Python 3:

```powershell
.\scripts\build-windows.ps1
python scripts/package.py
```

Para gerar também o Setup com MinGW-w64, disponibilize o resource compiler
`x86_64-w64-mingw32-windres`. Depois do build e empacotamento do plugin:

```sh
make installer WIN_CXX=x86_64-w64-mingw32-g++ WIN_WINDRES=x86_64-w64-mingw32-windres
```

O script `scripts/build_installer.py` embute os payloads e seu manifesto UAC,
verifica o manifesto/hash do plugin e gera `dist/MendesColor-1.2.0-Setup.exe`.
`make test` inclui os testes portáveis da transação de instalação. O compilador
MSVC do script acima constrói o plugin; o Setup entregue foi compilado com MinGW.

O fluxo MSVC/PowerShell é fornecido para reconstrução e não foi executado neste
ambiente Linux. O pacote entregue foi compilado com MinGW-w64. A tabela embutida
é gerada em `build/generated` com verificação do hash do `.cube` original.
