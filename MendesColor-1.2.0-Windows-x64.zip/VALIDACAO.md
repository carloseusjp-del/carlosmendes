# Validação da versão 1.2.0

## Compilação e verificações

O pacote Windows foi compilado com MinGW-w64 GCC 14 POSIX para x86-64, C++17,
O2, avisos tratados como erros e runtimes GCC/C++ estáticos. O formato PE/DLL,
as exportações OpenFX e as importações foram inspecionados.

`make test` executou com sucesso:

- 2.235 verificações do motor de cor, incluindo 42 referências da versão 1.1.0 para os seis looks antigos;
- 166 verificações de LUT/transferências: parsing, casos inválidos, domínio,
  interpolação, misturas, ordem de operações, alfa, cache e tabela fornecida;
- 184 verificações do host OpenFX simulado: descoberta, Filter/General,
  tolerância à descrição opcional, parâmetros, amostragem no tempo, tiles,
  padding, stride negativo, erro/cancelamento e liberação de imagens, importação
  customizada, mensagens e render com o preset embutido sem arquivo externo.

- 21 verificações de transações do instalador em diretório temporário:
  instalação nova, atualização, preservação de extras em backup, falha de
  preparação, restauração após falha de commit e colisões de staging/backup.

Os testes de cor, LUT e host também foram executados com AddressSanitizer e
UndefinedBehaviorSanitizer, incluindo detecção de vazamentos, sem diagnóstico.

A LUT original e sua tabela gerada foram verificadas por SHA-256. O arquivo
original foi preservado byte a byte. Testes conferem pontos numéricos conhecidos
e interpolação da cópia embutida contra o `.cube` enviado. O pacote inclui sua
proveniência em `Contents/Resources/LUTs/PROVENANCE.json`.

O REA 6.8.0 em Node.js 24.22.1 inspecionou o binário Windows final: exportações
`OfxGetNumberOfPlugins` e `OfxGetPlugin`, arquitetura AMD64, importações de
`KERNEL32.dll` e `msvcrt.dll`. As evidências completas em `verification/` têm o
mesmo digest do binário do `manifest.json`. A lista de importações não substitui
a execução do carregador Windows nem exclui toda forma de carregamento dinâmico.

A intensidade de estilo foi testada em 0, 0,5 e 1, incluindo preservação da
conversão de câmera em zero, correções manuais e alfa premultiplicado. O menu
anuncia 19 escolhas e os seis índices anteriores continuam iguais. O SVG de
comparação é uma figura de dados sintéticos gerada pelo motor, não uma observação
de imagens da câmera. Os looks são propostas estéticas, sem emulação calibrada.

## Instalador executável

O Setup Windows x64 contém o plugin, a LUT original, proveniência e guias como
recursos. Um manifesto solicita elevação administrativa. A escrita é precedida
por validação SHA-256 dos payloads e seguida por verificação dos arquivos gravados.
A transação instala via staging e move a versão anterior para backup fora da
pasta de plugins; o teste de filesystem força falhas e confere a restauração.

A execução da UI, a solicitação UAC, a enumeração de processos e as chamadas
BCrypt do instalador não foram exercitadas aqui, pois o ambiente é Linux. A
compilação e inspeção do PE/recursos e os testes portáveis não substituem esse
teste Windows. O executável é offline, sem assinatura digital de editor.

## Alcance da confirmação

O usuário confirmou o funcionamento da versão **1.0.2** no seu Resolve. A nova
**1.2.0** ainda não foi executada aqui no Windows nem no DaVinci Resolve real.
Os testes de host são simulados; não estabelecem menus ou aparência no Resolve.
O teste visual com a filmagem Avata 2 e desempenho em 4K ainda está pendente.

A tabela enviada identifica Avata 2 no nome e Mavic 3 Pro num comentário interno.
Não houve autenticação independente contra um download DJI. Ela não declara
gamma de saída, que é preservado por padrão; a configuração Rec.709 Gamma 2.4
do projeto/monitoramento é distinta de provar uma curva 2.4 na LUT.

A compilação MSVC e os scripts de instalação PowerShell não foram executados
neste ambiente Linux. O pacote é uma versão para validação no host, sem
certificação de produção, assinatura de editor ou promessa de tempo real.
